
<footer class="footer">Webmaster Rasmus Jonssønn Skramstad - 2020 <a href="tof">Terms of Service </a><a href="contact">Contact us</a></footer>


</body>
</html>
