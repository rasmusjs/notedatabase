<?php include '../Nav/navbar.php'; ?>
    <title>Files Upload and Download</title>


  
    <div class="content">
    <div class="form">
        <form method="post" enctype="multipart/form-data" >
          <h3>Upload File</h3>

        Permission:

          <select name="permission" required>
            <option selected value="0">Private</option>
            <option value="1">Public</option>
          </select>

  <input type="file" name="myfile" />

  <br><button type="submit" name="Upload">Upload</button>
          <?php include '../../functions/filesLogic.php';?>
        </form>


        <!-- <a href="https://stackoverflow.com/questions/13442270/ini-setupload-max-filesize-200m-not-working-in-php">FIX CORRUPTED FILES OVER 1M</a> -->
      </div>
   
<table>
<tr>
    <th>Filename</th>
    <th>File size (in mb)</th>
    <th>Downloads</th>
    <th>Action</th>
</tr>
<?php foreach ($files as $file): ?>
    <tr>
      <td><?php echo $file['fileID']; ?></td>
      <td><?php echo $file['fileName']; ?></td>
      <td><?php echo floor($file['fileSize'] / 1000) . ' KB'; ?></td>
      <td><?php echo $file['fileDownloads']; ?></td>
      <td><a href="none.php?file_id=<?php echo $file['fileID'] ?>">Download</a></td>
    </tr>
  <?php endforeach;?>



</table>
</div>
</div>
<?php include '../../footer.php' ?>