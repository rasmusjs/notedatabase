<?php

//skal egentlig være functions.php
include 'dbh.inc.php';

//NB hele må endres til en funksjon for å få nedlasting til å fungere som det skal,


// Uploads files
if (isset($_POST['Upload'])) { // if save button on the form is clicked
    // fileName of the uploaded file
    $userID = $_SESSION['userID'];
    $permission = mysqli_real_escape_string($conn, $_POST['permission']);
    
    $fileName = $_FILES['myfile']['name'];
    $filePath = time()."_".$_FILES['myfile']['name'];
    // destination of the file on the server
    $destination = '../../uploads/' . $filePath;
    //$destination = '/var/www/html/lars-prosjekt/uploads/'.$filePath;

    // get the file extension
    $extension = pathinfo($fileName, PATHINFO_EXTENSION);

    // the physical file on a temporary uploads directory on the server
    $file =  $_FILES['myfile']['tmp_name'];
    $fileSize = $_FILES['myfile']['size'];

    /*if (!in_array($extension, ['zip', 'pdf', 'docx', 'txt'])) {
        echo "You file extension must be .zip, .pdf or .docx ";
    }
    elseif*/
    if ($_FILES['myfile']['size'] > 16777216) { // file shouldn't be larger than 1Megabyte
        echo "File too large!";
    } else {
        // move the uploaded (temporary) file to the specified destination
        //copy() instead of move_uploaded_file()
        if (move_uploaded_file($file, $destination)) {
            $sql = "INSERT INTO `files` (`fileAuthor`, `fileName`, `filePath`, `fileSize`, `fileCreated`, `filePermission`, `fileDownloads`) VALUES ('$userID', '$fileName', '$filePath', '$fileSize', CURRENT_TIME(), '$permission', '0');";
            if (mysqli_query($conn, $sql)); {
                echo "File uploaded successfully";
            }
            //PUT RENAMER HERE! rename(); https://www.geeksforgeeks.org/php-rename-function/
        } else {
            echo "Failed to upload file.";
        }
    }
}
// fileDownloads files

/*$sql = "(SELECT files.*,users.userName FROM files LEFT JOIN users
ON files.fileAuthor = users.userID WHERE files.filePermission = '1') UNION (SELECT files.*,users.userName FROM files LEFT JOIN users
ON files.fileAuthor = users.userID WHERE files.fileAuthor = '$userID ')"; */
$sql = "SELECT * FROM files";
$result = mysqli_query($conn, $sql);
$files = mysqli_fetch_all($result, MYSQLI_ASSOC);

if (isset($_GET['file_id'])) {

    $fileid = $_GET['file_id'];

    // fetch file to download from database
    $sql = "SELECT * FROM files WHERE fileID=$fileid";
    $result = mysqli_query($conn, $sql);

    $file = mysqli_fetch_assoc($result);
    $filePath = '../../uploads/' . $file['filePath'];
    if (file_exists($filePath)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename=' . basename($file['fileName']));
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize('../../uploads/' . $file['filePath']));
        ob_clean();
        flush();
        readfile('../../uploads/' . $file['filePath']);

        // Now update fileDownloads count
        $newCount = $file['fileDownloads'] + 1;
        $updateQuery = "UPDATE files SET fileDownloads=$newCount WHERE fileID=$fileid";
        mysqli_query($conn, $updateQuery);
        exit;
    }

}