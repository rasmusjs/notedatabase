<?php include '../Nav/navbar.php'; ?>
    <title>Files Upload and Download</title>


  
    <div class="content">
    <div class="form">
        <form method="post" enctype="multipart/form-data" >
          <h3>Upload File</h3>

        Permission:
          <select name="permission" required>
            <option selected value="0">Private</option>
            <option value="1">Public</option>
          </select>

  <input type="file" name="mp3"/>

  <br><button type="submit" name="Upload">Upload</button>
          <?php 
            if (isset($_POST['Upload'])) {
              $filePath = uploadFile(mp3,$permission);
          }
          
          include '../../functions/filesLogic.php';?>
        </form>


        <!-- <a href="https://stackoverflow.com/questions/13442270/ini-setupload-max-filesize-200m-not-working-in-php">FIX CORRUPTED FILES OVER 1M</a> -->
      </div>
   
<table>
<tr>
    <th>File Creator</th>
    <th>Filename</th>
    <th>File size (in mb)</th>
    <th>Downloads</th>
    <th>Action</th>
</tr>
<?php foreach ($files as $file): ?>
    <tr>
      <td><?php echo $file['userName']; ?></td>
      <td><?php echo $file['fileName']; ?></td>
      <td><?php echo floor($file['fileSize'] / 1000) .' KB'; ?></td>
      <td><?php echo $file['fileDownloads']; ?></td>
      <td><!-- <a href="../../functions/dl.php?file_id=<?php echo $file['filePath'] ?>">Download</a>-->
      <b><a href="../../functions/filesLogic.php?file_id=<?php echo $file['filePath'] ?>">Download</a></b></td>
    </tr>
  <?php endforeach;?>

  <?php showDownloads(); ?>






</table>
</div>
</div>
<?php include '../../footer.php' ?>