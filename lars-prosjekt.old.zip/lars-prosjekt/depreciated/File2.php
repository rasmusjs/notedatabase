<?php include '../Nav/navbar.php'; //userAccess();?>
<title>Home</title>
<div class="content">

   <?php
         include '../../functions/languageSwitcher.php';
         include '../../functions/sqlCharts.php';
      $noteID = $_GET['id']; 
      $sql = "SELECT notedata.mp3,notedata.PDF FROM notedata WHERE noteID = '$noteID'";
      $result = $conn->query($sql);

      echo '<form method="post" enctype="multipart/form-data">';
        if ($result->num_rows > 0) {
           // output data of each row
           while($row = $result->fetch_assoc()) {
            //echo $row[$columnSqlNote['mp3']];
            
            if (isset($row[$columnSqlNote['mp3']])) {
               echo 'MP3 <br><audio controls scr="uploads/mp3/'.$row[$columnSqlNote['mp3']].'"> </audio><br>';
               echo 'Replace mp3?';
              } 
              echo '<select hidden name="permission" "Viewing Permission:" required>
               <option value="0">Private</option>
               <option selected value="1">Public</option>
             </select><br><input type="file" name="Mp3"><br>';
            
         if (!empty($row[$columnSqlNote['PDF']])) {
            echo 'PDF<br><a href="../../functions/filesLogic.php?file_id='.$row[$columnSqlNote['PDF']].'">Download </a>Upload new PDF';
            echo 'Replace PDF?';
              } 
              echo '<br>Upload PDF';
              echo '<select hidden name="permission" "Viewing Permission:" required>
              <option value="0">Private</option>
              <option selected value="1">Public</option>
            </select><br><input type="file" name="Mp3"><br>';
            }


           
        } else {
          echo "Not files found";
          

          echo '<b>Mp3</b>';
          realGUI('mp3','UPLOAD');

          echo '<br><b>PDF</b>';
          realGUI('PDF','UPLOAD');


          if (isset($_POST['Delete'])) {
          realGUI($fileID = mysqli_real_escape_string($conn, $_POST['fileID']),DELETE);
  }
  
        }
   

//realGUI($Mp3, DOWNLOADS);
/*

           echo '<form method="post" enctype="multipart/form-data">';
            echo '<div class="form"> Permission:
               <select name="permission" required>
                 <option selected value="0">Private</option>
                 <option value="1">Public</option>
               </select>
               <input type="file" name="'.$fileType.'"/>
       <br><button name="Upload">Upload</button></form></div>';
       if (isset($_POST['Upload'])) {
        $filePath = uploadFile($fileType,$permission);
    }
            if (isset($row[$columnSqlNote['mp3']])) {
               echo 'MP3 <br><audio controls scr="uploads/mp3/'.$row[$columnSqlNote['mp3']].'"> </audio><br>';
               echo 'Replace mp3?';
              } 
              echo '<select hidden name="permission" "Viewing Permission:" required>
               <option value="0">Private</option>
               <option selected value="1">Public</option>
             </select><br><input type="file" name="Mp3"><br>';
            
         if (!empty($row[$columnSqlNote['PDF']])) {
            echo 'PDF<br><a href="../../functions/filesLogic.php?file_id='.$row[$columnSqlNote['PDF']].'">Download </a>Upload new PDF';
            echo 'Replace PDF?';
              } 
              echo '<br>Upload PDF';
              echo '<select hidden name="permission" "Viewing Permission:" required>
              <option value="0">Private</option>
              <option selected value="1">Public</option>
            </select><br><input type="file" name="Mp3"><br>';
            }
            
         
        
          if (isset($_POST['fileDelete'])) {
          realGUI($fileID = mysqli_real_escape_string($conn, $_POST['fileID']),DELETE);
          }
*/

?>
</div>
</div>
<?php include '../../footer.php' ?>
