<?php include '../../functions/filesLogic.php';?>
<div class="form">
<table>
<thead>
    <th>fileid</th>
    <th>Filename</th>
    <th>fileSize (in mb)</th>
    <th>Downloads</th>
    <th>Action</th>
</thead>
<tbody>
  <?php foreach ($files as $file): ?>
    <tr>
      <td><?php echo $file['fileID']; ?></td>
      <td><?php echo $file['fileName']; ?></td>
      <td><?php echo floor($file['fileSize'] / 1000) . ' KB'; ?></td>
      <td><?php echo $file['fileDownloads']; ?></td>
      <td><a href="download.php?file_id=<?php echo $file['fileID'] ?>">Download</a></td>
    </tr>
  <?php endforeach;?>
</div>
</tbody>
</table>

<?php include '../../footer.php' ?>