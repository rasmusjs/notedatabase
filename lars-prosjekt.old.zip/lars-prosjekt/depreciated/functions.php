<?php
include 'dbh.inc.php';
session_start();
include 'languageSwitcher.php';
header('Content-Type: text/html; charset=utf-8');

function sessionRestrict()
{
    if (!isset($_SESSION['userID']))
    {
        header("Location: ../../");
        die();

    }
}
function userAccess()
{
    $Access = $_SESSION['accessLevel'];
    return $Access;
    die();
}
//Not used
function getUserIpAddr()
{
    $ip = "NotFound";
    if (!empty($_SERVER['HTTP_CLIENT_IP']))
    {
        //ip from share internet
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    }
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))
    {
        //ip pass from proxy
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    }
    else
    {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    //return $ip;
    return 'User Real IP :' . $ip;
}
//Login System
function login($userID, $password)
{
    include 'dbh.inc.php';
    $uniqueid = mysqli_real_escape_string($conn, $_POST['userID']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    //Error handlers
    //Check if inputs are empty
    if (empty($uniqueid) || empty($password))
    {
        header("Location: ../Splash/login.php?error=empty");
        exit();
    }
    else
    {
        $sql = "SELECT * FROM users WHERE userName='$uniqueid' OR userEmail='$uniqueid' OR userPhoneNumber='$uniqueid'";
        $result = mysqli_query($conn, $sql);
        $resultCheck = mysqli_num_rows($result);
        if ($resultCheck < 1)
        {
            header("Location: ../Splash/login.php?error=usernotfound");
            exit();
        }
        else
        {
            if ($row = mysqli_fetch_assoc($result))
            {
                //De-hashing the paswrd
                $hashedPwdCheck = password_verify($password, $row['userPassword']);
                if ($hashedPwdCheck == false)
                {
                    header("Location: ../Splash/login.php?error=userfound");
                    exit();
                }
                elseif ($hashedPwdCheck == true)
                {
                    //Log in the user here
                    $_SESSION['userID'] = $row['userID'];
                    $_SESSION['userName'] = $row['userName'];
                    $_SESSION['userFirstName'] = $row['userFirstName'];
                    $_SESSION['userSurname'] = $row['userSurname'];
                    $_SESSION['userEmail'] = $row['userEmail'];
                    $_SESSION['userPhoneNumber'] = $row['userPhoneNumber'];
                    userDataInitialize();
                    header("Location: ../../?login=loginsuccess");
                    exit();
                }
            }
        }
    }
}
function userDataInitialize()
{
    include 'dbh.inc.php';
    $userID = $_SESSION['userID'];
    $sql = "INSERT INTO `userdata` (`userID`) VALUES ('$userID')";
    if (mysqli_query($conn, $sql) /*or die(mysqli_error($conn))*/);
    {
        echo "New record created successfully";
    }
}
//  include '../../language/'.$setLanguage.'.php';
function signup($userName, $password, $firstName, $surname, $email, $phoneNumber, $passwordRepeat)
{
    include 'dbh.inc.php';
    $userName = mysqli_real_escape_string($conn, $_POST['userName']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $firstName = mb_convert_case(mb_strtolower(mysqli_real_escape_string($conn, $_POST['firstName']) , "UTF-8") , MB_CASE_TITLE, "UTF-8");
    $surname = mb_convert_case(mb_strtolower(mysqli_real_escape_string($conn, $_POST['surname']) , "UTF-8") , MB_CASE_TITLE, "UTF-8");
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phoneNumber = mysqli_real_escape_string($conn, $_POST['phoneNumber']);
    $passwordRepeat = mysqli_real_escape_string($conn, $_POST['passwordRepeated']);
    //Error handlers
    //Check for empty fields
    if (empty($firstName) || empty($surname) || empty($email) || empty($userName) || empty($password) || ($password !== $passwordRepeat) || (empty($phoneNumber)))
    {
        header("Location: ../Splash/signup.php?error=empty");
        exit();
    }
    else
    {
        //Check if email is valid
        if (!filter_var($email, FILTER_VALIDATE_EMAIL))
        {
            header("Location: ../Splash/signup.php?error=emailinalid");
            exit();
        }
        else
        {
            //Check if userName is taken
            $sql = "SELECT * FROM users WHERE userName='$userName';";
            $result = mysqli_query($conn, $sql);
            $resultCheck = mysqli_num_rows($result);
            if ($resultCheck > 0)
            {
                header("Location: ../Splash/signup.php?error=usertaken");
                exit();
            }
            else
            {
                //Check if Email is taken
                $sql = "SELECT * FROM users WHERE userEmail='$email'";
                $result = mysqli_query($conn, $sql);
                $resultCheck = mysqli_num_rows($result);
                if ($resultCheck > 0)
                {
                    header("Location: ../Splash/signup.php?error=emailtaken");
                    exit();
                }
                else
                {
                    //Check if telephonenumber is taken
                    $sql = "SELECT * FROM users WHERE userPhoneNumber='$phoneNumber'";
                    $result = mysqli_query($conn, $sql);
                    $resultCheck = mysqli_num_rows($result);
                    if ($resultCheck > 0)
                    {
                        header("Location: ../Splash/signup.php?error=telephonetaken");
                        exit();
                    }
                    else
                    {
                        //Hashing the password
                        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                        //Insert the user into the database
                        $sql = "INSERT INTO `users` (`userID`,  `userName`,  `userPassword`,  `userFirstName`,  `userSurname`,  `userEmail`,  `userPhoneNumber`) VALUES (NULL,  '$userName',  '$hashedPassword',  '$firstName',  '$surname',  '$email',  '$phoneNumber');";
                        mysqli_query($conn, $sql) or die(mysqli_error($conn));
                        header("Location: ../Splash/login.php?signup=success");
                        exit();
                    }
                }
            }
        }
    }
}

function showname()
{
    include 'dbh.inc.php';
    if (isset($_SESSION['userID']))
    {
        echo "<b>Logged in As " . $_SESSION['userFirstName'] . " " . $_SESSION['userSurname'] . "</b>";
    }
}
function browseSheet($mode, $searchterm)
{
    include 'dbh.inc.php';
    include 'languageSwitcher.php';
    include 'sqlCharts.php';
    if (strlen($searchterm = mysqli_real_escape_string($conn, $_POST['searchterm'])) <= '2')
    {
        echo '<br>String to short';
        echo '<div class="form"><button type="submit">⮌ Back</button></form></div>';
    }
    else
    {
        echo $lang['Searching for'] . ' : ' . $searchterm = mysqli_real_escape_string($conn, $_POST['searchterm']);
        echo '<br>' . $lang['By'] . ' : ' . $selection = mysqli_real_escape_string($conn, $_POST['selection']);

        //Search switch
        switch ($selection)
        {
            case "Primary":
                $searchtype = "`Navn på stykket`";
            break;
            case "Second":
                $searchtype = "`Annet navn på stykket`";
            break;
            case "Composer":
                $searchtype = "`Komponist for musikken`";
            break;
            default:
                $searchtype = "`Navn på stykket`";
        }

        switch ($mode)
        {
            case "0":
                $sql = "SELECT notedata.*, 
            sjanger.Sjanger, 
            opprinnelsesland.Opprinnelsesland, 
            instrumenter.Instrument, 
            `type arrangement`.`Orkester`, 
            lagringssted.konserthistorikk, 
            users.userFirstName,users.userSurname,avstamning.Avstamning,`type stykke`.`Type stykke`
            FROM   notedata
            LEFT JOIN sjanger
            ON notedata.Sjanger = sjanger.id
            LEFT JOIN `type stykke`
            ON notedata.`Type stykke` = `type stykke`.id
            LEFT JOIN users
            ON notedata.Avstamning = users.userID
            LEFT JOIN avstamning
            ON notedata.Avstamning = avstamning.id
            LEFT JOIN `type arrangement`
            ON `notedata`.`Type arrangement` = `type arrangement`.id
            LEFT JOIN opprinnelsesland
            ON notedata.opprinnelsesland = opprinnelsesland.id
            LEFT JOIN lagringssted
            ON notedata.lagringssted = lagringssted.id
            LEFT JOIN instrumenter
            ON notedata.Soloinstrument = instrumenter.ID
            WHERE 1 AND `notedata`.`Godkjent` = '$mode'
            ORDER  BY `notedata`.$searchtype ASC";
            break;
            default:
                $sql = "SELECT notedata.*, 
        sjanger.Sjanger, 
        opprinnelsesland.Opprinnelsesland, 
        instrumenter.Instrument, 
        `type arrangement`.`Orkester`, 
        lagringssted.konserthistorikk, 
        users.userFirstName,users.userSurname,avstamning.Avstamning,`type stykke`.`Type stykke`,`files`.*
        FROM   notedata
        LEFT JOIN sjanger
        ON notedata.Sjanger = sjanger.id
        LEFT JOIN `type stykke`
        ON notedata.`Type stykke` = `type stykke`.id
        LEFT JOIN users
        ON notedata.Avstamning = users.userID
        LEFT JOIN avstamning
        ON notedata.Avstamning = avstamning.id
        LEFT JOIN `type arrangement`
        ON `notedata`.`Type arrangement` = `type arrangement`.id
        LEFT JOIN opprinnelsesland
        ON notedata.opprinnelsesland = opprinnelsesland.id
        LEFT JOIN lagringssted
        ON notedata.lagringssted = lagringssted.id
        LEFT JOIN instrumenter
        ON notedata.Soloinstrument = instrumenter.ID
        LEFT JOIN files
        ON notedata.PDF = files.filePath
        WHERE `notedata`.$searchtype LIKE '%$searchterm%' AND `notedata`.`Godkjent` = '$mode'
        ORDER  BY `notedata`.$searchtype ASC";
            break;
        }

        $result = $conn->query($sql) or die(mysqli_error($conn));
        if ($result->num_rows > 0)
        {
            echo "<br><b> $result->num_rows" . '. ' . $lang['Result found'] . "</b>";
            echo '<table>
<tr> 
<th>' . $lang['Piece name'] . '</th>
<th>' . $lang['Other name'] . '</th>
<th>' . $lang['Composer'] . '</th>
<th>' . $lang['Publisher catalogue number'] . '</th>
<th>' . $lang['Genre'] . '</th>
<th>' . $lang['Lyricist'] . '</th>
<th>' . $lang['Opus number'] . '</th>
<th>' . $lang['Arranger'] . '</th>
<th>' . $lang['Ensemble type'] . '</th>
<th>' . $lang['Ancestry'] . '</th>
<th>' . $lang['Country of origin'] . '</th>
<th>' . $lang['Movement'] . '</th>
<th>' . $lang['Key'] . '</th>
<th>' . $lang['Solo instrument'] . '</th>
<th>' . $lang['Duration'] . '</th>
<th>' . $lang['Released'] . '</th>
<th>' . $lang['Scores Available'] . '</th>
<th>' . $lang['Soloist'] . '</th>
<th>' . $lang['Vocal'] . '</th>
<th>' . $lang['Chord names'] . '</th>
<th>' . $lang['Mp3'] . '</th>
<th>' . $lang['PDF'] . '</th>
<th>' . $lang['Physical location'] . '</th>
<th>' . $lang['Link to music sample'] . '</th>
<th>' . $lang['Please note'] . '</th>
</tr>';
            // output data of each row
            while ($row = $result->fetch_assoc())
            {
                echo "
<tr>
<td>" . $row[$columnSqlNote['Navn på stykket']] . "</td>
<td>" . $row[$columnSqlNote['Annet navn på stykket']] . "</td>
<td>" . $row[$columnSqlNote['Komponist for musikken']] . "</td>
<td>" . $row[$columnSqlNote['Noteutgivers katalognr']] . "</td>";
                if ($row[$columnSqlNote['Sjanger']] === '')
                {
                    echo "<td>Not given</td>";
                }
                else
                {
                    echo "<td>" . $row[$columnSqlNote['Sjanger']] . "</td>";
                }
                echo "
<td>" . $row[$columnSqlNote['Tekstforfatter']] . "</td>
<td>" . $row[$columnSqlNote['Opus nr']] . "</td>
<td>" . $row[$columnSqlNote['Arrangert av']] . "</td>

<td>" . $row[$columnSqlNote['Type stykke']] . "</td>";
                //78 is the number where the first users appear
                if ($row[$columnSqlNote['Avstamning']] > '78')
                {
                    echo "<td>" . $row[$columnSqlNote['Avstamning']] . "</td>";
                }
                else
                {
                    echo "<td>" . $row[$columnSqlUser['userFirstName']] . " " . $row[$columnSqlUser['userSurname']] . "</td>";
                }
                echo "<td>" . $row[$columnSqlNote['Opprinnelsesland']] . "</td>
<td>" . $row[$columnSqlNote['Type arrangement']] . "</td>
<td>" . $row[$columnSqlNote['Dur']] . "</td>
<td>" . $row[$columnSqlNote['Soloinstrument']] . "</td>
<td>" . $row[$columnSqlNote['Spilletid']] . "</td>
<td>" . $row[$columnSqlNote['Utgivelsesdato']] . "</td>";
                if ($row[$columnSqlNote['Akkorder er angitt']] == '0')
                {
                    echo "<td>" . $lang['Not given'] . "</td>";
                }
                else
                {
                    echo "<td>" . $lang['Given'] . "</td>";
                }
                if ($row[$columnSqlNote['Solist']] == '0')
                {
                    echo "<td>" . $lang['No'] . "</td>";
                }
                else
                {
                    echo "<td>" . $lang['Yes'] . "</td>";
                }
                if ($row[$columnSqlNote['Sang']] == '0')
                {
                    echo "<td>" . $lang['No'] . "</td>";
                }
                else
                {
                    echo "<td>" . $lang['Yes'] . "</td>";
                }
                if ($row[$columnSqlNote['Partitur finnes']] == '0')
                {
                    echo "<td>" . $lang['No'] . "</td>";
                }
                else
                {
                    echo "<td>" . $lang['Yes'] . "</td>";
                }
                if (empty($row[$columnSqlNote['mp3']]))
                {
                    echo '<td>' . $lang['Mp3 not found'] . '</td>';
                }
                else
                {
                    echo '<td><audio style="width:50px;" controls scr="uploads/mp3/' . $row[$columnSqlNote['mp3']] . '"></td>';
                }

                if (($row[$columnSqlNote['fileName']] == '') and ($row[$columnSqlNote['PDF']] == ''))
                {
                    echo '<td>' . $lang['PDF not found'] . '</td>';
                }
                else
                {
                    echo '<td><a href="../../functions/filesLogic.php?file_id=' . $row[$columnSqlNote['filePath']] . '"target="_blank">' . $row[$columnSqlNote['fileName']] . '</a></td>';
                }
                /* if ($row[$columnSqlNote['PDF']] == '0') {
                    echo "<td>" . $lang['No'] . "</td>";
                } else {
                    echo "<td>" . $lang['Yes'] . "</td>";
                }*/
                echo "
<td>" . $row[$columnSqlNote['Lagringssted']] . "</td>";
                if ($row[$columnSqlNote['Link til lydprøve']] == '')
                {
                    echo '<td>' . $lang['Link not found'] . '</td>';
                }
                else
                {
                    $link = $row[$columnSqlNote['Link til lydprøve']];
                    echo '<td><a href="' . str_replace("#", "", "$link") . '"target="_blank">Link</a></td>';
                }
                echo "
<td>" . $row[$columnSqlNote['Obs']] . "</td>";

                echo '<td><form method="POST"><input type="text" name="noteID" hidden value=' . $row[$columnSqlNote['noteID']] . '>  
            ';

                if (userAccess() == '1')
                {
                    echo '<button class="link" type="submit" name="Edit">Edit</button><br><button class="link" name="Delete">Delete</button>';

                    if ($mode == '0')
                    {
                        echo '<button name="Approve">Approve</button>';
                    }
                }

                echo '<br><button class="link" name="View">View</button></form></td></tr>';
            }
            echo "</td></tr></table>";
        }
        else
        {
            echo '<br><b>' . $lang['No result found'] . '</br>';
        }
        echo '<div class="form"><button type="submit">⮌ Back</button></div>';
    }
}

function deleteSheet()
{
    include 'dbh.inc.php';
    include 'languageSwitcher.php';
    $noteID = mysqli_real_escape_string($conn, $_POST['noteID']);
    if (userAccess() == '1')
    {
        $sql = "DELETE FROM `notedata` WHERE `notedata`.`noteID` = $noteID";
        if (mysqli_query($conn, $sql));
        {
            echo "Deleted successfully";
        }
    }
    else
    {
        echo "Action not permitted";
    }
    echo '<div class="form"><button type="submit">⮌ Back</button></div>';
}

function approveSheet()
{
    include 'dbh.inc.php';
    include 'languageSwitcher.php';
    $noteID = mysqli_real_escape_string($conn, $_POST['noteID']);
    if (userAccess() == '1')
    {
        $sql = "UPDATE `notedata` SET `Godkjent` = '1' WHERE `notedata`.`noteID` = $noteID";
        if (mysqli_query($conn, $sql));
        {
            echo "Note approved successfully";
        }
    }
    else
    {
        echo "Action not permitted";
    }
    echo '<div class="form"><button type="submit">⮌ Back</button></div>';
}

function viewDetail($noteID)
{
    include 'dbh.inc.php';
    include 'languageSwitcher.php';
    $noteID = mysqli_real_escape_string($conn, @$_POST['noteID']);
    if ($noteID > 0)
    {
        include 'sqlCharts.php';
        $sql = "SELECT * FROM notedata WHERE notedata.noteID = '$noteID'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0)
        {
            $result->num_rows;
            // output data of each row
            while ($row = $result->fetch_assoc())
            {
                echo '<div class="form">
<form method="POST">
<b>
<table>
<tbody>
<tr>
<td><input hidden value="' . $row[$columnSqlNote['noteID']] . '" name="noteID" ">
<thead>
<tr>
<th>
' . $lang['Alt Saxophone in Eb 1'] . '<br><input type="checkbox" ' . checkbox($row[$columnSqlNote['Alt-saksofon i Eb 1']]) . 'name="AltSaxophoneinEb1" placeholder="' . $lang['Alt Saxophone in Eb 1'] . '">
' . $lang['Alt Saxophone in Eb 2'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Alt-saksofon i Eb 2']]) . 'name="AltSaxophoneinEb2" placeholder="' . $lang['Alt Saxophone in Eb 2'] . '">
' . $lang['Alt Saxophone in Eb 3'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Alt-saksofon i Eb 3']]) . 'name="AltSaxophoneinEb3" placeholder="' . $lang['Alt Saxophone in Eb 3'] . '">
' . $lang['Banjo'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Banjo']]) . 'name="Banjo" placeholder="' . $lang['Banjo'] . '">
' . $lang['Baritone-saxophone in Eb'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Bariton-Saxofon i Eb']]) . 'name="Baritone-saxophoneinEb" placeholder="' . $lang['Baritone-saxophone in Eb'] . '">
' . $lang['Bass Clarinet (and or Clarinet in Eb)'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Bassklarinett (og eller klarinett i Eb)']]) . 'name="BassClarinet(andorClarinetinEb)" placeholder="' . $lang['Bass Clarinet (and or Clarinet in Eb)'] . '">
' . $lang['Bass Trombone'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Bass-trombone']]) . 'name="BassTrombone" placeholder="' . $lang['Bass Trombone'] . '">
' . $lang['Viola'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Bratsj']]) . 'name="Viola" placeholder="' . $lang['Viola'] . '">
' . $lang['Castanets'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Castagnetter']]) . 'name="Castanets" placeholder="' . $lang['Castanets'] . '">
' . $lang['Celesta'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Celesta']]) . 'name="Celesta" placeholder="' . $lang['Celesta'] . '">
</th>
<th>
' . $lang['Cello 1'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Cello 1']]) . 'name="Cello1" placeholder="' . $lang['Cello 1'] . '">
' . $lang['Cello 2'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Cello 2']]) . 'name="Cello2" placeholder="' . $lang['Cello 2'] . '">
' . $lang['Cello Obbligato'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Cello obligato']]) . 'name="CelloObbligato" placeholder="' . $lang['Cello Obbligato'] . '">
' . $lang['Chimes / Tubular Bells'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Chimes/tubular bells']]) . 'name="Chimes/TubularBells" placeholder="' . $lang['Chimes / Tubular Bells'] . '">
' . $lang['Cymbals'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Cymbaler']]) . 'name="Cymbals" placeholder="' . $lang['Cymbals'] . '">
' . $lang['Sleigh Bells'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Dombjeller']]) . 'name="SleighBells" placeholder="' . $lang['Sleigh Bells'] . '">
' . $lang['English Horn'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Engelsk horn']]) . 'name="EnglishHorn" placeholder="' . $lang['English Horn'] . '">
' . $lang['Euphonium'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Eufonium']]) . 'name="Euphonium" placeholder="' . $lang['Euphonium'] . '">
' . $lang['Bassoon 1'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Fagott 1']]) . 'name="Bassoon1" placeholder="' . $lang['Bassoon 1'] . '">
' . $lang['Bassoon 2'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Fagott 2']]) . 'name="Bassoon2" placeholder="' . $lang['Bassoon 2'] . '">
</th>
<th>
' . $lang['Violin 1'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Fiolin 1']]) . 'name="Violin1" placeholder="' . $lang['Violin 1'] . '">
' . $lang['Violin 2'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Fiolin 2']]) . 'name="Violin2" placeholder="' . $lang['Violin 2'] . '">
' . $lang['Violin 3'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Fiolin 3']]) . 'name="Violin3" placeholder="' . $lang['Violin 3'] . '">
' . $lang['Violin Obligate'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Fiolin obligat']]) . 'name="ViolinObligate" placeholder="' . $lang['Violin Obligate'] . '">
' . $lang['Flute 1'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Fløyte 1']]) . 'name="Flute1" placeholder="' . $lang['Flute 1'] . '">
' . $lang['Flute 2'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Fløyte 2']]) . 'name="Flute2" placeholder="' . $lang['Flute 2'] . '">
' . $lang['Flute 3'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Fløyte 3']]) . 'name="Flute3" placeholder="' . $lang['Flute 3'] . '">
' . $lang['Guitar'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Gitar']]) . 'name="Guitar" placeholder="' . $lang['Guitar'] . '">
' . $lang['Harmonica'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Harmonika']]) . 'name="Harmonica" placeholder="' . $lang['Harmonica'] . '">
' . $lang['Harmonium'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Harmonium']]) . 'name="Harmonium" placeholder="' . $lang['Harmonium'] . '">
</th>
<th>
' . $lang['Harp'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Harpe']]) . 'name="Harp" placeholder="' . $lang['Harp'] . '">
' . $lang['Horn in C 1'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Horn i C 1']]) . 'name="HorninC1" placeholder="' . $lang['Horn in C 1'] . '">
' . $lang['Horn in C 2'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Horn i C 2']]) . 'name="HorninC2" placeholder="' . $lang['Horn in C 2'] . '">
' . $lang['Horn in D 1'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Horn i D 1']]) . 'name="HorninD1" placeholder="' . $lang['Horn in D 1'] . '">
' . $lang['Horn in D 2'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Horn i D 2']]) . 'name="HorninD2" placeholder="' . $lang['Horn in D 2'] . '">
' . $lang['Horn in Eb 1'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Horn i Eb 1']]) . 'name="HorninEb1" placeholder="' . $lang['Horn in Eb 1'] . '">
' . $lang['Horn in Eb 2'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Horn i Eb 2']]) . 'name="HorninEb2" placeholder="' . $lang['Horn in Eb 2'] . '">
' . $lang['Horn in F 1'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Horn i F 1']]) . 'name="HorninF1" placeholder="' . $lang['Horn in F 1'] . '">
' . $lang['Horn in F 2'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Horn i F 2']]) . 'name="HorninF2" placeholder="' . $lang['Horn in F 2'] . '">
' . $lang['Horn in F 3'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Horn i F 3']]) . 'name="HorninF3" placeholder="' . $lang['Horn in F 3'] . '">
' . $lang['Horn in F 4'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Horn i F 4']]) . 'name="HorninF4" placeholder="' . $lang['Horn in F 4'] . '">
</th>
<th>
' . $lang['Clarinet 1 in A'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Klarinett 1 i A']]) . 'name="Clarinet1Ia" placeholder="' . $lang['Clarinet 1 in A'] . '">
' . $lang['Clarinet 1 in Bb'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Klarinett 1 i Bb']]) . 'name="Clarinet1inBb" placeholder="' . $lang['Clarinet 1 in Bb'] . '">
' . $lang['Clarinet 1 in C'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Klarinett 1 i C']]) . 'name="Clarinet1Ic" placeholder="' . $lang['Clarinet 1 in C'] . '">
' . $lang['Clarinet 2 in A'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Klarinett 2 i A']]) . 'name="Clarinet2thea" placeholder="' . $lang['Clarinet 2 in A'] . '">
' . $lang['Clarinet 2 in Bb'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Klarinett 2 i Bb']]) . 'name="Clarinet2inBb" placeholder="' . $lang['Clarinet 2 in Bb'] . '">
' . $lang['Clarinet 2 in C'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Klarinett 2 i C']]) . 'name="Clarinet2Ic" placeholder="' . $lang['Clarinet 2 in C'] . '">
' . $lang['Clarinet 3 in A'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Klarinett 3 i A']]) . 'name="Clarinet3thea" placeholder="' . $lang['Clarinet 3 in A'] . '">
' . $lang['Clarinet 3 in Bb'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Klarinett 3 i Bb']]) . 'name="Clarinet3inBb" placeholder="' . $lang['Clarinet 3 in Bb'] . '">
' . $lang['Keyboard instrument'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Klaver']]) . 'name="Keyboardinstrument" placeholder="' . $lang['Keyboard instrument'] . '">
' . $lang['Chime'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Klokkespill']]) . 'name="Chime" placeholder="' . $lang['Chime'] . '">
</th>
<th>
' . $lang['Double Bass'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Kontrabass']]) . 'name="DoubleBass" placeholder="' . $lang['Double Bass'] . '">
' . $lang['Contrabassoon'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Kontrafagott']]) . 'name="Contrabassoon" placeholder="' . $lang['Contrabassoon'] . '">
' . $lang['Cornet in A 1'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Kornett i A 1']]) . 'name="Cornetthea1" placeholder="' . $lang['Cornet in A 1'] . '">
' . $lang['Cornet in A 2'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Kornett i A 2']]) . 'name="CornetIa2" placeholder="' . $lang['Cornet in A 2'] . '">
' . $lang['Cornet in Bb 1'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Kornett i Bb 1']]) . 'name="CornetinBb1" placeholder="' . $lang['Cornet in Bb 1'] . '">
' . $lang['Cornet in Bb 2'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Kornett i Bb 2']]) . 'name="CornetinBb2" placeholder="' . $lang['Cornet in Bb 2'] . '">
' . $lang['Cowbell'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Kubjelle']]) . 'name="Cowbell" placeholder="' . $lang['Cowbell'] . '">
' . $lang['Mandolin 1'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Mandolin 1']]) . 'name="Mandolin1" placeholder="' . $lang['Mandolin 1'] . '">
' . $lang['Oboe 1'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Obo 1']]) . 'name="Oboe1" placeholder="' . $lang['Oboe 1'] . '">
' . $lang['Oboe 2'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Obo 2']]) . 'name="Oboe2" placeholder="' . $lang['Oboe 2'] . '">
</th>
<th>
' . $lang['Obo Obligate'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Obo Obligat']]) . 'name="OboObligate" placeholder="' . $lang['Obo Obligate'] . '">
' . $lang['Timpani 1 or 2'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Pauker 1-2 stk']]) . 'name="Timpani1or2" placeholder="' . $lang['Timpani 1 or 2'] . '">
' . $lang['Timpani 3 or More'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Pauker 3 eller fler']]) . 'name="Timpani3orMore" placeholder="' . $lang['Timpani 3 or More'] . '">
' . $lang['Piccolo (possibly as One of Flute Voices)'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Piccolo (muligens som en av fløytestemmene)']]) . 'name="Piccolo(possiblyasOneofFluteVoices)" placeholder="' . $lang['Piccolo (possibly as One of Flute Voices)'] . '">
' . $lang['Snare'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Skarptromme']]) . 'name="Snare" placeholder="' . $lang['Snare'] . '">
' . $lang['Percussion'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Slagverk']]) . 'name="Percussion" placeholder="' . $lang['Percussion'] . '">
' . $lang['Soprano Saxophone'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Sopran-saksofon']]) . 'name="SopranoSaxophone" placeholder="' . $lang['Soprano Saxophone'] . '">
' . $lang['Bass Drum'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Stortromme']]) . 'name="BassDrum" placeholder="' . $lang['Bass Drum'] . '">
' . $lang['Tambour'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Tamburtromme']]) . 'name="Tambour" placeholder="' . $lang['Tambour'] . '">
' . $lang['Tenor Banjo'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Tenorbanjo']]) . 'name="TenorBanjo" placeholder="' . $lang['Tenor Banjo'] . '">
</th>
<th>
' . $lang['Tenor Saxophone in Bb 1'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Tenor-saksofon i Bb 1']]) . 'name="TenorSaxophoneinBb1" placeholder="' . $lang['Tenor Saxophone in Bb 1'] . '">
' . $lang['Tenor Saxophone in Bb 2'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Tenor-saksofon i Bb 2']]) . 'name="TenorSaxophoneinBb2" placeholder="' . $lang['Tenor Saxophone in Bb 2'] . '">
' . $lang['Tenor Saxophone in Bb 3'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Tenor-saksofon i Bb 3']]) . 'name="TenorSaxophoneinBb3" placeholder="' . $lang['Tenor Saxophone in Bb 3'] . '">
' . $lang['Tenor Saxophone in Bb 4'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Tenor-saksofon i Bb 4']]) . 'name="TenorSaxophoneinBb4" placeholder="' . $lang['Tenor Saxophone in Bb 4'] . '">
' . $lang['Tenor Saxophone in C (melody)'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Tenor-saksofon i C (melodi)']]) . 'name="TenorSaxophoneinC(melody)" placeholder="' . $lang['Tenor Saxophone in C (melody)'] . '">
' . $lang['Timbales'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Timbaler']]) . 'name="Timbales" placeholder="' . $lang['Timbales'] . '">
' . $lang['Tom Tom'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Tom tom']]) . 'name="TomTom" placeholder="' . $lang['Tom Tom'] . '">
' . $lang['Accordion / Bandoneon'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Trekkspill/Bandoneon']]) . 'name="Accordion/Bandoneon" placeholder="' . $lang['Accordion / Bandoneon'] . '">
' . $lang['Triangle'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Triangel']]) . 'name="Triangle" placeholder="' . $lang['Triangle'] . '">
</th>
<th>
' . $lang['Trombone 1'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Trombone 1']]) . 'name="Trombone1" placeholder="' . $lang['Trombone 1'] . '">
' . $lang['Trombone 2'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Trombone 2']]) . 'name="Trombone2" placeholder="' . $lang['Trombone 2'] . '">
' . $lang['Trombone 3'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Trombone 3']]) . 'name="Trombone3" placeholder="' . $lang['Trombone 3'] . '">
' . $lang['Trumpet in A 1'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Trompet i A 1']]) . 'name="Trumpetina1" placeholder="' . $lang['Trumpet in A 1'] . '">
' . $lang['Trumpet in A 2'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Trompet i A 2']]) . 'name="Trumpetina2" placeholder="' . $lang['Trumpet in A 2'] . '">
' . $lang['Trumpet in A Obligate'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Trompet i A obligat']]) . 'name="TrumpetinaObligate" placeholder="' . $lang['Trumpet in A Obligate'] . '">
' . $lang['Trumpet in Bb 1'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Trompet i Bb 1']]) . 'name="TrumpetinBb1" placeholder="' . $lang['Trumpet in Bb 1'] . '">
' . $lang['Trumpet in Bb 2'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Trompet i Bb 2']]) . 'name="TrumpetinBb2" placeholder="' . $lang['Trumpet in Bb 2'] . '">
' . $lang['Trumpet in Bb 3'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Trompet i Bb 3']]) . 'name="TrumpetinBb3" placeholder="' . $lang['Trumpet in Bb 3'] . '">
' . $lang['Trumpet in Bb 4'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Trompet i Bb 4']]) . 'name="TrumpetinBb4" placeholder="' . $lang['Trumpet in Bb 4'] . '">
</th>
<th>
' . $lang['Trumpet in Bb Obligate'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Trompet i Bb obligat']]) . 'name="TrumpetinBbObligate" placeholder="' . $lang['Trumpet in Bb Obligate'] . '">
' . $lang['Trumpet in C 1'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Trompet i C 1']]) . 'name="TrumpetinC1" placeholder="' . $lang['Trumpet in C 1'] . '">
' . $lang['Trumpet in C2'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Trompet i C 2']]) . 'name="TrumpetinC2" placeholder="' . $lang['Trumpet in C2'] . '">
' . $lang['Trumpet F 1'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Trompet i F 1']]) . 'name="TrumpetF1" placeholder="' . $lang['Trumpet F 1'] . '">
' . $lang['Trumpet F 2'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Trompet i F 2']]) . 'name="TrumpetF2" placeholder="' . $lang['Trumpet F 2'] . '">
' . $lang['Tuba'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Tuba']]) . 'name="Tuba" placeholder="' . $lang['Tuba'] . '">
' . $lang['Tuba-ophicléide'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Tuba-Ophicléide']]) . 'name="Tuba-ophicléide" placeholder="' . $lang['Tuba-ophicléide'] . '">
' . $lang['Vibraphone'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Vibrafon']]) . 'name="Vibraphone" placeholder="' . $lang['Vibraphone'] . '">
' . $lang['Xylophone'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Xylofon']]) . 'name="Xylophone" placeholder="' . $lang['Xylophone'] . '">
</th>
</tr>
</thead>
</table>
</tr>
</tbody>
</table>';

                if (userAccess() == '1')
                {
                    echo '<button type="submit" name="Edit">Edit</button><br><br><button name="Delete">Delete</button></form></div>';
                }
            }
        }
    }
    echo '<div class="form"><br><form><button type="submit">⮌ Back</button></form></div>';
}

function retrieveSheet($noteID)
{
    include 'dbh.inc.php';
    include 'languageSwitcher.php';
    include '../../functions/filesLogic.php';
    $noteID = mysqli_real_escape_string($conn, @$_POST['noteID']);
    if ($noteID > 0)
    {
        include 'sqlCharts.php';
        $sql = "SELECT * FROM notedata WHERE notedata.noteID = '$noteID'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0)
        {
            echo "<br><b> $result->num_rows" . '. ' . $lang['Result found'] . "</b>";
            // output data of each row
            while ($row = $result->fetch_assoc())
            {
                echo '<div class="form">
<form method="POST">
<b>
<table>
<tbody>
<tr>
' . $lang['Edit Sheet'] . '
<td><input hidden value="' . $row[$columnSqlNote['noteID']] . '" name="noteID" ">
' . $lang['Piece name'] . '<input value="' . $row[$columnSqlNote['Navn på stykket']] . '" type="text" maxlength="255" name="Piecename" placeholder="' . $lang['Piece name'] . '">
' . $lang['Other name'] . '<input value="' . $row[$columnSqlNote['Annet navn på stykket']] . '" type="text" maxlength="255" name="OtherName" placeholder="' . $lang['Other name'] . '">
' . $lang['Composer'] . '<input value="' . $row[$columnSqlNote['Komponist for musikken']] . '" type="text" maxlength="255" name="Composer" placeholder="' . $lang['Composer'] . '">
' . $lang['Publisher catalogue number'] . '<input value="' . $row[$columnSqlNote['Noteutgivers katalognr']] . '" type="text" maxlength="20" name="Publishercataloguenumber" placeholder="' . $lang['Publisher catalogue number'] . '">
' . $lang['Genre'] . '<select name="Genre" placeholder="' . $lang['Genre'] . '"> ';
                dropdownSearchGenre($row[$columnSqlNote['Sjanger']]);
                echo '
' . $lang['Lyricist'] . '<input value="' . $row[$columnSqlNote['Tekstforfatter']] . '" type="text" maxlength="255" name="Lyricist" placeholder="' . $lang['Lyricist'] . '">
' . $lang['Opus number'] . '<input value="' . $row[$columnSqlNote['Opus nr']] . '" type="text" name="OpusNumber" placeholder="' . $lang['Opus number'] . '">
</td><td>
' . $lang['Arranger'] . '<input value="' . $row[$columnSqlNote['Arrangert av']] . '" type="text" maxlength="255" name="Arranger" placeholder="' . $lang['Arranger'] . '">
' . $lang['Ensemble type'] . '<select name="EnsembleType" placeholder="' . $lang['Ensemble type'] . '"> ';
                dropdownSearchEnsembletype($row[$columnSqlNote['Type arrangement notedata']]);
                echo '
' . $lang['Ancestry'] . '<select value="' . $row[$columnSqlNote['Avstamning']] . '"type="text" name="Ancestry" placeholder="' . $lang['Ancestry'] . '">';
                dropdownSearchAncestry($row[$columnSqlNote['Avstamning']]);
                echo '
' . $lang['Country of origin'] . '<select name="CountryOfOrigin" placeholder="' . $lang['Country of origin'] . '">';
                dropdownSearchOrgin($row[$columnSqlNote['Opprinnelsesland']]);
                echo '
' . $lang['Movement'] . '<select "type="text" name="Movement" placeholder="' . $lang['Movement'] . '">';
                dropdownSearchMovement($row[$columnSqlNote['Type stykke']]);
                echo '
' . $lang['Key'] . '<input value="' . $row[$columnSqlNote['Dur']] . '"type="text" maxlength="10" name="Key" placeholder="' . $lang['Key'] . '">
</td><td>
' . $lang['Solo instrument'] . '<select name="SoloInstrument" placeholder="' . $lang['Solo instrument'] . '">';
                dropdownSearchInstrument($row[$columnSqlNote['Soloinstrument notedata']]);
                echo '
' . $lang['Duration'] . " Currently set [" . timeFormater($row[$columnSqlNote['Spilletid']]) . '] <input value="' . timeFormater($row[$columnSqlNote['Spilletid']]) . '" type="time" maxlength="11" step="1" min="00:00:00" max="99:99:99" name="Duration" placeholder="' . $lang['Duration'] . '"> 
' . $lang['Released'] . " [" . dateFormater($row[$columnSqlNote['Utgivelsesdato']]) . ']<input value="' . dateFormater($row[$columnSqlNote['Utgivelsesdato']]) . '" oninput="this.value=this.value.slice(0,this.maxLength)" pattern="\d*" type="number" min="1900" max="2099" step="1" maxlength="4" name="Released" placeholder="' . $lang['Released'] . '">
' . $lang['Scores Available'] . '<input type="checkbox"' . checkbox($row[$columnSqlNote['Partitur finnes']]) . ' name="ScoresAvailable " placeholder="' . $lang['Scores Available'] . '">
' . $lang['Soloist'] . '<input type="checkbox"' . checkbox($row[$columnSqlNote['Solist']]) . ' name="Soloist" placeholder="' . $lang['Soloist'] . '">
' . $lang['Vocal'] . '<input type="checkbox"' . checkbox($row[$columnSqlNote['Sang']]) . ' name="Vocal" placeholder="' . $lang['Vocal'] . '">
' . $lang['Chord names'] . '<input type="checkbox"' . checkbox($row[$columnSqlNote['Akkorder er angitt']]) . ' name="Chordnames" placeholder="' . $lang['Chord names'] . '">
<td>
' /* . $lang['Mp3']*/ . '<input hidden value="' . $row[$columnSqlNote['mp3']] . '" type="text" name="Mp3" placeholder="' . $lang['Mp3'] . '">
' . $lang['PDF'] . '<input value="' . checkbox($row[$columnSqlNote['PDF']]) . '" name="PDF" placeholder="' . $lang['PDF'] . '">
' . $lang['Physical location'] . '<select name="PhysicalLocation" placeholder="' . $lang['Physical location'] . '">';
                dropdownSearchLocation($row[$columnSqlNote['Lagringssted notedata']]);
                echo '
' . $lang['Link to music sample'] . '<input value="' . str_replace("#", "", $row[$columnSqlNote['Link til lydprøve']]) . '"type="text" name="Link" placeholder="' . $lang['Link to music sample'] . '">
' . $lang['Please note'] . '<input value="' . $row[$columnSqlNote['Obs']] . '" name="PleaseNote" placeholder="' . $lang['Please note'] . '">
</td><br>
* ' . $lang['Optional'] . '
<table>
*  ' . $lang['Instruments'] . '
<thead>
<tr>
<th>
' . $lang['Alt Saxophone in Eb 1'] . '<br><input type="checkbox" ' . checkbox($row[$columnSqlNote['Alt-saksofon i Eb 1']]) . 'name="AltSaxophoneinEb1" placeholder="' . $lang['Alt Saxophone in Eb 1'] . '">
' . $lang['Alt Saxophone in Eb 2'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Alt-saksofon i Eb 2']]) . 'name="AltSaxophoneinEb2" placeholder="' . $lang['Alt Saxophone in Eb 2'] . '">
' . $lang['Alt Saxophone in Eb 3'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Alt-saksofon i Eb 3']]) . 'name="AltSaxophoneinEb3" placeholder="' . $lang['Alt Saxophone in Eb 3'] . '">
' . $lang['Banjo'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Banjo']]) . 'name="Banjo" placeholder="' . $lang['Banjo'] . '">
' . $lang['Baritone-saxophone in Eb'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Bariton-Saxofon i Eb']]) . 'name="Baritone-saxophoneinEb" placeholder="' . $lang['Baritone-saxophone in Eb'] . '">
' . $lang['Bass Clarinet (and or Clarinet in Eb)'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Bassklarinett (og eller klarinett i Eb)']]) . 'name="BassClarinet(andorClarinetinEb)" placeholder="' . $lang['Bass Clarinet (and or Clarinet in Eb)'] . '">
' . $lang['Bass Trombone'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Bass-trombone']]) . 'name="BassTrombone" placeholder="' . $lang['Bass Trombone'] . '">
' . $lang['Viola'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Bratsj']]) . 'name="Viola" placeholder="' . $lang['Viola'] . '">
' . $lang['Castanets'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Castagnetter']]) . 'name="Castanets" placeholder="' . $lang['Castanets'] . '">
' . $lang['Celesta'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Celesta']]) . 'name="Celesta" placeholder="' . $lang['Celesta'] . '">
</th>
<th>
' . $lang['Cello 1'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Cello 1']]) . 'name="Cello1" placeholder="' . $lang['Cello 1'] . '">
' . $lang['Cello 2'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Cello 2']]) . 'name="Cello2" placeholder="' . $lang['Cello 2'] . '">
' . $lang['Cello Obbligato'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Cello obligato']]) . 'name="CelloObbligato" placeholder="' . $lang['Cello Obbligato'] . '">
' . $lang['Chimes / Tubular Bells'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Chimes/tubular bells']]) . 'name="Chimes/TubularBells" placeholder="' . $lang['Chimes / Tubular Bells'] . '">
' . $lang['Cymbals'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Cymbaler']]) . 'name="Cymbals" placeholder="' . $lang['Cymbals'] . '">
' . $lang['Sleigh Bells'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Dombjeller']]) . 'name="SleighBells" placeholder="' . $lang['Sleigh Bells'] . '">
' . $lang['English Horn'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Engelsk horn']]) . 'name="EnglishHorn" placeholder="' . $lang['English Horn'] . '">
' . $lang['Euphonium'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Eufonium']]) . 'name="Euphonium" placeholder="' . $lang['Euphonium'] . '">
' . $lang['Bassoon 1'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Fagott 1']]) . 'name="Bassoon1" placeholder="' . $lang['Bassoon 1'] . '">
' . $lang['Bassoon 2'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Fagott 2']]) . 'name="Bassoon2" placeholder="' . $lang['Bassoon 2'] . '">
</th>
<th>
' . $lang['Violin 1'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Fiolin 1']]) . 'name="Violin1" placeholder="' . $lang['Violin 1'] . '">
' . $lang['Violin 2'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Fiolin 2']]) . 'name="Violin2" placeholder="' . $lang['Violin 2'] . '">
' . $lang['Violin 3'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Fiolin 3']]) . 'name="Violin3" placeholder="' . $lang['Violin 3'] . '">
' . $lang['Violin Obligate'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Fiolin obligat']]) . 'name="ViolinObligate" placeholder="' . $lang['Violin Obligate'] . '">
' . $lang['Flute 1'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Fløyte 1']]) . 'name="Flute1" placeholder="' . $lang['Flute 1'] . '">
' . $lang['Flute 2'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Fløyte 2']]) . 'name="Flute2" placeholder="' . $lang['Flute 2'] . '">
' . $lang['Flute 3'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Fløyte 3']]) . 'name="Flute3" placeholder="' . $lang['Flute 3'] . '">
' . $lang['Guitar'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Gitar']]) . 'name="Guitar" placeholder="' . $lang['Guitar'] . '">
' . $lang['Harmonica'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Harmonika']]) . 'name="Harmonica" placeholder="' . $lang['Harmonica'] . '">
' . $lang['Harmonium'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Harmonium']]) . 'name="Harmonium" placeholder="' . $lang['Harmonium'] . '">
</th>
<th>
' . $lang['Harp'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Harpe']]) . 'name="Harp" placeholder="' . $lang['Harp'] . '">
' . $lang['Horn in C 1'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Horn i C 1']]) . 'name="HorninC1" placeholder="' . $lang['Horn in C 1'] . '">
' . $lang['Horn in C 2'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Horn i C 2']]) . 'name="HorninC2" placeholder="' . $lang['Horn in C 2'] . '">
' . $lang['Horn in D 1'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Horn i D 1']]) . 'name="HorninD1" placeholder="' . $lang['Horn in D 1'] . '">
' . $lang['Horn in D 2'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Horn i D 2']]) . 'name="HorninD2" placeholder="' . $lang['Horn in D 2'] . '">
' . $lang['Horn in Eb 1'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Horn i Eb 1']]) . 'name="HorninEb1" placeholder="' . $lang['Horn in Eb 1'] . '">
' . $lang['Horn in Eb 2'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Horn i Eb 2']]) . 'name="HorninEb2" placeholder="' . $lang['Horn in Eb 2'] . '">
' . $lang['Horn in F 1'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Horn i F 1']]) . 'name="HorninF1" placeholder="' . $lang['Horn in F 1'] . '">
' . $lang['Horn in F 2'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Horn i F 2']]) . 'name="HorninF2" placeholder="' . $lang['Horn in F 2'] . '">
' . $lang['Horn in F 3'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Horn i F 3']]) . 'name="HorninF3" placeholder="' . $lang['Horn in F 3'] . '">
' . $lang['Horn in F 4'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Horn i F 4']]) . 'name="HorninF4" placeholder="' . $lang['Horn in F 4'] . '">
</th>
<th>
' . $lang['Clarinet 1 in A'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Klarinett 1 i A']]) . 'name="Clarinet1Ia" placeholder="' . $lang['Clarinet 1 in A'] . '">
' . $lang['Clarinet 1 in Bb'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Klarinett 1 i Bb']]) . 'name="Clarinet1inBb" placeholder="' . $lang['Clarinet 1 in Bb'] . '">
' . $lang['Clarinet 1 in C'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Klarinett 1 i C']]) . 'name="Clarinet1Ic" placeholder="' . $lang['Clarinet 1 in C'] . '">
' . $lang['Clarinet 2 in A'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Klarinett 2 i A']]) . 'name="Clarinet2thea" placeholder="' . $lang['Clarinet 2 in A'] . '">
' . $lang['Clarinet 2 in Bb'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Klarinett 2 i Bb']]) . 'name="Clarinet2inBb" placeholder="' . $lang['Clarinet 2 in Bb'] . '">
' . $lang['Clarinet 2 in C'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Klarinett 2 i C']]) . 'name="Clarinet2Ic" placeholder="' . $lang['Clarinet 2 in C'] . '">
' . $lang['Clarinet 3 in A'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Klarinett 3 i A']]) . 'name="Clarinet3thea" placeholder="' . $lang['Clarinet 3 in A'] . '">
' . $lang['Clarinet 3 in Bb'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Klarinett 3 i Bb']]) . 'name="Clarinet3inBb" placeholder="' . $lang['Clarinet 3 in Bb'] . '">
' . $lang['Keyboard instrument'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Klaver']]) . 'name="Keyboardinstrument" placeholder="' . $lang['Keyboard instrument'] . '">
' . $lang['Chime'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Klokkespill']]) . 'name="Chime" placeholder="' . $lang['Chime'] . '">
</th>
<th>
' . $lang['Double Bass'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Kontrabass']]) . 'name="DoubleBass" placeholder="' . $lang['Double Bass'] . '">
' . $lang['Contrabassoon'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Kontrafagott']]) . 'name="Contrabassoon" placeholder="' . $lang['Contrabassoon'] . '">
' . $lang['Cornet in A 1'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Kornett i A 1']]) . 'name="Cornetthea1" placeholder="' . $lang['Cornet in A 1'] . '">
' . $lang['Cornet in A 2'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Kornett i A 2']]) . 'name="CornetIa2" placeholder="' . $lang['Cornet in A 2'] . '">
' . $lang['Cornet in Bb 1'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Kornett i Bb 1']]) . 'name="CornetinBb1" placeholder="' . $lang['Cornet in Bb 1'] . '">
' . $lang['Cornet in Bb 2'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Kornett i Bb 2']]) . 'name="CornetinBb2" placeholder="' . $lang['Cornet in Bb 2'] . '">
' . $lang['Cowbell'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Kubjelle']]) . 'name="Cowbell" placeholder="' . $lang['Cowbell'] . '">
' . $lang['Mandolin 1'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Mandolin 1']]) . 'name="Mandolin1" placeholder="' . $lang['Mandolin 1'] . '">
' . $lang['Oboe 1'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Obo 1']]) . 'name="Oboe1" placeholder="' . $lang['Oboe 1'] . '">
' . $lang['Oboe 2'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Obo 2']]) . 'name="Oboe2" placeholder="' . $lang['Oboe 2'] . '">
</th>
<th>
' . $lang['Obo Obligate'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Obo Obligat']]) . 'name="OboObligate" placeholder="' . $lang['Obo Obligate'] . '">
' . $lang['Timpani 1 or 2'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Pauker 1-2 stk']]) . 'name="Timpani1or2" placeholder="' . $lang['Timpani 1 or 2'] . '">
' . $lang['Timpani 3 or More'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Pauker 3 eller fler']]) . 'name="Timpani3orMore" placeholder="' . $lang['Timpani 3 or More'] . '">
' . $lang['Piccolo (possibly as One of Flute Voices)'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Piccolo (muligens som en av fløytestemmene)']]) . 'name="Piccolo(possiblyasOneofFluteVoices)" placeholder="' . $lang['Piccolo (possibly as One of Flute Voices)'] . '">
' . $lang['Snare'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Skarptromme']]) . 'name="Snare" placeholder="' . $lang['Snare'] . '">
' . $lang['Percussion'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Slagverk']]) . 'name="Percussion" placeholder="' . $lang['Percussion'] . '">
' . $lang['Soprano Saxophone'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Sopran-saksofon']]) . 'name="SopranoSaxophone" placeholder="' . $lang['Soprano Saxophone'] . '">
' . $lang['Bass Drum'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Stortromme']]) . 'name="BassDrum" placeholder="' . $lang['Bass Drum'] . '">
' . $lang['Tambour'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Tamburtromme']]) . 'name="Tambour" placeholder="' . $lang['Tambour'] . '">
' . $lang['Tenor Banjo'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Tenorbanjo']]) . 'name="TenorBanjo" placeholder="' . $lang['Tenor Banjo'] . '">
</th>
<th>
' . $lang['Tenor Saxophone in Bb 1'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Tenor-saksofon i Bb 1']]) . 'name="TenorSaxophoneinBb1" placeholder="' . $lang['Tenor Saxophone in Bb 1'] . '">
' . $lang['Tenor Saxophone in Bb 2'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Tenor-saksofon i Bb 2']]) . 'name="TenorSaxophoneinBb2" placeholder="' . $lang['Tenor Saxophone in Bb 2'] . '">
' . $lang['Tenor Saxophone in Bb 3'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Tenor-saksofon i Bb 3']]) . 'name="TenorSaxophoneinBb3" placeholder="' . $lang['Tenor Saxophone in Bb 3'] . '">
' . $lang['Tenor Saxophone in Bb 4'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Tenor-saksofon i Bb 4']]) . 'name="TenorSaxophoneinBb4" placeholder="' . $lang['Tenor Saxophone in Bb 4'] . '">
' . $lang['Tenor Saxophone in C (melody)'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Tenor-saksofon i C (melodi)']]) . 'name="TenorSaxophoneinC(melody)" placeholder="' . $lang['Tenor Saxophone in C (melody)'] . '">
' . $lang['Timbales'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Timbaler']]) . 'name="Timbales" placeholder="' . $lang['Timbales'] . '">
' . $lang['Tom Tom'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Tom tom']]) . 'name="TomTom" placeholder="' . $lang['Tom Tom'] . '">
' . $lang['Accordion / Bandoneon'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Trekkspill/Bandoneon']]) . 'name="Accordion/Bandoneon" placeholder="' . $lang['Accordion / Bandoneon'] . '">
' . $lang['Triangle'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Triangel']]) . 'name="Triangle" placeholder="' . $lang['Triangle'] . '">
</th>
<th>
' . $lang['Trombone 1'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Trombone 1']]) . 'name="Trombone1" placeholder="' . $lang['Trombone 1'] . '">
' . $lang['Trombone 2'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Trombone 2']]) . 'name="Trombone2" placeholder="' . $lang['Trombone 2'] . '">
' . $lang['Trombone 3'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Trombone 3']]) . 'name="Trombone3" placeholder="' . $lang['Trombone 3'] . '">
' . $lang['Trumpet in A 1'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Trompet i A 1']]) . 'name="Trumpetina1" placeholder="' . $lang['Trumpet in A 1'] . '">
' . $lang['Trumpet in A 2'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Trompet i A 2']]) . 'name="Trumpetina2" placeholder="' . $lang['Trumpet in A 2'] . '">
' . $lang['Trumpet in A Obligate'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Trompet i A obligat']]) . 'name="TrumpetinaObligate" placeholder="' . $lang['Trumpet in A Obligate'] . '">
' . $lang['Trumpet in Bb 1'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Trompet i Bb 1']]) . 'name="TrumpetinBb1" placeholder="' . $lang['Trumpet in Bb 1'] . '">
' . $lang['Trumpet in Bb 2'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Trompet i Bb 2']]) . 'name="TrumpetinBb2" placeholder="' . $lang['Trumpet in Bb 2'] . '">
' . $lang['Trumpet in Bb 3'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Trompet i Bb 3']]) . 'name="TrumpetinBb3" placeholder="' . $lang['Trumpet in Bb 3'] . '">
' . $lang['Trumpet in Bb 4'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Trompet i Bb 4']]) . 'name="TrumpetinBb4" placeholder="' . $lang['Trumpet in Bb 4'] . '">
</th>
<th>
' . $lang['Trumpet in Bb Obligate'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Trompet i Bb obligat']]) . 'name="TrumpetinBbObligate" placeholder="' . $lang['Trumpet in Bb Obligate'] . '">
' . $lang['Trumpet in C 1'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Trompet i C 1']]) . 'name="TrumpetinC1" placeholder="' . $lang['Trumpet in C 1'] . '">
' . $lang['Trumpet in C2'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Trompet i C 2']]) . 'name="TrumpetinC2" placeholder="' . $lang['Trumpet in C2'] . '">
' . $lang['Trumpet F 1'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Trompet i F 1']]) . 'name="TrumpetF1" placeholder="' . $lang['Trumpet F 1'] . '">
' . $lang['Trumpet F 2'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Trompet i F 2']]) . 'name="TrumpetF2" placeholder="' . $lang['Trumpet F 2'] . '">
' . $lang['Tuba'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Tuba']]) . 'name="Tuba" placeholder="' . $lang['Tuba'] . '">
' . $lang['Tuba-ophicléide'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Tuba-Ophicléide']]) . 'name="Tuba-ophicléide" placeholder="' . $lang['Tuba-ophicléide'] . '">
' . $lang['Vibraphone'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Vibrafon']]) . 'name="Vibraphone" placeholder="' . $lang['Vibraphone'] . '">
' . $lang['Xylophone'] . '<br><input type="checkbox"' . checkbox($row[$columnSqlNote['Xylofon']]) . 'name="Xylophone" placeholder="' . $lang['Xylophone'] . '">
</th>
</tr>
</thead>
</table>
</tr>
</tbody>
</table>
<button name="editSheet">Edit</button></b><br><br>
<button type="submit">⮌ Back</button>
</form>
</div>';
            }
        }
    }
    else
    {
        echo '<div class="form">
        <form method="post" enctype="multipart/form-data"
<b>
<table>
<tbody>
<tr>
<td> <input hidden value="0" name="noteID">
' . $lang['Piece name'] . '<input type="text" maxlength="255" name="Piecename" placeholder="' . $lang['Piece name'] . '">
' . $lang['Other name'] . '<input type="text" maxlength="255" name="OtherName" placeholder="' . $lang['Other name'] . '">
' . $lang['Composer'] . '<input type="text" maxlength="255" name="Composer" placeholder="' . $lang['Composer'] . '">
' . $lang['Publisher catalogue number'] . '<br><input type="text" maxlength="20" name="Publishercataloguenumber" placeholder="' . $lang['Publisher catalogue number'] . '">
' . $lang['Genre'] . '<select name="Genre" placeholder="' . $lang['Genre'] . '">';
        dropdownSearchGenre(0);
        echo '
' . $lang['Lyricist'] . '<input type="text" maxlength="255" name="Lyricist" placeholder="' . $lang['Lyricist'] . '">
' . $lang['Opus number'] . '<input type="text" maxlength="50" name="OpusNumber" placeholder="' . $lang['Opus number'] . '">
</td>
<td>
' . $lang['Arranger'] . '<input name="Arranger" maxlength="255" placeholder="' . $lang['Arranger'] . '">
' . $lang['Ensemble type'] . '<select name="EnsembleType" placeholder="' . $lang['Ensemble type'] . '">';
        dropdownSearchEnsembletype(0);
        echo '
' . $lang['Ancestry'] . '<br><select name="Ancestry" placeholder="' . $lang['Ancestry'] . '">';
        dropdownSearchAncestry(0);
        echo '
' . $lang['Country of origin'] . '<br><select name="CountryOfOrigin" placeholder="' . $lang['Country of origin'] . '">';
        dropdownSearchOrgin(0);
        echo '
' . $lang['Movement'] . '<select name="Movement" placeholder="' . $lang['Movement'] . '">';
        dropdownSearchMovement(0);
        echo '
' . $lang['Key'] . '<input type="text" maxlength="10" name="Key" placeholder="' . $lang['Key'] . '">
</td>
<td>
' . $lang['Solo instrument'] . '<br><select name="SoloInstrument" placeholder="' . $lang['Solo instrument'] . '">';
        dropdownSearchInstrument(0);
        echo '
' . $lang['Duration'] . '<br><input type="time" step="1" min="00:00:00" max="99:99:99" name="Duration" placeholder="' . $lang['Duration'] . '">
' . $lang['Released'] . '<br><input value="1950" oninput="this.value=this.value.slice(0,this.maxLength)" pattern="\d*" type="number" min="1000" max="2099" step="1" maxlength="4" name="Released" placeholder="' . $lang['Released'] . '">
' . $lang['Scores Available'] . '<input type="checkbox" value="1" name="Scoresavailable" placeholder="' . $lang['Scores Available'] . '">
' . $lang['Soloist'] . '<br><input type="checkbox" value="1" name="Soloist" placeholder="' . $lang['Soloist'] . '">
' . $lang['Vocal'] . '<input type="checkbox" value="1" name="Vocal" placeholder="' . $lang['Vocal'] . '">
' . $lang['Chord names'] . '<input type="checkbox" value="1" name="Chordnames" title="' . $lang['Chord names'] . '">
</td>
<td>
' . $lang['Mp3'] . '*<br>
<select hidden name="permission" "Viewing Permission:" required>
  <option value="0">Private</option>
  <option selected value="1">Public</option>
</select><br><input type="file" name="Mp3"><br>
' . $lang['PDF'] . '<br>
<select hidden name="permission" "Viewing Permission:" required>
  <option value="0">Private</option>
  <option selected value="1">Public</option>
</select><br><input type="file" name="PDF"><br>
' . $lang['Physical location'] . '<br><select name="PhysicalLocation" placeholder="' . $lang['Physical location'] . '">';
        dropdownSearchLocation(0);
        echo '
' . $lang['Link to music sample'] . '<br><input type="text" name="Link" placeholder="' . $lang['Link to music sample'] . '">
' . $lang['Please note'] . '* <br><input type="text" name="PleaseNote" placeholder="' . $lang['Please note'] . '"><br>
</td>
* ' . $lang['Optional'] . '
<table>
' . $lang['Instruments'] . '

<thead>
<tr>
<th>
' . $lang['Alt Saxophone in Eb 1'] . '<br><input type="checkbox" value="1" name="AltSaxophoneinEb1" placeholder="' . $lang['Alt Saxophone in Eb 1'] . '">
' . $lang['Alt Saxophone in Eb 2'] . '<br><input type="checkbox" value="1" name="AltSaxophoneinEb2" placeholder="' . $lang['Alt Saxophone in Eb 2'] . '">
' . $lang['Alt Saxophone in Eb 3'] . '<br><input type="checkbox" value="1" name="AltSaxophoneinEb3" placeholder="' . $lang['Alt Saxophone in Eb 3'] . '">
' . $lang['Banjo'] . '<br><input type="checkbox" value="1" name="Banjo" placeholder="' . $lang['Banjo'] . '">
' . $lang['Baritone-saxophone in Eb'] . '<br><input type="checkbox" value="1" name="Baritone-saxophoneinEb" placeholder="' . $lang['Baritone-saxophone in Eb'] . '">
' . $lang['Bass Clarinet (and or Clarinet in Eb)'] . '<br><input type="checkbox" value="1" name="BassClarinetandorClarinetinEb" placeholder="' . $lang['Bass Clarinet (and or Clarinet in Eb)'] . '">
' . $lang['Bass Trombone'] . '<br><input type="checkbox" value="1" name="BassTrombone" placeholder="' . $lang['Bass Trombone'] . '">
' . $lang['Viola'] . '<br><input type="checkbox" value="1" name="Viola" placeholder="' . $lang['Viola'] . '">
' . $lang['Castanets'] . '<br><input type="checkbox" value="1" name="Castanets" placeholder="' . $lang['Castanets'] . '">
' . $lang['Celesta'] . '<br><input type="checkbox" value="1" name="Celesta" placeholder="' . $lang['Celesta'] . '">
</th>
<th>
' . $lang['Cello 1'] . '<br><input type="checkbox" value="1" name="Cello1" placeholder="' . $lang['Cello 1'] . '">
' . $lang['Cello 2'] . '<br><input type="checkbox" value="1" name="Cello2" placeholder="' . $lang['Cello 2'] . '">
' . $lang['Cello Obbligato'] . '<br><input type="checkbox" value="1" name="CelloObbligato" placeholder="' . $lang['Cello Obbligato'] . '">
' . $lang['Chimes / Tubular Bells'] . '<br><input type="checkbox" value="1" name="ChimesTubularBells" placeholder="' . $lang['Chimes / Tubular Bells'] . '">
' . $lang['Cymbals'] . '<br><input type="checkbox" value="1" name="Cymbals" placeholder="' . $lang['Cymbals'] . '">
' . $lang['Sleigh Bells'] . '<br><input type="checkbox" value="1" name="SleighBells" placeholder="' . $lang['Sleigh Bells'] . '">
' . $lang['English Horn'] . '<br><input type="checkbox" value="1" name="EnglishHorn" placeholder="' . $lang['English Horn'] . '">
' . $lang['Euphonium'] . '<br><input type="checkbox" value="1" name="Euphonium" placeholder="' . $lang['Euphonium'] . '">
' . $lang['Bassoon 1'] . '<br><input type="checkbox" value="1" name="Bassoon1" placeholder="' . $lang['Bassoon 1'] . '">
' . $lang['Bassoon 2'] . '<br><input type="checkbox" value="1" name="Bassoon2" placeholder="' . $lang['Bassoon 2'] . '">
</th>
<th> ' . $lang['Violin 1'] . '<br><input type="checkbox" value="1" name="Violin1" placeholder="' . $lang['Violin 1'] . '">
' . $lang['Violin 2'] . '<br><input type="checkbox" value="1" name="Violin2" placeholder="' . $lang['Violin 2'] . '">
' . $lang['Violin 3'] . '<br><input type="checkbox" value="1" name="Violin3" placeholder="' . $lang['Violin 3'] . '">
' . $lang['Violin Obligate'] . '<br><input type="checkbox" value="1" name="ViolinObligate" placeholder="' . $lang['Violin Obligate'] . '">
' . $lang['Flute 1'] . '<br><input type="checkbox" value="1" name="Flute1" placeholder="' . $lang['Flute 1'] . '">
' . $lang['Flute 2'] . '<br><input type="checkbox" value="1" name="Flute2" placeholder="' . $lang['Flute 2'] . '">
' . $lang['Flute 3'] . '<br><input type="checkbox" value="1" name="Flute3" placeholder="' . $lang['Flute 3'] . '">
' . $lang['Guitar'] . '<br><input type="checkbox" value="1" name="Guitar" placeholder="' . $lang['Guitar'] . '">
' . $lang['Harmonica'] . '<br><input type="checkbox" value="1" name="Harmonica" placeholder="' . $lang['Harmonica'] . '">
' . $lang['Harmonium'] . '<br><input type="checkbox" value="1" name="Harmonium" placeholder="' . $lang['Harmonium'] . '">
</th>
<th>' . $lang['Harp'] . '<br><input type="checkbox" value="1" name="Harp" placeholder="' . $lang['Harp'] . '">
' . $lang['Horn in C 1'] . '<br><input type="checkbox" value="1" name="HorninC1" placeholder="' . $lang['Horn in C 1'] . '">
' . $lang['Horn in C 2'] . '<br><input type="checkbox" value="1" name="HorninC2" placeholder="' . $lang['Horn in C 2'] . '">
' . $lang['Horn in D 1'] . '<br><input type="checkbox" value="1" name="HorninD1" placeholder="' . $lang['Horn in D 1'] . '">
' . $lang['Horn in D 2'] . '<br><input type="checkbox" value="1" name="HorninD2" placeholder="' . $lang['Horn in D 2'] . '">
' . $lang['Horn in Eb 1'] . '<br><input type="checkbox" value="1" name="HorninEb1" placeholder="' . $lang['Horn in Eb 1'] . '">
' . $lang['Horn in Eb 2'] . '<br><input type="checkbox" value="1" name="HorninEb2" placeholder="' . $lang['Horn in Eb 2'] . '">
' . $lang['Horn in F 1'] . '<br><input type="checkbox" value="1" name="HorninF1" placeholder="' . $lang['Horn in F 1'] . '">
' . $lang['Horn in F 2'] . '<br><input type="checkbox" value="1" name="HorninF2" placeholder="' . $lang['Horn in F 2'] . '">
' . $lang['Horn in F 3'] . '<br><input type="checkbox" value="1" name="HorninF3" placeholder="' . $lang['Horn in F 3'] . '">
' . $lang['Horn in F 4'] . '<br><input type="checkbox" value="1" name="HorninF4" placeholder="' . $lang['Horn in F 4'] . '">
</th>
<th>
' . $lang['Clarinet 1 in A'] . '<br><input type="checkbox" value="1" name="Clarinet1inA" placeholder="' . $lang['Clarinet 1 in A'] . '">
' . $lang['Clarinet 1 in Bb'] . '<br><input type="checkbox" value="1" name="Clarinet1inBb" placeholder="' . $lang['Clarinet 1 in Bb'] . '">
' . $lang['Clarinet 1 in C'] . '<br><input type="checkbox" value="1" name="Clarinet1inC" placeholder="' . $lang['Clarinet 1 in C'] . '">
' . $lang['Clarinet 2 in A'] . '<br><input type="checkbox" value="1" name="Clarinet2inA" placeholder="' . $lang['Clarinet 2 in A'] . '">
' . $lang['Clarinet 2 in Bb'] . '<br><input type="checkbox" value="1" name="Clarinet2inBb" placeholder="' . $lang['Clarinet 2 in Bb'] . '">
' . $lang['Clarinet 2 in C'] . '<br><input type="checkbox" value="1" name="Clarinet2inC" placeholder="' . $lang['Clarinet 2 in C'] . '">
' . $lang['Clarinet 3 in A'] . '<br><input type="checkbox" value="1" name="Clarinet3thea" placeholder="' . $lang['Clarinet 3 in A'] . '">
' . $lang['Clarinet 3 in Bb'] . '<br><input type="checkbox" value="1" name="Clarinet3inBb" placeholder="' . $lang['Clarinet 3 in Bb'] . '">
' . $lang['Keyboard instrument'] . '<br><input type="checkbox" value="1" name="Keyboardinstrument" placeholder="' . $lang['Keyboard instrument'] . '">
' . $lang['Chime'] . '<br><input type="checkbox" value="1" name="Chime" placeholder="' . $lang['Chime'] . '">
</th>
<th>
' . $lang['Double Bass'] . '<br><input type="checkbox" value="1" name="DoubleBass" placeholder="' . $lang['Double Bass'] . '">
' . $lang['Contrabassoon'] . '<br><input type="checkbox" value="1" name="Contrabassoon" placeholder="' . $lang['Contrabassoon'] . '">
' . $lang['Cornet in A 1'] . '<br><input type="checkbox" value="1" name="Cornetthea1" placeholder="' . $lang['Cornet in A 1'] . '">
' . $lang['Cornet in A 2'] . '<br><input type="checkbox" value="1" name="CornetinA2" placeholder="' . $lang['Cornet in A 2'] . '">
' . $lang['Cornet in Bb 1'] . '<br><input type="checkbox" value="1" name="CornetinBb1" placeholder="' . $lang['Cornet in Bb 1'] . '">
' . $lang['Cornet in Bb 2'] . '<br><input type="checkbox" value="1" name="CornetinBb2" placeholder="' . $lang['Cornet in Bb 2'] . '">
' . $lang['Cowbell'] . '<br><input type="checkbox" value="1" name="Cowbell" placeholder="' . $lang['Cowbell'] . '">
' . $lang['Mandolin 1'] . '<br><input type="checkbox" value="1" name="Mandolin1" placeholder="' . $lang['Mandolin 1'] . '">
' . $lang['Oboe 1'] . '<br><input type="checkbox" value="1" name="Oboe1" placeholder="' . $lang['Oboe 1'] . '">
' . $lang['Oboe 2'] . '<br><input type="checkbox" value="1" name="Oboe2" placeholder="' . $lang['Oboe 2'] . '">
</th>
<th>' . $lang['Obo Obligate'] . '<br><input type="checkbox" value="1" name="OboObligate" placeholder="' . $lang['Obo Obligate'] . '">
' . $lang['Timpani 1 or 2'] . '<br><input type="checkbox" value="1" name="Timpani1or2" placeholder="' . $lang['Timpani 1 or 2'] . '">
' . $lang['Timpani 3 or More'] . '<br><input type="checkbox" value="1" name="Timpani3orMore" placeholder="' . $lang['Timpani 3 or More'] . '">
' . $lang['Piccolo (possibly as One of Flute Voices)'] . '<br><input type="checkbox" value="1" name="PiccolopossiblyasOneofFluteVoices" placeholder="' . $lang['Piccolo (possibly as One of Flute Voices)'] . '">
' . $lang['Snare'] . '<br><input type="checkbox" value="1" name="Snare" placeholder="' . $lang['Snare'] . '">
' . $lang['Percussion'] . '<br><input type="checkbox" value="1" name="Percussion" placeholder="' . $lang['Percussion'] . '">
' . $lang['Soprano Saxophone'] . '<br><input type="checkbox" value="1" name="SopranoSaxophone" placeholder="' . $lang['Soprano Saxophone'] . '">
' . $lang['Bass Drum'] . '<br><input type="checkbox" value="1" name="BassDrum" placeholder="' . $lang['Bass Drum'] . '">
' . $lang['Tambour'] . '<br><input type="checkbox" value="1" name="Tambour" placeholder="' . $lang['Tambour'] . '">
' . $lang['Tenor Banjo'] . '<br><input type="checkbox" value="1" name="TenorBanjo" placeholder="' . $lang['Tenor Banjo'] . '">
</th>
<th>' . $lang['Tenor Saxophone in Bb 1'] . '<br><input type="checkbox" value="1" name="TenorSaxophoneinBb1" placeholder="' . $lang['Tenor Saxophone in Bb 1'] . '">
' . $lang['Tenor Saxophone in Bb 2'] . '<br><input type="checkbox" value="1" name="TenorSaxophoneinBb2" placeholder="' . $lang['Tenor Saxophone in Bb 2'] . '">
' . $lang['Tenor Saxophone in Bb 3'] . '<br><input type="checkbox" value="1" name="TenorSaxophoneinBb3" placeholder="' . $lang['Tenor Saxophone in Bb 3'] . '">
' . $lang['Tenor Saxophone in Bb 4'] . '<br><input type="checkbox" value="1" name="TenorSaxophoneinBb4" placeholder="' . $lang['Tenor Saxophone in Bb 4'] . '">
' . $lang['Tenor Saxophone in C (melody)'] . '<br><input type="checkbox" value="1" name="TenorSaxophoneinCmelody" placeholder="' . $lang['Tenor Saxophone in C (melody)'] . '">
' . $lang['Timbales'] . '<br><input type="checkbox" value="1" name="Timbales" placeholder="' . $lang['Timbales'] . '">
' . $lang['Tom Tom'] . '<br><input type="checkbox" value="1" name="TomTom" placeholder="' . $lang['Tom Tom'] . '">
' . $lang['Accordion / Bandoneon'] . '<br><input type="checkbox" value="1" name="AccordionBandoneon" placeholder="' . $lang['Accordion / Bandoneon'] . '">
' . $lang['Triangle'] . '<br><input type="checkbox" value="1" name="Triangle" placeholder="' . $lang['Triangle'] . '">
</th>
<th>
' . $lang['Trombone 1'] . '<br><input type="checkbox" value="1" name="Trombone1" placeholder="' . $lang['Trombone 1'] . '">
' . $lang['Trombone 2'] . '<br><input type="checkbox" value="1" name="Trombone2" placeholder="' . $lang['Trombone 2'] . '">
' . $lang['Trombone 3'] . '<br><input type="checkbox" value="1" name="Trombone3" placeholder="' . $lang['Trombone 3'] . '">
' . $lang['Trumpet in A 1'] . '<br><input type="checkbox" value="1" name="Trumpetin A1" placeholder="' . $lang['Trumpet in A 1'] . '">
' . $lang['Trumpet in A 2'] . '<br><input type="checkbox" value="1" name="TrumpetinA2" placeholder="' . $lang['Trumpet in A 2'] . '">
' . $lang['Trumpet in A Obligate'] . '<br><input type="checkbox" value="1" name="TrumpetinaObligate" placeholder="' . $lang['Trumpet in A Obligate'] . '">
' . $lang['Trumpet in Bb 1'] . '<br><input type="checkbox" value="1" name="TrumpetinBb1" placeholder="' . $lang['Trumpet in Bb 1'] . '">
' . $lang['Trumpet in Bb 2'] . '<br><input type="checkbox" value="1" name="TrumpetinBb2" placeholder="' . $lang['Trumpet in Bb 2'] . '">
' . $lang['Trumpet in Bb 3'] . '<br><input type="checkbox" value="1" name="TrumpetinBb3" placeholder="' . $lang['Trumpet in Bb 3'] . '">
' . $lang['Trumpet in Bb 4'] . '<br><input type="checkbox" value="1" name="TrumpetinBb4" placeholder="' . $lang['Trumpet in Bb 4'] . '">
</th>
<th>
' . $lang['Trumpet in Bb Obligate'] . '<br><input type="checkbox" value="1" name="TrumpetinBbObligate" placeholder="' . $lang['Trumpet in Bb Obligate'] . '">
' . $lang['Trumpet in C 1'] . '<br><input type="checkbox" value="1" name="TrumpetinC1" placeholder="' . $lang['Trumpet in C 1'] . '">
' . $lang['Trumpet in C2'] . '<br><input type="checkbox" value="1" name="TrumpetinC2" placeholder="' . $lang['Trumpet in C2'] . '">
' . $lang['Trumpet F 1'] . '<br><input type="checkbox" value="1" name="TrumpetF1" placeholder="' . $lang['Trumpet F 1'] . '">
' . $lang['Trumpet F 2'] . '<br><input type="checkbox" value="1" name="TrumpetF2" placeholder="' . $lang['Trumpet F 2'] . '">
' . $lang['Tuba'] . '<br><input type="checkbox" value="1" name="Tuba" placeholder="' . $lang['Tuba'] . '">
' . $lang['Tuba-ophicléide'] . '<br><input type="checkbox" value="1" name="Tuba-ophicléide" placeholder="' . $lang['Tuba-ophicléide'] . '">
' . $lang['Vibraphone'] . '<br><input type="checkbox" value="1" name="Vibraphone" placeholder="' . $lang['Vibraphone'] . '">
' . $lang['Xylophone'] . '<br><input type="checkbox" value="1" name="Xylophone" placeholder="' . $lang['Xylophone'] . '">
</th>
</tr>
</thead>
</table>
</tr>
</tbody>
</table>
<button type="submit" name="submit" value="submit">Submit</button>
</b>
</form>
</div>';
    }

}
function timeFormater($string)
{
    include 'languageSwitcher.php';
    if (empty($string))
    {
        $string = "NOTSET";
    }
    ///htmlDateFormater  date("Y-m-d", strtotime($string))
    return $string;
    echo date("i:s", strtotime($string));
}
function dateFormater($string)
{
    if (empty($string))
    {
        $string = "NOTSET";
    }
    ///htmlDateFormater  date("Y-m-d", strtotime($string))
    return date("Y", strtotime($string));
    echo date("Y", strtotime($string));
}
function checkbox($string)
{
    if (empty($string))
    {
        $string = 'value="1"';
    }
    else
    {
        $string = 'checked value="1"';
        return $string;
    }
}
function dropdownSearchGenre($extraID)
{
    include 'languageSwitcher.php';
    if (empty($extraID))
    {
        $extraID = "0";
        echo '<option value="0">' . $lang['Genre'] . '</option>';
    }
    include 'dbh.inc.php';
    //Name of table columns
    $table = "sjanger";
    $columnSql['ID'] = "ID";
    $columnSql['Name'] = "Sjanger";
    $sql = "(SELECT * FROM $table WHERE ID = $extraID) UNION (SELECT * FROM $table WHERE 1)";
    $result = $conn->query($sql);
    if ($result->num_rows > 0)
    {
        while ($row = $result->fetch_assoc())
        {
            echo "<option value='" . $row[$columnSql['ID']] . "'>" . $row[$columnSql['Name']] . "</option>";
        }
        echo "</select>";
    }
}
function dropdownSearchEnsembleType($extraID)
{
    include 'languageSwitcher.php';
    if (empty($extraID))
    {
        $extraID = "0";
        echo '<option value="0">' . $lang['Ensemble type'] . '</option>';
    }
    include 'dbh.inc.php';
    $table = "`type arrangement`";
    $columnSql['ID'] = "ID";
    $columnSql['Name'] = "Orkester";
    $sql = "(SELECT * FROM $table WHERE ID = $extraID) UNION (SELECT * FROM $table WHERE 1)";
    $result = $conn->query($sql);
    if ($result->num_rows > 0)
    {
        while ($row = $result->fetch_assoc())
        {
            echo "<option value='" . $row[$columnSql['ID']] . "'>" . $row[$columnSql['Name']] . "</option>";
        }
        echo "</select>";
    }
}
function dropdownSearchAncestry($extraID)
{
    include 'languageSwitcher.php';
    if (empty($extraID))
    {
        //echo '<option value="0">'.$lang['Ancestry'].'</option>';
        echo '<option value="' . $_SESSION['userID'] . '">' . $_SESSION['userFirstName'] . ' ' . $_SESSION['userSurname'] . '</option>';
    }
    include 'dbh.inc.php';
    $table = "`avstamning`";
    $columnSql['ID'] = "ID";
    $columnSql['Name'] = "Avstamning";
    $sql = "(SELECT * FROM $table WHERE ID = $extraID) UNION (SELECT * FROM $table WHERE 1)";
    $result = $conn->query($sql);
    if ($result->num_rows > 0)
    {
        while ($row = $result->fetch_assoc())
        {
            echo "<option value='" . $row[$columnSql['ID']] . "'>" . $row[$columnSql['Name']] . "</option>";
        }
        echo "</select>";
    }
}
function dropdownSearchMovement($extraID)
{
    include 'languageSwitcher.php';
    if (empty($extraID))
    {
        $extraID = "0";
        echo '<option value="0">' . $lang['Movement'] . '</option>';
    }
    include 'dbh.inc.php';
    $table = "`type stykke`";
    $columnSql['ID'] = "ID";
    $columnSql['Name'] = "Type stykke";
    $sql = "(SELECT * FROM $table WHERE ID = $extraID) UNION (SELECT * FROM $table WHERE 1)";
    $result = $conn->query($sql);
    if ($result->num_rows > 0)
    {
        while ($row = $result->fetch_assoc())
        {
            echo "<option value='" . $row[$columnSql['ID']] . "'>" . $row[$columnSql['Name']] . "</option>";
        }
        echo "</select>";
    }
}
function dropdownSearchOrgin($extraID)
{
    include 'languageSwitcher.php';
    if (empty($extraID))
    {
        $extraID = "0";
        echo '<option value="0">' . $lang['Country of origin'] . '</option>';
    }
    include 'dbh.inc.php';
    $table = "`opprinnelsesland`";
    $columnSql['ID'] = "ID";
    $columnSql['Name'] = "Opprinnelsesland";
    $sql = "(SELECT * FROM $table WHERE ID = $extraID) UNION (SELECT * FROM $table WHERE 1)";
    $result = $conn->query($sql);
    if ($result->num_rows > 0)
    {
        while ($row = $result->fetch_assoc())
        {
            echo "<option value='" . $row[$columnSql['ID']] . "'>" . $row[$columnSql['Name']] . "</option>";
        }
        echo "</select>";
    }
}
function dropdownSearchInstrument($extraID)
{
    include 'languageSwitcher.php';
    if (empty($extraID))
    {
        $extraID = "0";
        echo '<option value="0">' . $lang['Solo instrument'] . '</option>';
    }
    include 'dbh.inc.php';
    $table = "`instrumenter`";
    $columnSql['ID'] = "ID";
    $columnSql['Name'] = "Instrument";
    $sql = "(SELECT * FROM $table WHERE ID = $extraID) UNION (SELECT * FROM $table WHERE 1)";
    $result = $conn->query($sql);
    if ($result->num_rows > 0)
    {
        while ($row = $result->fetch_assoc())
        {
            echo "<option value='" . $row[$columnSql['ID']] . "'>" . $row[$columnSql['Name']] . "</option>";
        }
        echo "</select>";
    }
}
function dropdownSearchLocation($extraID)
{
    include 'languageSwitcher.php';
    if (empty($extraID))
    {
        $extraID = "0";
        echo '<option value="0">' . $lang['Physical location'] . '</option>';
    }
    include 'dbh.inc.php';
    $table = "`lagringssted`";
    $columnSql['ID'] = "ID";
    $columnSql['Name'] = "Konserthistorikk";
    $sql = "(SELECT * FROM $table WHERE ID = $extraID) UNION (SELECT * FROM $table WHERE 1)";
    $result = $conn->query($sql);
    if ($result->num_rows > 0)
    {
        while ($row = $result->fetch_assoc())
        {
            echo "<option value='" . $row[$columnSql['ID']] . "'>" . $row[$columnSql['Name']] . "</option>";
        }
        echo "</select>";
    }
}
function uploadSheet($mode, $noteID, $Piecename, $Othername, $Composer, $Lyricist, $Mp3, $Publishercataloguenumber, $Genre, $Pleasenote, $Chordnames, $Arranger, $EnsembleType, $Ancestry, $Released, $Physicallocation, $Linktomusicsample, $Soloist, $Soloinstrument, $Key, $Opusnumber, $Countryoforigin, $Duration, $Movement, $PDF, $Vocal, $ScoresAvailable, $AltSaxophoneinEb1, $AltSaxophoneinEb2, $AltSaxophoneinEb3, $Banjo, $BaritonesaxophoneinEb, $BassClarinetandorClarinetinEb, $BassTrombone, $Viola, $Castanets, $Celesta, $Cello1, $Cello2, $CelloObbligato, $ChimesTubularBells, $Cymbals, $SleighBells, $EnglishHorn, $Euphonium, $Bassoon1, $Bassoon2, $Violin1, $Violin2, $Violin3, $ViolinObligate, $Flute1, $Flute2, $Flute3, $Guitar, $Harmonica, $Harmonium, $Harp, $HorninC1, $HorninC2, $HorninD1, $HorninD2, $HorninEb1, $HorninEb2, $HorninF1, $HorninF2, $HorninF3, $HorninF4, $Clarinet1inA, $Clarinet1inBb, $Clarinet1inC, $Clarinet2thea, $Clarinet2inBb, $Clarinet2inC, $Clarinet3inA, $Clarinet3inBb, $Keyboardinstrument, $Chime, $DoubleBass, $Contrabassoon, $CornetinA1, $CornetinA2, $CornetinBb1, $CornetinBb2, $Cowbell, $Mandolin1, $Oboe1, $Oboe2, $OboObligate, $Timpani1or2, $Timpani3orMore, $PiccolopossiblyasOneofFluteVoices, $Snare, $Percussion, $SopranoSaxophone, $BassDrum, $Tambour, $TenorBanjo, $TenorSaxophoneinBb1, $TenorSaxophoneinBb2, $TenorSaxophoneinBb3, $TenorSaxophoneinBb4, $TenorSaxophoneinCmelody, $Timbales, $TomTom, $AccordionBandoneon, $Triangle, $Trombone1, $Trombone2, $Trombone3, $Trumpetina1, $TrumpetinA2, $TrumpetinaObligate, $TrumpetinBb1, $TrumpetinBb2, $TrumpetinBb3, $TrumpetinBb4, $TrumpetinBbObligate, $TrumpetinC1, $TrumpetinC2, $TrumpetF1, $TrumpetF2, $Tuba, $Tubaophicléide, $Vibraphone, $Xylophone)
{

    include 'languageSwitcher.php';
    include 'dbh.inc.php';

    $noteID = mysqli_real_escape_string($conn, $_POST['noteID']);
    $Piecename = mysqli_real_escape_string($conn, $_POST['Piecename']);
    $Othername = mysqli_real_escape_string($conn, $_POST['OtherName']);
    $Composer = mysqli_real_escape_string($conn, $_POST['Composer']);
    $Lyricist = mysqli_real_escape_string($conn, $_POST['Lyricist']);

    $Publishercataloguenumber = mysqli_real_escape_string($conn, $_POST['Publishercataloguenumber']);
    $Genre = mysqli_real_escape_string($conn, $_POST['Genre']);
    $Pleasenote = mysqli_real_escape_string($conn, $_POST['PleaseNote']);
    $Chordnames = mysqli_real_escape_string($conn, @$_POST['Chordnames']);
    if (isset($_POST['Chordnames']) && $_POST['Chordnames'] == '1')
    {
        $Chordnames = '1';
    }
    else
    {
        $Chordnames = '0';
    }
    $Arranger = mysqli_real_escape_string($conn, $_POST['Arranger']);
    $EnsembleType = mysqli_real_escape_string($conn, $_POST['EnsembleType']);
    $Ancestry = mysqli_real_escape_string($conn, $_POST['Ancestry']);
    $Released = mysqli_real_escape_string($conn, $_POST['Released']);
    $Physicallocation = mysqli_real_escape_string($conn, $_POST['PhysicalLocation']);
    $Linktomusicsample = mysqli_real_escape_string($conn, $_POST['Link']);

    //$Link              = "#" . "$Linktomusicsample" . "#";
    if (isset($_POST['Link']))
    {
        $Link = '';
    }
    else
    {
        $Link = "#" . "$Linktomusicsample" . "#";
    }

    $Soloist = mysqli_real_escape_string($conn, @$_POST['Soloist']);
    if (isset($_POST['Soloist']) && $_POST['Soloist'] == '1')
    {
        $Soloist = '1';
    }
    else
    {
        $Soloist = '0';
    }
    $Soloinstrument = mysqli_real_escape_string($conn, $_POST['SoloInstrument']);
    $Key = mysqli_real_escape_string($conn, $_POST['Key']);
    $Opusnumber = mysqli_real_escape_string($conn, $_POST['OpusNumber']);
    $Countryoforigin = mysqli_real_escape_string($conn, $_POST['CountryOfOrigin']);
    $Duration = mysqli_real_escape_string($conn, $_POST['Duration']);
    $Movement = mysqli_real_escape_string($conn, $_POST['Movement']);
    /*$PDF             = mysqli_real_escape_string($conn, @$_POST['PDF']);
    if (isset($_POST['PDF']) && $_POST['PDF'] == '1') {
        $PDF = '1';
    } else {
        $PDF = '0';
    }*/
    $Vocal = mysqli_real_escape_string($conn, @$_POST['Vocal']);
    if (isset($_POST['Vocal']) && $_POST['Vocal'] == '1')
    {
        $Vocal = '1';
    }
    else
    {
        $Vocal = '0';
    }
    $ScoresAvailable = mysqli_real_escape_string($conn, @$_POST['ScoresAvailable']);
    if (isset($_POST['ScoresAvailable']) && $_POST['ScoresAvailable'] == '1')
    {
        $ScoresAvailable = '1';
    }
    else
    {
        $ScoresAvailable = '0';
    }
    $AltSaxophoneinEb1 = mysqli_real_escape_string($conn, @$_POST['AltSaxophoneinEb1']);
    if (isset($_POST['AltSaxophoneinEb1']) && $_POST['AltSaxophoneinEb1'] == '1')
    {
        $AltSaxophoneinEb1 = '1';
    }
    else
    {
        $AltSaxophoneinEb1 = '0';
    }
    $AltSaxophoneinEb2 = mysqli_real_escape_string($conn, @$_POST['AltSaxophoneinEb2']);
    if (isset($_POST['AltSaxophoneinEb2']) && $_POST['AltSaxophoneinEb2'] == '1')
    {
        $AltSaxophoneinEb2 = '1';
    }
    else
    {
        $AltSaxophoneinEb2 = '0';
    }
    $AltSaxophoneinEb3 = mysqli_real_escape_string($conn, @$_POST['AltSaxophoneinEb3']);
    if (isset($_POST['AltSaxophoneinEb3']) && $_POST['AltSaxophoneinEb3'] == '1')
    {
        $AltSaxophoneinEb3 = '1';
    }
    else
    {
        $AltSaxophoneinEb3 = '0';
    }
    $Banjo = mysqli_real_escape_string($conn, @$_POST['Banjo']);
    if (isset($_POST['Banjo']) && $_POST['Banjo'] == '1')
    {
        $Banjo = '1';
    }
    else
    {
        $Banjo = '0';
    }
    $BaritonesaxophoneinEb = mysqli_real_escape_string($conn, @$_POST['BaritonesaxophoneinEb']);
    if (isset($_POST['BaritonesaxophoneinEb']) && $_POST['BaritonesaxophoneinEb'] == '1')
    {
        $BaritonesaxophoneinEb = '1';
    }
    else
    {
        $BaritonesaxophoneinEb = '0';
    }
    $BassClarinetandorClarinetinEb = mysqli_real_escape_string($conn, @$_POST['BassClarinet(andorClarinetinEb)']);
    if (isset($_POST['BassClarinet(andorClarinetinEb)']) && $_POST['BassClarinet(andorClarinetinEb)'] == '1')
    {
        $BassClarinetandorClarinetinEb = '1';
    }
    else
    {
        $BassClarinetandorClarinetinEb = '0';
    }
    $BassTrombone = mysqli_real_escape_string($conn, @$_POST['BassTrombone']);
    if (isset($_POST['BassTrombone']) && $_POST['BassTrombone'] == '1')
    {
        $BassTrombone = '1';
    }
    else
    {
        $BassTrombone = '0';
    }
    $Viola = mysqli_real_escape_string($conn, @$_POST['Viola']);
    if (isset($_POST['Viola']) && $_POST['Viola'] == '1')
    {
        $Viola = '1';
    }
    else
    {
        $Viola = '0';
    }
    $Castanets = mysqli_real_escape_string($conn, @$_POST['Castanets']);
    if (isset($_POST['Castanets']) && $_POST['Castanets'] == '1')
    {
        $Castanets = '1';
    }
    else
    {
        $Castanets = '0';
    }
    $Celesta = mysqli_real_escape_string($conn, @$_POST['Celesta']);
    if (isset($_POST['Celesta']) && $_POST['Celesta'] == '1')
    {
        $Celesta = '1';
    }
    else
    {
        $Celesta = '0';
    }
    $Cello1 = mysqli_real_escape_string($conn, @$_POST['Cello1']);
    if (isset($_POST['Cello1']) && $_POST['Cello1'] == '1')
    {
        $Cello1 = '1';
    }
    else
    {
        $Cello1 = '0';
    }
    $Cello2 = mysqli_real_escape_string($conn, @$_POST['Cello2']);
    if (isset($_POST['Cello2']) && $_POST['Cello2'] == '1')
    {
        $Cello2 = '1';
    }
    else
    {
        $Cello2 = '0';
    }
    $CelloObbligato = mysqli_real_escape_string($conn, @$_POST['CelloObbligato']);
    if (isset($_POST['CelloObbligato']) && $_POST['CelloObbligato'] == '1')
    {
        $CelloObbligato = '1';
    }
    else
    {
        $CelloObbligato = '0';
    }
    $ChimesTubularBells = mysqli_real_escape_string($conn, @$_POST['ChimesTubularBells']);
    if (isset($_POST['ChimesTubularBells']) && $_POST['ChimesTubularBells'] == '1')
    {
        $ChimesTubularBells = '1';
    }
    else
    {
        $ChimesTubularBells = '0';
    }
    $Cymbals = mysqli_real_escape_string($conn, @$_POST['Cymbals']);
    if (isset($_POST['Cymbals']) && $_POST['Cymbals'] == '1')
    {
        $Cymbals = '1';
    }
    else
    {
        $Cymbals = '0';
    }
    $SleighBells = mysqli_real_escape_string($conn, @$_POST['SleighBells']);
    if (isset($_POST['SleighBells']) && $_POST['SleighBells'] == '1')
    {
        $SleighBells = '1';
    }
    else
    {
        $SleighBells = '0';
    }
    $EnglishHorn = mysqli_real_escape_string($conn, @$_POST['EnglishHorn']);
    if (isset($_POST['EnglishHorn']) && $_POST['EnglishHorn'] == '1')
    {
        $EnglishHorn = '1';
    }
    else
    {
        $EnglishHorn = '0';
    }
    $Euphonium = mysqli_real_escape_string($conn, @$_POST['Euphonium']);
    if (isset($_POST['Euphonium']) && $_POST['Euphonium'] == '1')
    {
        $Euphonium = '1';
    }
    else
    {
        $Euphonium = '0';
    }
    $Bassoon1 = mysqli_real_escape_string($conn, @$_POST['Bassoon1']);
    if (isset($_POST['Bassoon1']) && $_POST['Bassoon1'] == '1')
    {
        $Bassoon1 = '1';
    }
    else
    {
        $Bassoon1 = '0';
    }
    $Bassoon2 = mysqli_real_escape_string($conn, @$_POST['Bassoon2']);
    if (isset($_POST['Bassoon2']) && $_POST['Bassoon2'] == '1')
    {
        $Bassoon2 = '1';
    }
    else
    {
        $Bassoon2 = '0';
    }
    $Violin1 = mysqli_real_escape_string($conn, @$_POST['Violin1']);
    if (isset($_POST['Violin1']) && $_POST['Violin1'] == '1')
    {
        $Violin1 = '1';
    }
    else
    {
        $Violin1 = '0';
    }
    $Violin2 = mysqli_real_escape_string($conn, @$_POST['Violin2']);
    if (isset($_POST['Violin2']) && $_POST['Violin2'] == '1')
    {
        $Violin2 = '1';
    }
    else
    {
        $Violin2 = '0';
    }
    $Violin3 = mysqli_real_escape_string($conn, @$_POST['Violin3']);
    if (isset($_POST['Violin3']) && $_POST['Violin3'] == '1')
    {
        $Violin3 = '1';
    }
    else
    {
        $Violin3 = '0';
    }
    $ViolinObligate = mysqli_real_escape_string($conn, @$_POST['ViolinObligate']);
    if (isset($_POST['ViolinObligate']) && $_POST['ViolinObligate'] == '1')
    {
        $ViolinObligate = '1';
    }
    else
    {
        $ViolinObligate = '0';
    }
    $Flute1 = mysqli_real_escape_string($conn, @$_POST['Flute1']);
    if (isset($_POST['Flute1']) && $_POST['Flute1'] == '1')
    {
        $Flute1 = '1';
    }
    else
    {
        $Flute1 = '0';
    }
    $Flute2 = mysqli_real_escape_string($conn, @$_POST['Flute2']);
    if (isset($_POST['Flute2']) && $_POST['Flute2'] == '1')
    {
        $Flute2 = '1';
    }
    else
    {
        $Flute2 = '0';
    }
    $Flute3 = mysqli_real_escape_string($conn, @$_POST['Flute3']);
    if (isset($_POST['Flute3']) && $_POST['Flute3'] == '1')
    {
        $Flute3 = '1';
    }
    else
    {
        $Flute3 = '0';
    }
    $Guitar = mysqli_real_escape_string($conn, @$_POST['Guitar']);
    if (isset($_POST['Guitar']) && $_POST['Guitar'] == '1')
    {
        $Guitar = '1';
    }
    else
    {
        $Guitar = '0';
    }
    $Harmonica = mysqli_real_escape_string($conn, @$_POST['Harmonica']);
    if (isset($_POST['Harmonica']) && $_POST['Harmonica'] == '1')
    {
        $Harmonica = '1';
    }
    else
    {
        $Harmonica = '0';
    }
    $Harmonium = mysqli_real_escape_string($conn, @$_POST['Harmonium']);
    if (isset($_POST['Harmonium']) && $_POST['Harmonium'] == '1')
    {
        $Harmonium = '1';
    }
    else
    {
        $Harmonium = '0';
    }
    $Harp = mysqli_real_escape_string($conn, @$_POST['Harp']);
    if (isset($_POST['Harp']) && $_POST['Harp'] == '1')
    {
        $Harp = '1';
    }
    else
    {
        $Harp = '0';
    }
    $HorninC1 = mysqli_real_escape_string($conn, @$_POST['HorninC1']);
    if (isset($_POST['HorninC1']) && $_POST['HorninC1'] == '1')
    {
        $HorninC1 = '1';
    }
    else
    {
        $HorninC1 = '0';
    }
    $HorninC2 = mysqli_real_escape_string($conn, @$_POST['HorninC2']);
    if (isset($_POST['HorninC2']) && $_POST['HorninC2'] == '1')
    {
        $HorninC2 = '1';
    }
    else
    {
        $HorninC2 = '0';
    }
    $HorninD1 = mysqli_real_escape_string($conn, @$_POST['HorninD1']);
    if (isset($_POST['HorninD1']) && $_POST['HorninD1'] == '1')
    {
        $HorninD1 = '1';
    }
    else
    {
        $HorninD1 = '0';
    }
    $HorninD2 = mysqli_real_escape_string($conn, @$_POST['HorninD2']);
    if (isset($_POST['HorninD2']) && $_POST['HorninD2'] == '1')
    {
        $HorninD2 = '1';
    }
    else
    {
        $HorninD2 = '0';
    }
    $HorninEb1 = mysqli_real_escape_string($conn, @$_POST['HorninEb1']);
    if (isset($_POST['HorninEb1']) && $_POST['HorninEb1'] == '1')
    {
        $HorninEb1 = '1';
    }
    else
    {
        $HorninEb1 = '0';
    }
    $HorninEb2 = mysqli_real_escape_string($conn, @$_POST['HorninEb2']);
    if (isset($_POST['HorninEb2']) && $_POST['HorninEb2'] == '1')
    {
        $HorninEb2 = '1';
    }
    else
    {
        $HorninEb2 = '0';
    }
    $HorninF1 = mysqli_real_escape_string($conn, @$_POST['HorninF1']);
    if (isset($_POST['HorninF1']) && $_POST['HorninF1'] == '1')
    {
        $HorninF1 = '1';
    }
    else
    {
        $HorninF1 = '0';
    }
    $HorninF2 = mysqli_real_escape_string($conn, @$_POST['HorninF2']);
    if (isset($_POST['HorninF2']) && $_POST['HorninF2'] == '1')
    {
        $HorninF2 = '1';
    }
    else
    {
        $HorninF2 = '0';
    }
    $HorninF3 = mysqli_real_escape_string($conn, @$_POST['HorninF3']);
    if (isset($_POST['HorninF3']) && $_POST['HorninF3'] == '1')
    {
        $HorninF3 = '1';
    }
    else
    {
        $HorninF3 = '0';
    }
    $HorninF4 = mysqli_real_escape_string($conn, @$_POST['HorninF4']);
    if (isset($_POST['HorninF4']) && $_POST['HorninF4'] == '1')
    {
        $HorninF4 = '1';
    }
    else
    {
        $HorninF4 = '0';
    }
    $Clarinet1inA = mysqli_real_escape_string($conn, @$_POST['Clarinet1inA']);
    if (isset($_POST['Clarinet1inA']) && $_POST['Clarinet1inA'] == '1')
    {
        $Clarinet1inA = '1';
    }
    else
    {
        $Clarinet1inA = '0';
    }
    $Clarinet1inBb = mysqli_real_escape_string($conn, @$_POST['Clarinet1inBb']);
    if (isset($_POST['Clarinet1inBb']) && $_POST['Clarinet1inBb'] == '1')
    {
        $Clarinet1inBb = '1';
    }
    else
    {
        $Clarinet1inBb = '0';
    }
    $Clarinet1inC = mysqli_real_escape_string($conn, @$_POST['Clarinet1inC']);
    if (isset($_POST['Clarinet1inC']) && $_POST['Clarinet1inC'] == '1')
    {
        $Clarinet1in = '1';
    }
    else
    {
        $Clarinet1inC = '0';
    }
    $Clarinet2thea = mysqli_real_escape_string($conn, @$_POST['Clarinet2thea']);
    if (isset($_POST['Clarinet2thea']) && $_POST['Clarinet2thea'] == '1')
    {
        $Clarinet2thea = '1';
    }
    else
    {
        $Clarinet2thea = '0';
    }
    $Clarinet2inBb = mysqli_real_escape_string($conn, @$_POST['Clarinet2inBb']);
    if (isset($_POST['Clarinet2inBb']) && $_POST['Clarinet2inBb'] == '1')
    {
        $Clarinet2inBb = '1';
    }
    else
    {
        $Clarinet2inBb = '0';
    }
    $Clarinet2inC = mysqli_real_escape_string($conn, @$_POST['Clarinet2inC']);
    if (isset($_POST['Clarinet2inC']) && $_POST['Clarinet2inC'] == '1')
    {
        $Clarinet2inC = '1';
    }
    else
    {
        $Clarinet2inC = '0';
    }
    $Clarinet3inA = mysqli_real_escape_string($conn, @$_POST['Clarinet3inA']);
    if (isset($_POST['Clarinet3inA']) && $_POST['Clarinet3inA'] == '1')
    {
        $Clarinet3inA = '1';
    }
    else
    {
        $Clarinet3inA = '0';
    }
    $Clarinet3inBb = mysqli_real_escape_string($conn, @$_POST['Clarinet3inBb']);
    if (isset($_POST['Clarinet3inBb']) && $_POST['Clarinet3inBb'] == '1')
    {
        $Clarinet3inBb = '1';
    }
    else
    {
        $Clarinet3inBb = '0';
    }
    $Keyboardinstrument = mysqli_real_escape_string($conn, @$_POST['Keyboardinstrument']);
    if (isset($_POST['Keyboardinstrument']) && $_POST['Keyboardinstrument'] == '1')
    {
        $Keyboardinstrument = '1';
    }
    else
    {
        $Keyboardinstrument = '0';
    }
    $Chime = mysqli_real_escape_string($conn, @$_POST['Chime']);
    if (isset($_POST['Chime']) && $_POST['Chime'] == '1')
    {
        $Chime = '1';
    }
    else
    {
        $Chime = '0';
    }
    $DoubleBass = mysqli_real_escape_string($conn, @$_POST['DoubleBass']);
    if (isset($_POST['DoubleBass']) && $_POST['DoubleBass'] == '1')
    {
        $DoubleBass = '1';
    }
    else
    {
        $DoubleBass = '0';
    }
    $Contrabassoon = mysqli_real_escape_string($conn, @$_POST['Contrabassoon']);
    if (isset($_POST['Contrabassoon']) && $_POST['Contrabassoon'] == '1')
    {
        $Contrabassoon = '1';
    }
    else
    {
        $Contrabassoon = '0';
    }
    $CornetinA1 = mysqli_real_escape_string($conn, @$_POST['CornetinA1']);
    if (isset($_POST['CornetinA1']) && $_POST['CornetinA1'] == '1')
    {
        $CornetinA1 = '1';
    }
    else
    {
        $CornetinA1 = '0';
    }
    $CornetinA2 = mysqli_real_escape_string($conn, @$_POST['CornetinA2']);
    if (isset($_POST['CornetinA2']) && $_POST['CornetinA2'] == '1')
    {
        $CornetinA2 = '1';
    }
    else
    {
        $CornetinA2 = '0';
    }
    $CornetinBb1 = mysqli_real_escape_string($conn, @$_POST['CornetinBb1']);
    if (isset($_POST['CornetinBb1']) && $_POST['CornetinBb1'] == '1')
    {
        $CornetinBb1 = '1';
    }
    else
    {
        $CornetinBb1 = '0';
    }
    $CornetinBb2 = mysqli_real_escape_string($conn, @$_POST['CornetinBb2']);
    if (isset($_POST['CornetinBb2']) && $_POST['CornetinBb2'] == '1')
    {
        $CornetinBb2 = '1';
    }
    else
    {
        $CornetinBb2 = '0';
    }
    $Cowbell = mysqli_real_escape_string($conn, @$_POST['Cowbell']);
    if (isset($_POST['Cowbell']) && $_POST['Cowbell'] == '1')
    {
        $Cowbell = '1';
    }
    else
    {
        $Cowbell = '0';
    }
    $Mandolin1 = mysqli_real_escape_string($conn, @$_POST['Mandolin1']);
    if (isset($_POST['Mandolin1']) && $_POST['Mandolin1'] == '1')
    {
        $Mandolin1 = '1';
    }
    else
    {
        $Mandolin1 = '0';
    }
    $Oboe1 = mysqli_real_escape_string($conn, @$_POST['Oboe1']);
    if (isset($_POST['Oboe1']) && $_POST['Oboe1'] == '1')
    {
        $Oboe1 = '1';
    }
    else
    {
        $Oboe1 = '0';
    }
    $Oboe2 = mysqli_real_escape_string($conn, @$_POST['Oboe2']);
    if (isset($_POST['Oboe2']) && $_POST['Oboe2'] == '1')
    {
        $Oboe2 = '1';
    }
    else
    {
        $Oboe2 = '0';
    }
    $OboObligate = mysqli_real_escape_string($conn, @$_POST['OboObligate']);
    if (isset($_POST['OboObligate']) && $_POST['OboObligate'] == '1')
    {
        $OboObligate = '1';
    }
    else
    {
        $OboObligate = '0';
    }
    $Timpani1or2 = mysqli_real_escape_string($conn, @$_POST['Timpani1or2']);
    if (isset($_POST['Timpani1or2']) && $_POST['Timpani1or2'] == '1')
    {
        $Timpani1or2 = '1';
    }
    else
    {
        $Timpani1or2 = '0';
    }
    $Timpani3orMore = mysqli_real_escape_string($conn, @$_POST['Timpani3orMore']);
    if (isset($_POST['Timpani3orMore']) && $_POST['Timpani3orMore'] == '1')
    {
        $Timpani3orMore = '1';
    }
    else
    {
        $Timpani3orMore = '0';
    }
    $PiccolopossiblyasOneofFluteVoices = mysqli_real_escape_string($conn, @$_POST['PiccolopossiblyasOneofFluteVoices']);
    if (isset($_POST['PiccolopossiblyasOneofFluteVoices']) && $_POST['PiccolopossiblyasOneofFluteVoices'] == '1')
    {
        $PiccolopossiblyasOneofFluteVoices = '1';
    }
    else
    {
        $PiccolopossiblyasOneofFluteVoices = '0';
    }
    $Snare = mysqli_real_escape_string($conn, @$_POST['Snare']);
    if (isset($_POST['Snare']) && $_POST['Snare'] == '1')
    {
        $Snare = '1';
    }
    else
    {
        $Snare = '0';
    }
    $Percussion = mysqli_real_escape_string($conn, @$_POST['Percussion']);
    if (isset($_POST['Percussion']) && $_POST['Percussion'] == '1')
    {
        $Percussion = '1';
    }
    else
    {
        $Percussion = '0';
    }
    $SopranoSaxophone = mysqli_real_escape_string($conn, @$_POST['SopranoSaxophone']);
    if (isset($_POST['SopranoSaxophone']) && $_POST['SopranoSaxophone'] == '1')
    {
        $SopranoSaxophone = '1';
    }
    else
    {
        $SopranoSaxophone = '0';
    }
    $BassDrum = mysqli_real_escape_string($conn, @$_POST['BassDrum']);
    if (isset($_POST['BassDrum']) && $_POST['BassDrum'] == '1')
    {
        $BassDrum = '1';
    }
    else
    {
        $BassDrum = '0';
    }
    $Tambour = mysqli_real_escape_string($conn, @$_POST['Tambour']);
    if (isset($_POST['Tambour']) && $_POST['Tambour'] == '1')
    {
        $Tambour = '1';
    }
    else
    {
        $Tambour = '0';
    }
    $TenorBanjo = mysqli_real_escape_string($conn, @$_POST['TenorBanjo']);
    if (isset($_POST['TenorBanjo']) && $_POST['TenorBanjo'] == '1')
    {
        $TenorBanjo = '1';
    }
    else
    {
        $TenorBanjo = '0';
    }
    $TenorSaxophoneinBb1 = mysqli_real_escape_string($conn, @$_POST['TenorSaxophoneinBb1']);
    if (isset($_POST['TenorSaxophoneinBb1']) && $_POST['TenorSaxophoneinBb1'] == '1')
    {
        $TenorSaxophoneinBb1 = '1';
    }
    else
    {
        $TenorSaxophoneinBb1 = '0';
    }
    $TenorSaxophoneinBb2 = mysqli_real_escape_string($conn, @$_POST['TenorSaxophoneinBb2']);
    if (isset($_POST['TenorSaxophoneinBb2']) && $_POST['TenorSaxophoneinBb2'] == '1')
    {
        $TenorSaxophoneinBb2 = '1';
    }
    else
    {
        $TenorSaxophoneinBb2 = '0';
    }
    $TenorSaxophoneinBb3 = mysqli_real_escape_string($conn, @$_POST['TenorSaxophoneinBb3']);
    if (isset($_POST['TenorSaxophoneinBb3']) && $_POST['TenorSaxophoneinBb3'] == '1')
    {
        $TenorSaxophoneinBb3 = '1';
    }
    else
    {
        $TenorSaxophoneinBb3 = '0';
    }
    $TenorSaxophoneinBb4 = mysqli_real_escape_string($conn, @$_POST['TenorSaxophoneinBb4']);
    if (isset($_POST['TenorSaxophoneinBb4']) && $_POST['TenorSaxophoneinBb4'] == '1')
    {
        $TenorSaxophoneinBb4 = '1';
    }
    else
    {
        $TenorSaxophoneinBb4 = '0';
    }
    $TenorSaxophoneinCmelody = mysqli_real_escape_string($conn, @$_POST['TenorSaxophoneinCmelody']);
    if (isset($_POST['TenorSaxophoneinCmelody']) && $_POST['TenorSaxophoneinCmelody'] == '1')
    {
        $TenorSaxophoneinCmelody = '1';
    }
    else
    {
        $TenorSaxophoneinCmelody = '0';
    }
    $Timbales = mysqli_real_escape_string($conn, @$_POST['Timbales']);
    if (isset($_POST['Timbales']) && $_POST['Timbales'] == '1')
    {
        $Timbales = '1';
    }
    else
    {
        $Timbales = '0';
    }
    $TomTom = mysqli_real_escape_string($conn, @$_POST['TomTom']);
    if (isset($_POST['TomTom']) && $_POST['TomTom'] == '1')
    {
        $TomTom = '1';
    }
    else
    {
        $TomTom = '0';
    }
    $AccordionBandoneon = mysqli_real_escape_string($conn, @$_POST['AccordionBandoneon']);
    if (isset($_POST['AccordionBandoneon']) && $_POST['AccordionBandoneon'] == '1')
    {
        $AccordionBandoneon = '1';
    }
    else
    {
        $AccordionBandoneon = '0';
    }
    $Triangle = mysqli_real_escape_string($conn, @$_POST['Triangle']);
    if (isset($_POST['Triangle']) && $_POST['Triangle'] == '1')
    {
        $Triangle = '1';
    }
    else
    {
        $Triangle = '0';
    }
    $Trombone1 = mysqli_real_escape_string($conn, @$_POST['Trombone1']);
    if (isset($_POST['Trombone1']) && $_POST['Trombone1'] == '1')
    {
        $Trombone1 = '1';
    }
    else
    {
        $Trombone1 = '0';
    }
    $Trombone2 = mysqli_real_escape_string($conn, @$_POST['Trombone2']);
    if (isset($_POST['Trombone2']) && $_POST['Trombone2'] == '1')
    {
        $Trombone2 = '1';
    }
    else
    {
        $Trombone2 = '0';
    }
    $Trombone3 = mysqli_real_escape_string($conn, @$_POST['Trombone3']);
    if (isset($_POST['Trombone3']) && $_POST['Trombone3'] == '1')
    {
        $Trombone3 = '1';
    }
    else
    {
        $Trombone3 = '0';
    }
    $TrumpetinA1 = mysqli_real_escape_string($conn, @$_POST['TrumpetinA1']);
    if (isset($_POST['TrumpetinA1']) && $_POST['TrumpetinA1'] == '1')
    {
        $TrumpetinA1 = '1';
    }
    else
    {
        $TrumpetinA1 = '0';
    }
    $TrumpetinA2 = mysqli_real_escape_string($conn, @$_POST['TrumpetinA2']);
    if (isset($_POST['TrumpetinA2']) && $_POST['TrumpetinA2'] == '1')
    {
        $TrumpetinA2 = '1';
    }
    else
    {
        $TrumpetinA2 = '0';
    }
    $TrumpetinaObligate = mysqli_real_escape_string($conn, @$_POST['TrumpetinaObligate']);
    if (isset($_POST['TrumpetinaObligate']) && $_POST['TrumpetinaObligate'] == '1')
    {
        $TrumpetinaObligate = '1';
    }
    else
    {
        $TrumpetinaObligate = '0';
    }
    $TrumpetinBb1 = mysqli_real_escape_string($conn, @$_POST['TrumpetinBb1']);
    if (isset($_POST['TrumpetinBb1']) && $_POST['TrumpetinBb1'] == '1')
    {
        $TrumpetinBb1 = '1';
    }
    else
    {
        $TrumpetinBb1 = '0';
    }
    $TrumpetinBb2 = mysqli_real_escape_string($conn, @$_POST['TrumpetinBb2']);
    if (isset($_POST['TrumpetinBb2']) && $_POST['TrumpetinBb2'] == '1')
    {
        $TrumpetinBb2 = '1';
    }
    else
    {
        $TrumpetinBb2 = '0';
    }
    $TrumpetinBb3 = mysqli_real_escape_string($conn, @$_POST['TrumpetinBb3']);
    if (isset($_POST['TrumpetinBb3']) && $_POST['TrumpetinBb3'] == '1')
    {
        $TrumpetinBb3 = '1';
    }
    else
    {
        $TrumpetinBb3 = '0';
    }
    $TrumpetinBb4 = mysqli_real_escape_string($conn, @$_POST['TrumpetinBb4']);
    if (isset($_POST['TrumpetinBb4']) && $_POST['TrumpetinBb4'] == '1')
    {
        $TrumpetinBb4 = '1';
    }
    else
    {
        $TrumpetinBb4 = '0';
    }
    $TrumpetinBbObligate = mysqli_real_escape_string($conn, @$_POST['TrumpetinBbObligate']);
    if (isset($_POST['TrumpetinBbObligate']) && $_POST['TrumpetinBbObligate'] == '1')
    {
        $TrumpetinBbObligate = '1';
    }
    else
    {
        $TrumpetinBbObligate = '0';
    }
    $TrumpetinC1 = mysqli_real_escape_string($conn, @$_POST['TrumpetinC1']);
    if (isset($_POST['TrumpetinC1']) && $_POST['TrumpetinC1'] == '1')
    {
        $TrumpetinC1 = '1';
    }
    else
    {
        $TrumpetinC1 = '0';
    }
    $TrumpetinC2 = mysqli_real_escape_string($conn, @$_POST['TrumpetinC2']);
    if (isset($_POST['TrumpetinC2']) && $_POST['TrumpetinC2'] == '1')
    {
        $TrumpetinC2 = '1';
    }
    else
    {
        $TrumpetinC2 = '0';
    }
    $TrumpetF1 = mysqli_real_escape_string($conn, @$_POST['TrumpetF1']);
    if (isset($_POST['TrumpetF1']) && $_POST['TrumpetF1'] == '1')
    {
        $TrumpetF1 = '1';
    }
    else
    {
        $TrumpetF1 = '0';
    }
    $TrumpetF2 = mysqli_real_escape_string($conn, @$_POST['TrumpetF2']);
    if (isset($_POST['TrumpetF2']) && $_POST['TrumpetF2'] == '1')
    {
        $TrumpetF2 = '1';
    }
    else
    {
        $TrumpetF2 = '0';
    }
    $Tuba = mysqli_real_escape_string($conn, @$_POST['Tuba']);
    if (isset($_POST['Tuba']) && $_POST['Tuba'] == '1')
    {
        $Tuba = '1';
    }
    else
    {
        $Tuba = '0';
    }
    $Tubaophicléide = mysqli_real_escape_string($conn, @$_POST['Tubaophicléide']);
    if (isset($_POST['Tubaophicléide']) && $_POST['Tubaophicléide'] == '1')
    {
        $Tubaophicléide = '1';
    }
    else
    {
        $Tubaophicléide = '0';
    }
    $Vibraphone = mysqli_real_escape_string($conn, @$_POST['Vibraphone']);
    if (isset($_POST['Vibraphone']) && $_POST['Vibraphone'] == '1')
    {
        $Vibraphone = '1';
    }
    else
    {
        $Vibraphone = '0';
    }
    $Xylophone = mysqli_real_escape_string($conn, @$_POST['Xylophone']);
    if (isset($_POST['Xylophone']) && $_POST['Xylophone'] == '1')
    {
        $Xylophone = '1';
    }
    else
    {
        $Xylophone = '0';
    }
    if ($mode == "1")
    {
        echo '<br>' . $lang['Upload Success'];
        mysqli_query($conn, "
INSERT INTO notedata(`Navn på stykket`, `Annet navn på stykket`, `Komponist for musikken`, `Tekstforfatter`, `mp3`, `Noteutgivers katalognr`, `Sjanger`, `Obs`, `Akkorder er angitt`, `Arrangert av`, `Type arrangement`, `Avstamning`, `Utgivelsesdato`, `Lagringssted`, `Link til lydprøve`, `Solist`, `Soloinstrument`, `Dur`, `Opus nr`, `Opprinnelsesland`, `Spilletid`, `Type stykke`, `PDF`, `Sang`, `Partitur finnes`, `Alt-saksofon i Eb 1`, `Alt-saksofon i Eb 2`, `Alt-saksofon i Eb 3`, `Banjo`, `Bariton-Saxofon i Eb`, `Bassklarinett (og eller klarinett i Eb)`, `Bass-trombone`, `Bratsj`, `Castagnetter`, `Celesta`, `Cello 1`, `Cello 2`, `Cello obligato`, `Chimes/tubular bells`, `Cymbaler`, `Dombjeller`, `Engelsk horn`, `Eufonium`, `Fagott 1`, `Fagott 2`, `Fiolin 1`, `Fiolin 2`, `Fiolin 3`, `Fiolin obligat`, `Fløyte 1`, `Fløyte 2`, `Fløyte 3`, `Gitar`, `Harmonika`, `Harmonium`, `Harpe`, `Horn i C 1`, `Horn i C 2`, `Horn i D 1`, `Horn i D 2`, `Horn i Eb 1`, `Horn i Eb 2`, `Horn i F 1`, `Horn i F 2`, `Horn i F 3`, `Horn i F 4`, `Klarinett 1 i A`, `Klarinett 1 i Bb`, `Klarinett 1 i C`, `Klarinett 2 i A`, `Klarinett 2 i Bb`, `Klarinett 2 i C`, `Klarinett 3 i A`, `Klarinett 3 i Bb`, `Klaver`, `Klokkespill`, `Kontrabass`, `Kontrafagott`, `Kornett i A 1`, `Kornett i A 2`, `Kornett i Bb 1`, `Kornett i Bb 2`, `Kubjelle`, `Mandolin 1`, `Obo 1`, `Obo 2`, `Obo Obligat`, `Pauker 1-2 stk`, `Pauker 3 eller fler`, `Piccolo (muligens som en av fløytestemmene)`, `Skarptromme`, `Slagverk`, `Sopran-saksofon`, `Stortromme`, `Tamburtromme`, `Tenorbanjo`, `Tenor-saksofon i Bb 1`, `Tenor-saksofon i Bb 2`, `Tenor-saksofon i Bb 3`, `Tenor-saksofon i Bb 4`, `Tenor-saksofon i C (melodi)`, `Timbaler`, `Tom tom`, `Trekkspill/Bandoneon`, `Triangel`, `Trombone 1`, `Trombone 2`, `Trombone 3`, `Trompet i A 1`, `Trompet i A 2`, `Trompet i A obligat`, `Trompet i Bb 1`, `Trompet i Bb 2`, `Trompet i Bb 3`, `Trompet i Bb 4`, `Trompet i Bb obligat`, `Trompet i C 1`, `Trompet i C 2`, `Trompet i F 1`, `Trompet i F 2`, `Tuba`, `Tuba-Ophicléide`, `Vibrafon`, `Xylofon`)
VALUES ('$Piecename', '$Othername', '$Composer', '$Lyricist', '$Mp3', '$Publishercataloguenumber', '$Genre', '$Pleasenote', '$Chordnames', '$Arranger', '$EnsembleType', '$Ancestry', '$Released', '$Physicallocation', '$Link', '$Soloist', '$Soloinstrument', '$Key', '$Opusnumber', '$Countryoforigin', '$Duration', '$Movement', '$PDF', '$Vocal', '$ScoresAvailable', '$AltSaxophoneinEb1', '$AltSaxophoneinEb2', '$AltSaxophoneinEb3', '$Banjo', '$BaritonesaxophoneinEb', '$BassClarinetandorClarinetinEb', '$BassTrombone', '$Viola', '$Castanets', '$Celesta', '$Cello1', '$Cello2', '$CelloObbligato', '$ChimesTubularBells', '$Cymbals', '$SleighBells', '$EnglishHorn', '$Euphonium', '$Bassoon1', '$Bassoon2', '$Violin1', '$Violin2', '$Violin3', '$ViolinObligate', '$Flute1', '$Flute2', '$Flute3', '$Guitar', '$Harmonica', '$Harmonium', '$Harp', '$HorninC1', '$HorninC2', '$HorninD1', '$HorninD2', '$HorninEb1', '$HorninEb2', '$HorninF1', '$HorninF2', '$HorninF3', '$HorninF4', '$Clarinet1inA', '$Clarinet1inBb', '$Clarinet1inC', '$Clarinet2thea', '$Clarinet2inBb', '$Clarinet2inC', '$Clarinet3inA', '$Clarinet3inBb', '$Keyboardinstrument', '$Chime', '$DoubleBass', '$Contrabassoon', '$CornetinA1', '$CornetinA2', '$CornetinBb1', '$CornetinBb2', '$Cowbell', '$Mandolin1', '$Oboe1', '$Oboe2', '$OboObligate', '$Timpani1or2', '$Timpani3orMore', '$PiccolopossiblyasOneofFluteVoices', '$Snare', '$Percussion', '$SopranoSaxophone', '$BassDrum', '$Tambour', '$TenorBanjo', '$TenorSaxophoneinBb1', '$TenorSaxophoneinBb2', '$TenorSaxophoneinBb3', '$TenorSaxophoneinBb4', '$TenorSaxophoneinCmelody', '$Timbales', '$TomTom', '$AccordionBandoneon', '$Triangle', '$Trombone1', '$Trombone2', '$Trombone3', '$TrumpetinA1', '$TrumpetinA2', '$TrumpetinaObligate', '$TrumpetinBb1', '$TrumpetinBb2', '$TrumpetinBb3', '$TrumpetinBb4', '$TrumpetinBbObligate', '$TrumpetinC1', '$TrumpetinC2', '$TrumpetF1', '$TrumpetF2', '$Tuba', '$Tubaophicléide', '$Vibraphone', '$Xylophone'
)") or die(mysqli_error($conn));
        echo '<div class="form"><br><form><button type="submit">⮌ Back</button></form></div>';
    }

    elseif ($mode == "2")
    {
        if (userAccess() == '1')
        {
            echo $lang['Edit Success'];
            mysqli_query($conn, "UPDATE `notedata` SET `Navn på stykket` = '$Piecename',`Annet navn på stykket` = '$Othername',`Komponist for musikken` = '$Composer',`Tekstforfatter` = '$Lyricist',`mp3` = '$Mp3',`Noteutgivers katalognr` = '$Publishercataloguenumber',`Sjanger` = '$Genre',`Obs` = '$Pleasenote',`Akkorder er angitt` = '$Chordnames',`Arrangert av` = '$Arranger',`Type arrangement` = '$EnsembleType',`Avstamning` = '$Ancestry',`Utgivelsesdato` = '$Released',`Lagringssted` = '$Physicallocation',`Link til lydprøve` = '$Link',`Solist` = '$Soloist',`Soloinstrument` = '$Soloinstrument',`Dur` = '$Key',`Opus nr` = '$Opusnumber',`Opprinnelsesland` = '$Countryoforigin',`Spilletid` = '$Duration',`Type stykke` = '$Movement',`PDF` = '$PDF',`Sang` = '$Vocal',`Partitur finnes` = '$ScoresAvailable',`Alt-saksofon i Eb 1` = '$AltSaxophoneinEb1',`Alt-saksofon i Eb 2` = '$AltSaxophoneinEb2',`Alt-saksofon i Eb 3` = '$AltSaxophoneinEb3',`Banjo` = '$Banjo',`Bariton-Saxofon i Eb` = '$BaritonesaxophoneinEb',`Bassklarinett (og eller klarinett i Eb)` = '$BassClarinetandorClarinetinEb',`Bass-trombone` = '$BassTrombone',`Bratsj` = '$Viola',`Castagnetter` = '$Castanets',`Celesta` = '$Celesta',`Cello 1` = '$Cello1',`Cello 2` = '$Cello2',`Cello obligato` = '$CelloObbligato',`Chimes/tubular bells` = '$ChimesTubularBells',`Cymbaler` = '$Cymbals',`Dombjeller` = '$SleighBells',`Engelsk horn` = '$EnglishHorn',`Eufonium` = '$Euphonium',`Fagott 1` = '$Bassoon1',`Fagott 2` = '$Bassoon2',`Fiolin 1` = '$Violin1',`Fiolin 2` = '$Violin2',`Fiolin 3` = '$Violin3',`Fiolin obligat` = '$ViolinObligate',`Fløyte 1` = '$Flute1',`Fløyte 2` = '$Flute2',`Fløyte 3` = '$Flute3',`Gitar` = '$Guitar',`Harmonika` = '$Harmonica',`Harmonium` = '$Harmonium',`Harpe` = '$Harp',`Horn i C 1` = '$HorninC1',`Horn i C 2` = '$HorninC2',`Horn i D 1` = '$HorninD1',`Horn i D 2` = '$HorninD2',`Horn i Eb 1` = '$HorninEb1',`Horn i Eb 2` = '$HorninEb2',`Horn i F 1` = '$HorninF1',`Horn i F 2` = '$HorninF2',`Horn i F 3` = '$HorninF3',`Horn i F 4` = '$HorninF4',`Klarinett 1 i A` = '$Clarinet1inA',`Klarinett 1 i Bb` = '$Clarinet1inBb',`Klarinett 1 i C` = '$Clarinet1inC',`Klarinett 2 i A` = '$Clarinet2thea',`Klarinett 2 i Bb` = '$Clarinet2inBb',`Klarinett 2 i C` = '$Clarinet2inC',`Klarinett 3 i A` = '$Clarinet3inA',`Klarinett 3 i Bb` = '$Clarinet3inBb',`Klaver` = '$Keyboardinstrument',`Klokkespill` = '$Chime',`Kontrabass` = '$DoubleBass',`Kontrafagott` = '$Contrabassoon',`Kornett i A 1` = '$CornetinA1',`Kornett i A 2` = '$CornetinA2',`Kornett i Bb 1` = '$CornetinBb1',`Kornett i Bb 2` = '$CornetinBb2',`Kubjelle` = '$Cowbell',`Mandolin 1` = '$Mandolin1',`Obo 1` = '$Oboe1',`Obo 2` = '$Oboe2',`Obo Obligat` = '$OboObligate',`Pauker 1-2 stk` = '$Timpani1or2',`Pauker 3 eller fler` = '$Timpani3orMore',`Piccolo (muligens som en av fløytestemmene)` = '$PiccolopossiblyasOneofFluteVoices',`Skarptromme` = '$Snare',`Slagverk` = '$Percussion',`Sopran-saksofon` = '$SopranoSaxophone',`Stortromme` = '$BassDrum',`Tamburtromme` = '$Tambour',`Tenorbanjo` = '$TenorBanjo',`Tenor-saksofon i Bb 1` = '$TenorSaxophoneinBb1',`Tenor-saksofon i Bb 2` = '$TenorSaxophoneinBb2',`Tenor-saksofon i Bb 3` = '$TenorSaxophoneinBb3',`Tenor-saksofon i Bb 4` = '$TenorSaxophoneinBb4',`Tenor-saksofon i C (melodi)` = '$TenorSaxophoneinCmelody',`Timbaler` = '$Timbales',`Tom tom` = '$TomTom',`Trekkspill/Bandoneon` = '$AccordionBandoneon',`Triangel` = '$Triangle',`Trombone 1` = '$Trombone1',`Trombone 2` = '$Trombone2',`Trombone 3` = '$Trombone3',`Trompet i A 1` = '$TrumpetinA1',`Trompet i A 2` = '$TrumpetinA2',`Trompet i A obligat` = '$TrumpetinaObligate',`Trompet i Bb 1` = '$TrumpetinBb1',`Trompet i Bb 2` = '$TrumpetinBb2',`Trompet i Bb 3` = '$TrumpetinBb3',`Trompet i Bb 4` = '$TrumpetinBb4',`Trompet i Bb obligat` = '$TrumpetinBbObligate',`Trompet i C 1` = '$TrumpetinC1',`Trompet i C 2` = '$TrumpetinC2',`Trompet i F 1` = '$TrumpetF1',`Trompet i F 2` = '$TrumpetF2',`Tuba` = '$Tuba',`Tuba-Ophicléide` = '$Tubaophicléide',`Vibrafon` = '$Vibraphone',`Xylofon` = '$Xylophone' WHERE `notedata`.`noteID` = $noteID;") or die(mysqli_error($conn));
            header("Location: File.php?id=$noteID");
            echo '<div class="form"><br><form><button type="submit">⮌ Back</button></form></div>';
        }
    }
}

function uploadFileOLD($filePost, $permission)
{
    include 'dbh.inc.php';
    $userID = $_SESSION['userID'];
    $permission = mysqli_real_escape_string($conn, $_POST['permission']);
    $fileID = mysqli_real_escape_string($conn, $_POST['fileID']);
    //input file
    //if (userAccess() == '1') {
    // fileName of the uploaded file
    $fileName = $_FILES[$filePost]['name'];
    $filePath = time() . "_" . $_FILES[$filePost]['name'];
    //$filePath = md5(microtime());
    // destination of the file on the server
    $destination = '../../uploads/' . $filePath;

    // get the file extension
    $extension = pathinfo($fileName, PATHINFO_EXTENSION);

    // the physical file on a temporary uploads directory on the server
    $file = $_FILES[$filePost]['tmp_name'];
    $fileSize = $_FILES[$filePost]['size'];

    if (!in_array($extension, ['mp3', 'pdf', 'txt']))
    {
        echo "Your file must be in a .mp3, .pdf or .txt format!";
    }
    else
    {
        if ($_FILES[$filePost]['size'] > 16777216)
        { // file shouldn't be larger than 1Megabyte
            echo "File too large!";
        }
        else
        {
            // move the uploaded (temporary) file to the specified destination
            //copy() instead of move_uploaded_file()
            if (move_uploaded_file($file, $destination))
            {
                $sql = "INSERT INTO `files` (`fileAuthor`, `fileName`, `filePath`, `fileSize`, `fileCreated`, `filePermission`, `fileDownloads`) VALUES ('$userID', '$fileName', '$filePath', '$fileSize', CURRENT_TIME(), '$permission', '0');";
                //deleteFile ($fileID,replace); //$sql = "UPDATE `files` SET `fileAuthor` = '$userID', `fileName` = '$fileName', `filePath` = '$filePath', `fileSize` = '$fileSize', `fileCreated` = CURRENT_TIME(), `filePermission` = '$permission' WHERE `files`.`fileID` = '$fileID';";
                if (mysqli_query($conn, $sql));
                {
                    echo "$fileName uploaded";
                    //echo "<meta http-equiv='refresh' content='0'>";
                    $fileStatus = "OK";
                }
                return $filePath;
            }
            else
            {
                echo "Failed to upload $fileName";
            }
        }

        unset($_POST['permission'], $_POST['fileID']);
    }
    echo $lang['Action Denied'];
}

function uploadFile($relatedNote,$permission)
{
    include 'dbh.inc.php';
    $userID = $_SESSION['userID'];
    //$permission = mysqli_real_escape_string($conn, $_POST['permission']);
    $filePost = "myfile";
    //input file
    //if (userAccess() == '1') {
    // fileName of the uploaded file
    $fileName = $_FILES[$filePost]['name'];
    $filePath = time() . "_" . $_FILES[$filePost]['name'];
    //$filePath = md5(microtime());
    // destination of the file on the server
    $destination = '../../uploads/' . $filePath;

    // get the file extension
    $extension = pathinfo($fileName, PATHINFO_EXTENSION);

    // the physical file on a temporary uploads directory on the server
    $file = $_FILES[$filePost]['tmp_name'];
    $fileSize = $_FILES[$filePost]['size'];

    if (!in_array($extension, ['mp3', 'pdf', 'txt']))
    {
        echo "Your file must be in a .mp3, .pdf or .txt format!";
    }
    else
    {
        if ($_FILES[$filePost]['size'] > 16777216)
        { // file shouldn't be larger than 1Megabyte
            echo "File too large!";
        }
        else
        {
            // move the uploaded (temporary) file to the specified destination
            //copy() instead of move_uploaded_file()
            if (move_uploaded_file($file, $destination))
            {
                $sql = "INSERT INTO `files` (`relatedNote`,`fileAuthor`, `fileName`, `filePath`, `fileSize`, `fileCreated`, `filePermission`, `fileDownloads`) VALUES ('$relatedNote', '$userID', '$fileName', '$filePath', '$fileSize', CURRENT_TIME(), '$permission', '0');";
                
                
                if (mysqli_query($conn, $sql) or die(mysqli_error($conn)));
                {
                    echo "$fileName uploaded";
                    //echo "<meta http-equiv='refresh' content='0'>";
                    $fileStatus = "OK";
                
                //return $filePath;


                switch ($extension ) {
                    case 'mp3':
                        $sql = "UPDATE `notedata` SET `mp3` = '$filePath' WHERE `notedata`.`noteID` = $relatedNote";
                        if (mysqli_query($conn, $sql)  or die(mysqli_error($conn)));
                        {
                            echo "Note approved successfully";
                        }
                        break;
                    case 'pdf':
                        $sql = "UPDATE `notedata` SET `PDF` = '$filePath' WHERE `notedata`.`noteID` = $relatedNote";
                        if (mysqli_query($conn, $sql));
                        {
                            echo "Note approved successfully";
                        }
                         break;
                    default:
                        # code...
                        break;
                }

            }}
            else
            {
                echo "Failed to upload $fileName";
            }
        }


    }
    //echo $lang['Action Denied'];
}

function filesize_formatted($size)
{
    $units = array(
        'B',
        'KB',
        'MB',
        'GB',
        'TB',
        'PB',
        'EB',
        'ZB',
        'YB'
    );
    $power = $size > 0 ? floor(log($size, 1000)) : 0;
    //return number_format($size / pow(1000, $power), 2, '.', ',') . ' ' . $units[$power];
    return number_format($size / pow(1000, $power) , 0, '.', ',') . ' ' . $units[$power];
}
//Not used for now
function filePermission($filePermission)
{

    if ($filePermission == "1")
    {
        return '<p style="color:green">Public</p>';
    }
    else
    {
        return '<p style="color:red">Private</p>';
    }
}

function fileGUI($fileID, $action)
{
    include 'languageSwitcher.php';
    include 'dbh.inc.php';
    $userID = $_SESSION['userID'];
    switch ($action)
    {
        case 'DELETE':
            if (isset($_POST['confirmFileDelete']) && $_POST['confirmFileDelete'] == '1')
            {
                $Confirmed = '1';
                switch (userAccess())
                {
                    case "1";
                    $sql = "SELECT * FROM files WHERE fileID = '$fileID'";
                break;
                default:
                    $sql = "SELECT * FROM files WHERE fileID = '$fileID' AND fileAuthor = '$userID'";
            }
            $result = mysqli_query($conn, $sql);

            $file = mysqli_fetch_assoc($result);
            $filePath = '../../uploads/' . $file['filePath'];

            // Use unlink() function to delete a file
            if (!unlink($filePath))
            {
                echo $file['fileName'] . "cannot be deleted due to an error. Redirecting";
            }
            else
            {
                echo $file['fileName'] . " has been deleted Redirecting";
                $sql = "DELETE FROM `files` WHERE `files`.`fileID` = '$fileID'";
                $result = mysqli_query($conn, $sql);
            }
            echo "<meta http-equiv='refresh' content='0'>";
        }
        else
        {
            $Confirmed = '0';
            echo "Please check the checkbox to perform this action!";
        }
    break;
    case 'DOWNLOADS':
        $sortBy = "ORDER BY `files`.`fileCreated` DESC";
        switch ($fileID)
        {
            case "0";
            //Show all public files
            $sql = "(SELECT files.*,users.userName FROM files $sortBy LEFT JOIN users
            ON files.fileAuthor = users.userID WHERE files.fileAuthor = '$userID') UNION(SELECT files.*,users.userName FROM files LEFT JOIN users
            ON files.fileAuthor = users.userID WHERE files.filePermission = '1')" . $sortBy;
            $view = "1";
            if ((userAccess() == "1"))
            { //Only for users with full access
                //Show all files including private files
                $sql = '(SELECT files.*,users.userName FROM files LEFT JOIN users ON files.fileAuthor = users.userID)' . $sortBy;
            }
        break;
        default: //Show file with correct $fileID
            $sql = "(SELECT files.*,users.userName FROM files LEFT JOIN users ON files.fileAuthor = users.userID WHERE files.relatedNote = '$fileID')" . $sortBy;
            $view = "0";

        break;
    }
    $result = mysqli_query($conn, $sql);
    //$result = $conn->query($sql);
 
    if ($result->num_rows > 0)
    {
        echo "<table>
        <th>Status</th>
        <th>Filename</th>
        <th>File size</th>
        <th>Total Downloads</th>
        <th>Action</th>";
        while ($row = $result->fetch_assoc())
        {
            echo '
                <tr><td>' . filePermission($row['filePermission']) . 'By: ' . $row['userName'] . '</td>
                <td>' . $row['fileName'] . '</td>
                <td>' . filesize_formatted($row['fileSize']) . '</td>
                <td>' . $row['fileDownloads'] . '</td>
                <td><a href="../../functions/filesLogic.php?file_id=' . $row['filePath'] . '">Download </a>';
            $fileAuthor = $row['fileAuthor'];
            if (($userID == "$fileAuthor") or (userAccess() == "1"))
            {
                echo '<br><form method="post"><input type="text" value="' . $row['fileID'] . '" name="fileID" hidden><br><input type="checkbox" value="1" name="confirmFileDelete"><br><button class="link" name="fileDelete">Delete</button></form></td>';
            }
            else
            {
                echo '</td>';
            }
        }
        echo "</tr></table>";
    }
    else
    {
        echo "File not found!";
    }
break;
default:
    echo '<form method="post" enctype="multipart/form-data">';
    echo '<div class="form"> 
               <input type="file" name="myfile"/>
       <br><button name="Upload">Upload</button></form></div>';

       $noteID = $action;
    if ((isset($_POST['Upload'])) AND (is_numeric($noteID)))
    { 
        $filePath = uploadFile($noteID,'1');
    }
break;
}

}

//NOT used
function realGUI($fileID, $action)
{
    include 'languageSwitcher.php';
    include 'dbh.inc.php';
    $userID = $_SESSION['userID'];
    switch ($action)
    {
        case 'DELETE':
            if (isset($_POST['confirmFileDelete']) && $_POST['confirmFileDelete'] == '1')
            {
                $Confirmed = '1';
                switch (userAccess())
                {
                    case "1";
                    $sql = "SELECT * FROM files WHERE fileID = '$fileID'";
                break;
                default:
                    $sql = "SELECT * FROM files WHERE fileID = '$fileID' AND fileAuthor = '$userID'";
            }
            $result = mysqli_query($conn, $sql);

            $file = mysqli_fetch_assoc($result);
            $filePath = '../../uploads/' . $file['filePath'];

            // Use unlink() function to delete a file
            if (!unlink($filePath))
            {
                echo $file['fileName'] . "cannot be deleted due to an error. Redirecting";
            }
            else
            {
                echo $file['fileName'] . " has been deleted Redirecting";
                $sql = "DELETE FROM `files` WHERE `files`.`fileID` = '$fileID'";
                $result = mysqli_query($conn, $sql);
            }
            echo "<meta http-equiv='refresh' content='0'>";
        }
        else
        {
            $Confirmed = '0';
            echo "Please check the checkbox to perform this action!";
        }
    break;
    case 'DOWNLOADS';
    $sortBy = "ORDER BY `files`.`fileCreated` DESC";
    switch ($fileID)
    {
        case "0";
        //Show all public files
        $sql = "(SELECT files.*,users.userName FROM files $sortBy LEFT JOIN users
            ON files.fileAuthor = users.userID WHERE files.fileAuthor = '$userID') UNION(SELECT files.*,users.userName FROM files LEFT JOIN users
            ON files.fileAuthor = users.userID WHERE files.filePermission = '1')" . $sortBy;
        $view = "1";
        if ((userAccess() == "1"))
        { //Only for users with full access
            //Show all files including private files
            $sql = '(SELECT files.*,users.userName FROM files LEFT JOIN users ON files.fileAuthor = users.userID)' . $sortBy;
        }
    break;
    default: //Show file with correct $fileID
        $sql = "(SELECT files.*,users.userName FROM files LEFT JOIN users ON files.fileAuthor = users.userID WHERE files.fileID = '$fileID')" . $sortBy;
        $view = "0";

    break;
}
$result = mysqli_query($conn, $sql);
//$result = $conn->query($sql);
echo "<table>
        <th>Status</th>
        <th>Filename</th>
        <th>File size</th>
        <th>Total Downloads</th>
        <th>Action</th>";
if ($result->num_rows > 0)
{
    while ($row = $result->fetch_assoc())
    {
        echo '
                <tr><td>' . filePermission($row['filePermission']) . 'By: ' . $row['userName'] . '</td>
                <td>' . $row['fileName'] . '</td>
                <td>' . filesize_formatted($row['fileSize']) . '</td>
                <td>' . $row['fileDownloads'] . '</td>
                <td><a href="../../functions/filesLogic.php?file_id=' . $row['filePath'] . '">Download </a>';
        $fileAuthor = $row['fileAuthor'];
        if (($userID == "$fileAuthor") or (userAccess() == "1"))
        {
            echo '<br><form method="post"><input type="text" value="' . $row['fileID'] . '" name="fileID" hidden><br><input type="checkbox" value="1" name="confirmFileDelete"><br><button class="link" name="fileDelete">Delete</button></form></td>';
        }
        else
        {
            echo '</td>';
        }
    }
    echo "</tr></table>";
}
else
{
    echo "File not found!";
}
break;
default:
    $fileType = $fileID;
    echo '<form method="post" enctype="multipart/form-data">';
    echo '<div class="form"> Permission:
               <select name="permission" required>
                 <option selected value="0">Private</option>
                 <option value="1">Public</option>
               </select>
               <input type="file" name="' . $fileType . '"/>
       <br><button name="Upload">Upload</button></form></div>';
    if (isset($_POST['Upload']))
    {
        $filePath = uploadFile($fileType, $permission);
    }
break;
}

}

?>
