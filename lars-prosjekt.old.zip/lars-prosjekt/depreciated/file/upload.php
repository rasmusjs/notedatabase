<?php include '../Nav/navbar.php'; ?>
    <title>Files Upload and Download</title>

    <div class="content">

    
<?php 


//realGUI('mp3', @$permission = mysqli_real_escape_string($conn, $_POST['permission']));
if (isset($_POST['fileDelete'])) {
  realGUI($fileID = mysqli_real_escape_string($conn, $_POST['fileID']), 'DELETE');
} elseif(isset($_POST['Delete'])){

} else {realGUI('138', 'DOWNLOADS');
}

?>

    <?php //fileGUI(0,ALL); ?>
        <?php /*if (isset($_POST['Replace'])) {
  fileGUI($fileID = mysqli_real_escape_string($conn, $_POST['fileID']),ALL);
} else {showDownloads(0);} */?> 
        <details><summary>Standard Upload</summary>
        
      </details>
  </div>





</table>
</div>
</div>
<?php include '../../footer.php' ?>