<?php include '../Nav/navbar.php';?>
<title>Home</title>





<div class="content">
<h1><?=$lang['index-welcome'];?></h1>

<form method="POST">


<?php 

if (isset($_POST['Search'])) {
   browseSheet(0,$searchterm = mysqli_real_escape_string($conn, $_POST['searchterm']));
  }
  
 else { 
    //Search
   echo '<div class="form">

   <input type="text" name="searchterm" placeholder="Name" minlength="0" value="All"/>
   Order by
      <select name="selection">
         <option value="Primary">Search piece name</option>
         <option value="Second">Search second name</option>
         <option value="Composer">Search composer</option>
      </select>
      Maybe Sort by time?
      <button type="submit" name="Search">Search</button>
</div>';

  }



?>
</div>
</div>
<?php include '../../footer.php' ?>
