<?php
//english lang

//navbar
$lang['navbarHome'] = 'Home';
$lang['navbarSearch'] = 'Search in database';
$lang['navbarAddSheet'] = 'Add sheet music to database';
$lang['navbarListen'] = 'Listen';
$lang['navbarApprove'] = 'Approve';
$lang['lang-eng'] = 'English';
$lang['lang-fre'] = 'French';
$lang['lang-ger'] = 'German';

$lang['langPlay'] = 'Play';
$lang['langPause'] = 'Pause';


//index
$lang['index-title'] = 'Language Demo';
$lang['index-welcome'] = "Welcome to Lars' charts database";
$lang['index-text-search'] = "Search away!";

//search
$lang['Searching for'] ='Searching for';
$lang['Result found'] ='Result found';
$lang['No result found'] ='No result found, try a different search term ';
$lang['By'] ='By';
$lang['Upload Success'] = 'Upload Success';
$lang['Upload Failed'] = 'Upload Failed';
$lang['Given'] = 'Given';
$lang['Not given'] = 'Not given';
$lang['Yes'] = 'Yes';
$lang['No'] = 'No';

//messages
$lang['Replace File'] = 'Replace File';
$lang['Edit Sheet'] = 'Edit Sheet';
$lang['Edit Success'] = 'Edit Success';
$lang['Edit Failed'] = 'Edit Failed';
$lang['Action'] = 'Action';
$lang['Action Denied'] = 'Action Denied';
//notedata
$lang['sheetid'] ='Sheetid';
$lang['Piece name'] ='Piece name';
$lang['Other name'] ='Other name';
$lang['Composer'] ='Composer';
$lang['Lyricist'] ='Lyricist';
$lang['Mp3'] ='mp3';
$lang['Mp3 File Note'] ='File must be in mp3 format!';
$lang['Publisher catalogue number'] ='Publisher catalogue number';
$lang['Genre'] ='Genre';
$lang['Please note'] ='Please note';
$lang['Chord names'] ='Chord names';
$lang['Arranger'] ='Arranger';
$lang['Ancestry'] ='Origin';
$lang['Released'] ='Released';
$lang['Physical location'] ='Physical location';
$lang['Link to music sample'] ='Link to music sample';
$lang['Link not found'] ='Link not given';
$lang['Mp3 not found'] ='Mp3 not given';
$lang['PDF not found'] ='Not given';
$lang['Soloist'] ='Soloist';
$lang['Solo instrument'] ='Solo instrument';
$lang['Key'] ='Key';
$lang['Opus number'] ='Opus number';
$lang['Ensemble type'] ='Ensemble type';
$lang['Country of origin'] ='Country of origin';
$lang['Duration'] ='Duration';
$lang['Movement'] ='Movement';
$lang['PDF'] ='PDF';
$lang['Vocal'] ='Vocal';
$lang['Scores Available'] ='Conductors score';
$lang['Instruments'] = 'Instruments';
$lang['Optional'] = 'Optional';




//instruments
$lang['Alt Saxophone in Eb 1'] ='Alt Saxophone in Eb 1';
$lang['Alt Saxophone in Eb 2'] ='Alt Saxophone in Eb 2';
$lang['Alt Saxophone in Eb 3'] ='Alt Saxophone in Eb 3';
$lang['Banjo'] ='Banjo';
$lang['Baritone-saxophone in Eb'] ='Baritone-saxophone in Eb';
$lang['Bass Clarinet (and or Clarinet in Eb)'] ='Bass Clarinet (and or Clarinet in Eb)';
$lang['Bass Trombone'] ='Bass Trombone';
$lang['Viola'] ='Viola';
$lang['Castanets'] ='Castanets';
$lang['Celesta'] ='Celesta';
$lang['Cello 1'] ='Cello 1';
$lang['Cello 2'] ='Cello 2';
$lang['Cello Obbligato'] ='Cello Obbligato';
$lang['Chimes / Tubular Bells'] ='Chimes / Tubular Bells';
$lang['Cymbals'] ='Cymbals';
$lang['Sleigh Bells'] ='Sleigh Bells';
$lang['English Horn'] ='English Horn';
$lang['Euphonium'] ='Euphonium';
$lang['Bassoon 1'] ='Bassoon 1';
$lang['Bassoon 2'] ='Bassoon 2';
$lang['Violin 1'] ='Violin 1';
$lang['Violin 2'] ='Violin 2';
$lang['Violin 3'] ='Violin 3';
$lang['Violin Obligate'] ='Violin Obligate';
$lang['Flute 1'] ='Flute 1';
$lang['Flute 2'] ='Flute 2';
$lang['Flute 3'] ='Flute 3';
$lang['Guitar'] ='Guitar';
$lang['Harmonica'] ='Harmonica';
$lang['Harmonium'] ='Harmonium';
$lang['Harp'] ='Harp';
$lang['Horn in C 1'] ='Horn in C 1';
$lang['Horn in C 2'] ='Horn in C 2';
$lang['Horn in D 1'] ='Horn in D 1';
$lang['Horn in D 2'] ='Horn in D 2';
$lang['Horn in Eb 1'] ='Horn in Eb 1';
$lang['Horn in Eb 2'] ='Horn in Eb 2';
$lang['Horn in F 1'] ='Horn in F 1';
$lang['Horn in F 2'] ='Horn in F 2';
$lang['Horn in F 3'] ='Horn in F 3';
$lang['Horn in F 4'] ='Horn in F 4';
$lang['Clarinet 1 in A'] ='Clarinet 1 in A';
$lang['Clarinet 1 in Bb'] ='Clarinet 1 in Bb';
$lang['Clarinet 1 in C'] ='Clarinet 1 in C';
$lang['Clarinet 2 in A'] ='Clarinet 2 in A';
$lang['Clarinet 2 in Bb'] ='Clarinet 2 in Bb';
$lang['Clarinet 2 in C'] ='Clarinet 2 in C';
$lang['Clarinet 3 in A'] ='Clarinet 3 in A';
$lang['Clarinet 3 in Bb'] ='Clarinet 3 in Bb';
$lang['Keyboard instrument'] ='Piano';
$lang['Chime'] ='Chime';
$lang['Double Bass'] ='Double Bass';
$lang['Contrabassoon'] ='Contrabassoon';
$lang['Cornet in A 1'] ='Cornet in A 1';
$lang['Cornet in A 2'] ='Cornet in A 2';
$lang['Cornet in Bb 1'] ='Cornet in Bb 1';
$lang['Cornet in Bb 2'] ='Cornet in Bb 2';
$lang['Cowbell'] ='Cowbell';
$lang['Mandolin 1'] ='Mandolin 1';
$lang['Oboe 1'] ='Oboe 1';
$lang['Oboe 2'] ='Oboe 2';
$lang['Obo Obligate'] ='Obo Obligate';
$lang['Timpani 1 or 2'] ='Timpani 1 or 2';
$lang['Timpani 3 or More'] ='Timpani 3 or More';
$lang['Piccolo (possibly as One of Flute Voices)'] ='Piccolo (possibly as One of Flute Voices)';
$lang['Snare'] ='Snare';
$lang['Percussion'] ='Percussion';
$lang['Soprano Saxophone'] ='Soprano Saxophone';
$lang['Bass Drum'] ='Bass Drum';
$lang['Tambour'] ='Tambour';
$lang['Tenor Banjo'] ='Tenor Banjo';
$lang['Tenor Saxophone in Bb 1'] ='Tenor Saxophone in Bb 1';
$lang['Tenor Saxophone in Bb 2'] ='Tenor Saxophone in Bb 2';
$lang['Tenor Saxophone in Bb 3'] ='Tenor Saxophone in Bb 3';
$lang['Tenor Saxophone in Bb 4'] ='Tenor Saxophone in Bb 4';
$lang['Tenor Saxophone in C (melody)'] ='Tenor Saxophone in C (melody)';
$lang['Timbales'] ='Timbales';
$lang['Tom Tom'] ='Tom Tom';
$lang['Accordion / Bandoneon'] ='Accordion / Bandoneon';
$lang['Triangle'] ='Triangle';
$lang['Trombone 1'] ='Trombone 1';
$lang['Trombone 2'] ='Trombone 2';
$lang['Trombone 3'] ='Trombone 3';
$lang['Trumpet in A 1'] ='Trumpet in A 1';
$lang['Trumpet in A 2'] ='Trumpet in A 2';
$lang['Trumpet in A Obligate'] ='Trumpet in A Obligate';
$lang['Trumpet in Bb 1'] ='Trumpet in Bb 1';
$lang['Trumpet in Bb 2'] ='Trumpet in Bb 2';
$lang['Trumpet in Bb 3'] ='Trumpet in Bb 3';
$lang['Trumpet in Bb 4'] ='Trumpet in Bb 4';
$lang['Trumpet in Bb Obligate'] ='Trumpet in Bb Obligate';
$lang['Trumpet in C 1'] ='Trumpet in C 1';
$lang['Trumpet in C2'] ='Trumpet in C2';
$lang['Trumpet F 1'] ='Trumpet F 1';
$lang['Trumpet F 2'] ='Trumpet F 2';
$lang['Tuba'] ='Tuba';
$lang['Tuba-ophicléide'] ='Tuba-ophicléide';
$lang['Vibraphone'] ='Vibraphone';
$lang['Xylophone'] ='Xylophone';



?>

