-- phpMyAdmin SQL Dump
-- version 4.9.7deb1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jul 27, 2021 at 09:19 PM
-- Server version: 10.5.10-MariaDB-0ubuntu0.21.04.1
-- PHP Version: 7.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `chat`
--
CREATE DATABASE IF NOT EXISTS `chat` DEFAULT CHARACTER SET utf32 COLLATE utf32_swedish_ci;
USE `chat`;

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE `files` (
  `fileID` int(11) NOT NULL,
  `relatedNote` int(11) NOT NULL,
  `fileAuthor` int(11) NOT NULL,
  `fileName` varchar(255) COLLATE utf32_swedish_ci NOT NULL,
  `filePath` varchar(255) COLLATE utf32_swedish_ci NOT NULL,
  `fileSize` int(11) NOT NULL,
  `fileCreated` datetime NOT NULL,
  `filePermission` varchar(45) COLLATE utf32_swedish_ci NOT NULL,
  `fileDownloads` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE `groups` (
  `groupID` int(11) NOT NULL,
  `groupRecipients` varchar(255) COLLATE utf32_swedish_ci NOT NULL,
  `groupAuthor` int(11) NOT NULL,
  `groupTitle` varchar(255) COLLATE utf32_swedish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_swedish_ci;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`groupID`, `groupRecipients`, `groupAuthor`, `groupTitle`) VALUES
(4, '1;2;3;', 1, 'groupTitle');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `messageID` int(11) NOT NULL,
  `messageAuthor` int(11) NOT NULL,
  `groupID` int(11) NOT NULL,
  `messageSent` datetime NOT NULL DEFAULT current_timestamp(),
  `message` text COLLATE utf32_swedish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_swedish_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`messageID`, `messageAuthor`, `groupID`, `messageSent`, `message`) VALUES
(1, 1, 4, '2021-01-31 14:49:41', 'HEy'),
(2, 3, 4, '2021-01-31 14:50:52', 'Hey'),
(3, 1, 4, '2021-01-31 15:16:30', 'Bruhhhh'),
(4, 1, 4, '2021-01-31 15:32:03', 'ss'),
(5, 1, 4, '2021-01-31 15:48:23', 'LOL'),
(6, 1, 4, '2021-01-31 16:04:14', 'test'),
(7, 1, 4, '2021-03-26 13:35:18', 'heyy'),
(8, 1, 4, '2021-03-26 13:39:33', 'wow'),
(9, 1, 4, '2021-03-26 13:47:19', 'test'),
(10, 1, 4, '2021-05-13 18:39:08', 'test'),
(11, 3, 4, '2021-05-13 19:29:23', 'wtf'),
(12, 3, 4, '2021-05-13 19:29:43', 'hva snex du om'),
(13, 3, 4, '2021-05-13 19:29:47', 'er du doom'),
(14, 1, 4, '2021-05-13 19:29:50', 'nei'),
(15, 1, 4, '2021-05-13 19:29:53', 'iiiiiiiiiiiiiiiiiiiiiiiiii'),
(16, 1, 4, '2021-05-13 19:30:29', 'bro');

-- --------------------------------------------------------

--
-- Table structure for table `userdata`
--

CREATE TABLE `userdata` (
  `userID` int(11) NOT NULL,
  `userLanguage` varchar(3) COLLATE utf32_swedish_ci NOT NULL DEFAULT 'ENG',
  `userAccessLevel` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_swedish_ci;

--
-- Dumping data for table `userdata`
--

INSERT INTO `userdata` (`userID`, `userLanguage`, `userAccessLevel`) VALUES
(1, 'ENG', 0),
(2, 'ENG', 0),
(3, 'ENG', 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userID` int(11) NOT NULL,
  `userName` varchar(255) COLLATE utf32_swedish_ci NOT NULL,
  `userPassword` varchar(255) COLLATE utf32_swedish_ci NOT NULL,
  `userFirstName` varchar(255) COLLATE utf32_swedish_ci NOT NULL,
  `userSurname` varchar(255) COLLATE utf32_swedish_ci NOT NULL,
  `userEmail` varchar(255) COLLATE utf32_swedish_ci NOT NULL,
  `userPhoneNumber` varchar(255) COLLATE utf32_swedish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userID`, `userName`, `userPassword`, `userFirstName`, `userSurname`, `userEmail`, `userPhoneNumber`) VALUES
(1, 'rasmusjs', '$2y$10$M90XGFBbxIBM0jtArQY3JehqbHIQ6PVRLi03Gv5KnYo5ds7uiXvJ.', 'Rasmus Jonssønn', 'Skramstad', 'rasmusjskr@gmail.com', '99576897'),
(2, 'slothmachine', '$2y$10$8aT6O33Yf8Nz8XvIuAbRt.Xo/sHBLU9g2lGZ6fH5PPuuzX7Me/rmm', 'Jonathan', 'Slotten', 'jonaslotten@hotmail.com', '48006618'),
(3, 'johannesjs', '$2y$10$JYvIVOqWw0US0/IAgrQwcOfRS00LVKUS/ys5P/LeFcZl/aZ4A7GpG', 'Johannes', 'Skramstad', 'johannes.skramstad@gmail.com', '99576898');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`fileID`),
  ADD KEY `fk_fileID_User` (`fileAuthor`) USING BTREE;

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`groupID`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`messageID`);

--
-- Indexes for table `userdata`
--
ALTER TABLE `userdata`
  ADD UNIQUE KEY `userID` (`userID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `files`
--
ALTER TABLE `files`
  MODIFY `fileID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `groups`
--
ALTER TABLE `groups`
  MODIFY `groupID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `messageID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
