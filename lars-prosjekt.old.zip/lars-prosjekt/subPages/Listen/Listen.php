<?php include '../Nav/navbar.php';?>
<title><?=$lang['navbarListen'];?></title>


<div class="content">

<h2><?=$lang['navbarListen'];?></h2>
<form method="POST">


<?php 

if (isset($_POST['Search'])) {
    listen(1,$searchterm = mysqli_real_escape_string($conn, $_POST['searchterm']));
  }
   elseif (isset($_POST['Edit'])) {
      retrieveSheet($noteID = mysqli_real_escape_string($conn, $_POST['noteID']));
 }
 elseif (isset($_POST['View'])) {
  viewDetail($noteID = mysqli_real_escape_string($conn, $_POST['noteID']));
}
 else { 
    //Search
   echo '<div class="form">
   <details>
   <summary>Search by name</summary> 
   <input type="text" name="searchterm" placeholder="Name" minlength="0" value="dette er en test"/>
   Dropdown
      <select name="selection">
         <option value="Primary">Search piece name</option>
         <option value="Second">Search second name</option>
         <option value="Composer">Search composer</option>
      </select>
      <button type="submit" name="Search">Search</button>
</div></details><br>';

include '../../functions/dbh.inc.php';

//Offset
@$Offset = mysqli_real_escape_string($conn, $_POST['Offset']);
if (!isset($_POST['Offset'])) {
  $Offset = 0;

}

//echo 'Offset is set to '.$Offset.'<br>';

echo '<form method="POST">Offset is set to : <input type="number" name="Offset" value="'.$Offset.'" step="10" min="0" style="max-width: 50px; word-wrap: break-word;"> </input><button name="ALL" type="submit">Go</button></form>';
  
if (isset($_POST['ALL'])){
  listen('ALL', $Offset);
}
   else {
   listen('ALL', "0");
  }
}


?>

METATAG START OF FILE<p>#EXTM3U</p>
Name:<p>#EXTINF:0, March from Riccardo	Georg Friedrich Händel (1685-1759)	Hotell-orkester Vestfossen +obo evt +vla mm	Orchestral Holyday-heftet</p>
LINK:<p>http://musikanter.org/musikk/normalisert/March_from_Ricardo.mp3 </p>

</div>
</div>
<?php include '../../footer.php' ?>
