<?php require '../../header.php'; sessionRestrict(); ?>

<ul>
  <li><a href="../Start/Home.php" class="active"><?= $lang['navbarHome'];?></a></li>
  <li><a href="../Search/Search.php"><?= $lang['navbarSearch'];?></a></li>
    <li><a href="../Listen/Listen.php"><?= $lang['navbarListen'];?></a></li>
  <li><a href="../Upload/Upload.php"><?= $lang['navbarAddSheet'];?></a></li>
  <?php         if (userAccess() == '1') { echo '
    <li><a href="../Approve/Approve.php">'.$lang['navbarApprove'].'</a></li>';} ?>


  <li><a href="#">User</a></li>
<!--<li><a href="../Chat/home.php">Chat</a></li>-->
  <li style="float:right"><a href="../../includes/logout.inc.php">Logout <?php showname(); ?></a></li>
</ul>
