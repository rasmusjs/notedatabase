<?php include '../../header.php' ?>



<title>Logon</title>
 <!--<img src="../../styles/media/logo/logo.png" style="width: 300px;"></a>-->
<div class="login-page">
<div class="form">
<h1 style="color:white">Log in</h1>

  <!--<img src="../../styles/media/icon/upload.png">-->
  <form class="login-form" method="POST">
    <input type="text" name="userID" placeholder="username or email"/>
    <input type="password" name="password" placeholder="Password"/>
    <button type="submit" name="submit" value="submit">Login</button>

    <p class="message">Not registered? <a href="signup.php">Create an account</a></p>
  </form>
</div>
</div>
<?php if (isset($_POST['submit'])) {
    login($uniqueid = mysqli_real_escape_string($conn, $_POST['userID']),$password = mysqli_real_escape_string($conn, $_POST['password']));
    }
    if (isset($_GET['error'])) {
      echo '<p>';
      if ($_GET['error'] == "empty") {
        echo "Please fill all fields";
      }
      if ($_GET['error'] == "usernotfound") {
        echo "User not found, you can try to login with username, email or phonenumber";
      }
      if ($_GET['error'] == "userfound") {
        echo "User found, pasword not correct";
      }
      echo "</p>";
    }
?>




<?php include '../../footer.php' ?>
