<?php include '../../header.php' ?>
<title>Signup</title>

<div class="login-page">
<div class="form">
  <h1 style="color:white">Sign up</h1>
  <?php 
    if (isset($_POST['submit'])) {
    signup(
    $userName = mysqli_real_escape_string($conn, $_POST['userName']),
    $password = mysqli_real_escape_string($conn, $_POST['password']),
    $firstName = mysqli_real_escape_string($conn, $_POST['firstName']),
    $surname = mysqli_real_escape_string($conn, $_POST['surname']),
    $email = mysqli_real_escape_string($conn, $_POST['email']),
    $phoneNumber = mysqli_real_escape_string($conn, $_POST['phoneNumber']),
    $passwordRepeat = mysqli_real_escape_string($conn, $_POST['passwordRepeated']));
    }

    if (isset($_GET['error'])) {
      echo '<p>';
      if ($_GET['error'] == "empty") {
        echo "Please fill all fields";
      }
      if ($_GET['error'] == "emailinalid") {
        echo "Please type a valid email";
      }
      if ($_GET['error'] == "usertaken") {
        echo "Please pick a different username, the username is already in use";
      }
      if ($_GET['error'] == "emailtaken") {
        echo "Please pick a different email, the email is already in use";
      }
      if ($_GET['error'] == "telephonetaken") {
        echo "Please pick a different telephone number, the telephone number is already in use";
      }
      echo "</p>";
    }
?>
  <form class="register-form" method="POST">
    <input type="text" name="firstName" placeholder="First Name">
    <input type="text" name="surname" placeholder="Surname">
    <input type="text" name="email" placeholder="E-mail">
    <input type="text" name="userName" placeholder="Username">
    <input type="password" name="password" placeholder="Password">
    <input type="password" name="passwordRepeated" placeholder="Repeat Password">
    <input type="text" name="phoneNumber" placeholder="Telephone Number">
    By clicking Create, you agree to our <a href="#">Terms of Service</a><br><br>
    <button  type="submit" name="submit">Create</button>
    <p class="message">Already registered? <a href="login.php">Sign In</a></p>

  </form>
</div>
</div>





<?php include '../../footer.php' ?>
