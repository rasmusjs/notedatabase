<?php
include '../Nav/navbar.php'; //userAccess();
?>
<title>Home</title>
<div class="content">

   <?php


include '../../functions/languageSwitcher.php';
include '../../functions/sqlCharts.php';
$noteID = $_GET['id'];
$sql    = "SELECT notedata.mp3,notedata.PDF,notedata.`Navn på stykket` FROM notedata WHERE noteID = '$noteID'";
$result = $conn->query($sql);

echo '<form method="post" enctype="multipart/form-data">';
if ($result->num_rows > 0) {
    // output data of each row
    while ($row = $result->fetch_assoc()) {
        echo '<h2>Viewing files related to<b> '.$row[$columnSqlNote['Navn på stykket']].'</b></h2><br>';
    }
    echo 'Current files related to note';
    if (isset($_POST['fileDelete'])) {
      fileGUI($fileID = mysqli_real_escape_string($conn, $_POST['fileID']), 'DELETE');
    } else {
        fileGUI($noteID, 'DOWNLOADS');
    }  
    echo '<b>Add files to note</b>';
    fileGUI('file', $noteID);
}


else {
    echo "<h1>Note not found</h1>";
    echo '<a href="../Search/Search.php">Back to search</a>';
}   
    

    
    

 


?>
</div>
</div>
<?php
include '../../footer.php';
?>