<?php include '../Nav/navbar.php';?>
<title>Home</title>





<div class="content">

<h2><?=$lang['index-text-search'];?></h2>
<form method="POST">


<?php 

if (isset($_POST['Search'])) {
    browseSheet(1,$searchterm = mysqli_real_escape_string($conn, $_POST['searchterm']));
  }
   elseif (isset($_POST['Edit'])) {
      retrieveSheet($noteID = mysqli_real_escape_string($conn, $_POST['noteID']));
 }
 elseif (isset($_POST['View'])) {
  viewDetail($noteID = mysqli_real_escape_string($conn, $_POST['noteID']));
}
  elseif (isset($_POST['Delete'])) {
    deleteSheet($noteID = mysqli_real_escape_string($conn, $_POST['noteID']));
  }
 elseif (isset($_POST['editSheet'])) {
   uploadSheet(2,
           $noteID = mysqli_real_escape_string($conn, $_POST['noteID']),
           $Piecename = mysqli_real_escape_string($conn, $_POST['Piecename']),
           $Othername = mysqli_real_escape_string($conn, $_POST['OtherName']),
           $Composer = mysqli_real_escape_string($conn, $_POST['Composer']),
           $Lyricist = mysqli_real_escape_string($conn, $_POST['Lyricist']),
           $Mp3 = mysqli_real_escape_string($conn, $_POST['Mp3']),
           $Publishercataloguenumber = mysqli_real_escape_string($conn, $_POST['Publishercataloguenumber']),
           $Genre = mysqli_real_escape_string($conn, $_POST['Genre']),
           $Pleasenote = mysqli_real_escape_string($conn, $_POST['PleaseNote']),
           $Arranger = mysqli_real_escape_string($conn, $_POST['Arranger']),
           $EnsembleType = mysqli_real_escape_string($conn, $_POST['EnsembleType']),
           $Chordnames = mysqli_real_escape_string($conn, @$_POST['Chordnames']),
           $Ancestry = mysqli_real_escape_string($conn, $_POST['Ancestry']),
           $Released = mysqli_real_escape_string($conn, $_POST['Released']),
           $Physicallocation = mysqli_real_escape_string($conn, $_POST['PhysicalLocation']),
           $Linktomusicsample = mysqli_real_escape_string($conn, $_POST['Link']),
           $Soloist = mysqli_real_escape_string($conn,  @$_POST['Soloist']),
           $Soloinstrument = mysqli_real_escape_string($conn, $_POST['SoloInstrument']),
           $Key = mysqli_real_escape_string($conn, $_POST['Key']),
           $Opusnumber = mysqli_real_escape_string($conn, $_POST['OpusNumber']),
           $Countryoforigin = mysqli_real_escape_string($conn, $_POST['CountryOfOrigin']),
           $Duration = mysqli_real_escape_string($conn, $_POST['Duration']),
           $Movement = mysqli_real_escape_string($conn,  @$_POST['Movement']),
           $PDF = mysqli_real_escape_string($conn, @$_POST['PDF']),
           $Vocal = mysqli_real_escape_string($conn,  @$_POST['Vocal']),
           $Scoresavailable = mysqli_real_escape_string($conn, @$_POST['Scoresavailable']),
         $AltSaxophoneinEb1 = mysqli_real_escape_string($conn, @$_POST['AltSaxophoneinEb1']),
         $AltSaxophoneinEb2 = mysqli_real_escape_string($conn, @$_POST['AltSaxophoneinEb2']),
         $AltSaxophoneinEb3 = mysqli_real_escape_string($conn, @$_POST['AltSaxophoneinEb3']),
         $Banjo = mysqli_real_escape_string($conn, @$_POST['Banjo']),
         $BaritonesaxophoneinEb = mysqli_real_escape_string($conn, @$_POST['Baritone-saxophoneinEb']),
         $BassClarinetandorClarinetinEb = mysqli_real_escape_string($conn, @$_POST['BassClarinetandorClarinetinEb']),
         $BassTrombone = mysqli_real_escape_string($conn, @$_POST['BassTrombone']),
         $Viola = mysqli_real_escape_string($conn, @$_POST['Viola']),
         $Castanets = mysqli_real_escape_string($conn, @$_POST['Castanets']),
         $Celesta = mysqli_real_escape_string($conn, @$_POST['Celesta']),
         $Cello1 = mysqli_real_escape_string($conn, @$_POST['Cello1']),
         $Cello2 = mysqli_real_escape_string($conn, @$_POST['Cello2']),
         $CelloObbligato = mysqli_real_escape_string($conn, @$_POST['CelloObbligato']),
         $ChimesTubularBells = mysqli_real_escape_string($conn, @$_POST['ChimesTubularBells']),
         $Cymbals = mysqli_real_escape_string($conn, @$_POST['Cymbals']),
         $SleighBells = mysqli_real_escape_string($conn, @$_POST['SleighBells']),
         $EnglishHorn = mysqli_real_escape_string($conn, @$_POST['EnglishHorn']),
         $Euphonium = mysqli_real_escape_string($conn, @$_POST['Euphonium']),
         $Bassoon1 = mysqli_real_escape_string($conn, @$_POST['Bassoon1']),
         $Bassoon2 = mysqli_real_escape_string($conn, @$_POST['Bassoon2']),
         $Violin1 = mysqli_real_escape_string($conn, @$_POST['Violin1']),
         $Violin2 = mysqli_real_escape_string($conn, @$_POST['Violin2']),
         $Violin3 = mysqli_real_escape_string($conn, @$_POST['Violin3']),
         $ViolinObligate = mysqli_real_escape_string($conn, @$_POST['ViolinObligate']),
         $Flute1 = mysqli_real_escape_string($conn, @$_POST['Flute1']),
         $Flute2 = mysqli_real_escape_string($conn, @$_POST['Flute2']),
         $Flute3 = mysqli_real_escape_string($conn, @$_POST['Flute3']),
         $Guitar = mysqli_real_escape_string($conn, @$_POST['Guitar']),
         $Harmonica = mysqli_real_escape_string($conn, @$_POST['Harmonica']),
         $Harmonium = mysqli_real_escape_string($conn, @$_POST['Harmonium']),
         $Harp = mysqli_real_escape_string($conn, @$_POST['Harp']),
         $HorninC1 = mysqli_real_escape_string($conn, @$_POST['HorninC1']),
         $HorninC2 = mysqli_real_escape_string($conn, @$_POST['HorninC2']),
         $HorninD1 = mysqli_real_escape_string($conn, @$_POST['HorninD1']),
         $HorninD2 = mysqli_real_escape_string($conn, @$_POST['HorninD2']),
         $HorninEb1 = mysqli_real_escape_string($conn, @$_POST['HorninEb1']),
         $HorninEb2 = mysqli_real_escape_string($conn, @$_POST['HorninEb2']),
         $HorninF1 = mysqli_real_escape_string($conn, @$_POST['HorninF1']),
         $HorninF2 = mysqli_real_escape_string($conn, @$_POST['HorninF2']),
         $HorninF3 = mysqli_real_escape_string($conn, @$_POST['HorninF3']),
         $HorninF4 = mysqli_real_escape_string($conn, @$_POST['HorninF4']),
         $Clarinet1inA = mysqli_real_escape_string($conn, @$_POST['Clarinet1inA']),
         $Clarinet1inBb = mysqli_real_escape_string($conn, @$_POST['Clarinet1inBb']),
         $Clarinet1inC = mysqli_real_escape_string($conn, @$_POST['Clarinet1inC']),
         $Clarinet2thea = mysqli_real_escape_string($conn, @$_POST['Clarinet2thea']),
         $Clarinet2inBb = mysqli_real_escape_string($conn, @$_POST['Clarinet2inBb']),
         $Clarinet2inC = mysqli_real_escape_string($conn, @$_POST['Clarinet2inC']),
         $Clarinet3thea = mysqli_real_escape_string($conn, @$_POST['Clarinet3thea']),
         $Clarinet3inBb = mysqli_real_escape_string($conn, @$_POST['Clarinet3inBb']),
         $Keyboardinstrument = mysqli_real_escape_string($conn, @$_POST['Keyboardinstrument']),
         $Chime = mysqli_real_escape_string($conn, @$_POST['Chime']),
         $DoubleBass = mysqli_real_escape_string($conn, @$_POST['DoubleBass']),
         $Contrabassoon = mysqli_real_escape_string($conn, @$_POST['Contrabassoon']),
         $Cornetthea1 = mysqli_real_escape_string($conn, @$_POST['Cornetthea1']),
         $CornetinA2 = mysqli_real_escape_string($conn, @$_POST['CornetinA2']),
         $CornetinBb1 = mysqli_real_escape_string($conn, @$_POST['CornetinBb1']),
         $CornetinBb2 = mysqli_real_escape_string($conn, @$_POST['CornetinBb2']),
         $Cowbell = mysqli_real_escape_string($conn, @$_POST['Cowbell']),
         $Mandolin1 = mysqli_real_escape_string($conn, @$_POST['Mandolin1']),
         $Oboe1 = mysqli_real_escape_string($conn, @$_POST['Oboe1']),
         $Oboe2 = mysqli_real_escape_string($conn, @$_POST['Oboe2']),
         $OboObligate = mysqli_real_escape_string($conn, @$_POST['OboObligate']),
         $Timpani1or2 = mysqli_real_escape_string($conn, @$_POST['Timpani1or2']),
         $Timpani3orMore = mysqli_real_escape_string($conn, @$_POST['Timpani3orMore']),
         $PiccolopossiblyasOneofFluteVoices = mysqli_real_escape_string($conn, @$_POST['PiccolopossiblyasOneofFluteVoices']),
         $Snare = mysqli_real_escape_string($conn, @$_POST['Snare']),
         $Percussion = mysqli_real_escape_string($conn, @$_POST['Percussion']),
         $SopranoSaxophone = mysqli_real_escape_string($conn, @$_POST['SopranoSaxophone']),
         $BassDrum = mysqli_real_escape_string($conn, @$_POST['BassDrum']),
         $Tambour = mysqli_real_escape_string($conn, @$_POST['Tambour']),
         $TenorBanjo = mysqli_real_escape_string($conn, @$_POST['TenorBanjo']),
         $TenorSaxophoneinBb1 = mysqli_real_escape_string($conn, @$_POST['TenorSaxophoneinBb1']),
         $TenorSaxophoneinBb2 = mysqli_real_escape_string($conn, @$_POST['TenorSaxophoneinBb2']),
         $TenorSaxophoneinBb3 = mysqli_real_escape_string($conn, @$_POST['TenorSaxophoneinBb3']),
         $TenorSaxophoneinBb4 = mysqli_real_escape_string($conn, @$_POST['TenorSaxophoneinBb4']),
         $TenorSaxophoneinCmelody = mysqli_real_escape_string($conn, @$_POST['TenorSaxophoneinCmelody']),
         $Timbales = mysqli_real_escape_string($conn, @$_POST['Timbales']),
         $TomTom = mysqli_real_escape_string($conn, @$_POST['TomTom']),
         $AccordionBandoneon = mysqli_real_escape_string($conn, @$_POST['AccordionBandoneon']),
         $Triangle = mysqli_real_escape_string($conn, @$_POST['Triangle']),
         $Trombone1 = mysqli_real_escape_string($conn, @$_POST['Trombone1']),
         $Trombone2 = mysqli_real_escape_string($conn, @$_POST['Trombone2']),
         $Trombone3 = mysqli_real_escape_string($conn, @$_POST['Trombone3']),
         $TrumpetinA1 = mysqli_real_escape_string($conn, @$_POST['Trumpetin A1']),
         $TrumpetinA2 = mysqli_real_escape_string($conn, @$_POST['TrumpetinA2']),
         $TrumpetinaObligate = mysqli_real_escape_string($conn, @$_POST['TrumpetinaObligate']),
         $TrumpetinBb1 = mysqli_real_escape_string($conn, @$_POST['TrumpetinBb1']),
         $TrumpetinBb2 = mysqli_real_escape_string($conn, @$_POST['TrumpetinBb2']),
         $TrumpetinBb3 = mysqli_real_escape_string($conn, @$_POST['TrumpetinBb3']),
         $TrumpetinBb4 = mysqli_real_escape_string($conn, @$_POST['TrumpetinBb4']),
         $TrumpetinBbObligate = mysqli_real_escape_string($conn, @$_POST['TrumpetinBbObligate']),
         $TrumpetinC1 = mysqli_real_escape_string($conn, @$_POST['TrumpetinC1']),
         $TrumpetinC2 = mysqli_real_escape_string($conn, @$_POST['TrumpetinC2']),
         $TrumpetF1 = mysqli_real_escape_string($conn, @$_POST['TrumpetF1']),
         $TrumpetF2 = mysqli_real_escape_string($conn, @$_POST['TrumpetF2']),
         $Tuba = mysqli_real_escape_string($conn, @$_POST['Tuba']),
         $Tubaophicléide = mysqli_real_escape_string($conn, @$_POST['Tuba-ophicléide']),
         $Vibraphone = mysqli_real_escape_string($conn, @$_POST['Vibraphone']),
         $Xylophone = mysqli_real_escape_string($conn, @$_POST['Xylophone']));
   
       }
 else { 
    //Search
   echo '<div class="form">
   <details>
   <summary>Search by name</summary>
   
  
   
   
   
   <input type="text" name="searchterm" placeholder="Name" minlength="0" value="dette er en test"/>
   Dropdown
      <select name="selection">
         <option value="Primary">Search piece name</option>
         <option value="Second">Search second name</option>
         <option value="Composer">Search composer</option>
      </select>
      <button type="submit" name="Search">Search</button>
</div></details><br>';

include '../../functions/dbh.inc.php';

@$Offset = mysqli_real_escape_string($conn, $_POST['Offset']);
if (!isset($_POST['Offset'])) {
  $Offset = 0;

}


//echo 'Offset is set to '.$Offset.'<br>';

echo '<form method="POST">Offset is set to : <input type="number" name="Offset" value="'.$Offset.'" step="100" min="0" style="max-width: 50px; word-wrap: break-word;"> </input><button name="ALL" type="submit">Go</button></form>';
  
if (isset($_POST['ALL'])){
  browseSheet('ALL', $Offset);
}
   else {
   browseSheet('ALL', "0");
  }
}



?>



</div>
</div>
<?php include '../../footer.php' ?>
