<?php include '../Nav/navbar.php';?>
<title>Home</title>





<div class="content">
<h1><?=$lang['index-welcome'];?></h1>

<?php  ?>
</div>

<?php include '../../footer.php' ?>
