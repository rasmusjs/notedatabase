<?php include '../Nav/navbar.php'; ?>
<title>Home</title>





<div class="content">
<div class="row">
  <div class="column">
    <h2>Column 1</h2>
    <p>Shortcuts</p>
  </div>
  <div class="column2">
    <h2>Column 2</h2>
    <p>Some text..</p>
  </div>
    <div class="column3">
    <h2>Column 3</h2>
    <p>Friends</p>
  </div>
</div>
</div>

<?php include '../../footer.php' ?>
