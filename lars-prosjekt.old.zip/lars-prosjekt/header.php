
<?php require 'functions/functions.php'; ?>

<!DOCTYPE html>
<html lang="no" dir="ltr">
  <head>
    

    <meta charset="utf-8" /> 
    <!--<meta http-equiv="Content-type" content="text/html; charset=utf-8" />-->
    <!--<link rel="icon" href="styles/media/icon/upload.gif" type="image/gif" >
    <link rel="icon" href="../styles/media/icon/upload.gif" type="image/gif" >
    <link rel="icon" href="../../styles/media/icon/upload.gif" type="image/gif" >-->
    
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="styles/normalStyle.css">
    <link rel="stylesheet" href="../styles/normalStyle.css">
    <link rel="stylesheet" href="../../styles/normalStyle.css">




  </head>
  <body>



