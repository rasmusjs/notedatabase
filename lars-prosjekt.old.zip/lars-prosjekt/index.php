<title>Welcome</title>


<?php
include 'header.php';

if (!isset($_SESSION['userID'])) {
 	header("Location: subPages/Splash/login.php");
}
if (isset($_SESSION['userID'])) {
  header("Location: subPages/Search/Search.php");
}

include 'footer.php';
?>
