Spr�k filer finner du under lang, du m� endre til riktig filplassering 


KJ�R 
"UPDATE `notedata` SET `Sjanger` = '28' WHERE `notedata`.`sjanger` IS NULL; " 

B�r endre datatypen Spilletid til TIME istendfor varchart, m� da endre oppf�ringer f�rst,

Avstamming? Nye eller gamle navn? N� endres verdien etter hvor mange oppf�ringer som er i Avstamming p� oppf�ring 79 enders det til fornavn og etternavn

Korrupte filer over 1MB?
https://stackoverflow.com/questions/13442270/ini-setupload-max-filesize-200m-not-working-in-php

Slett
	- ID
Endre
	- PersonID til noteID
	- Spilletid Varchart til 11



Filer



Man kan per 15. November laste opp filer, filene f�r ett tilfeldig filnavn lokal. Dette er gjort s� man ikke kan overskrive filer dersom de heter det samme.

Jobb videre med � kunne spille mp3 filer rett i nettleser. Trenger ikke � laste ned.


To do
https://www.w3schools.com/cssref/tryit.asp?filename=trycss3_resize
Egen mappe til mp3 og pdf ikke delt mappe


Fiks
Bugs
Ser ikke ut til at spilletid kommer inn i databasen, Audio controlls p� audio form tar hele plassen og erstatter de andre elementene med seg selv

Id�e



Gjort
Lang remse med �rstall fra 1800-1970 for utgivelsesdato
utgivelsesdato (released) kan v�re uten dag og m�ned.
Lars m� godkjenne endring i oppf�ringene f�r de lagres permanent i databasen.
Ha eget form for opplasting og endring av filer. S� dette blir en egen "modul"
Hvordan laste opp mp3-filer til mappe "./mp3"
Hvordan laste opp pdf-filer til mappe "noter"
