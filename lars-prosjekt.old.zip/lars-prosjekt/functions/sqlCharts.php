<?php 
//Name of table columns for database case-sensitive
$columnSqlNote['noteID']="noteID";
$columnSqlNote['Navn på stykket']="Navn på stykket";
$columnSqlNote['Annet navn på stykket']="Annet navn på stykket";
$columnSqlNote['Komponist for musikken']="Komponist for musikken";
$columnSqlNote['Tekstforfatter']="Tekstforfatter";
$columnSqlNote['mp3']="mp3";
$columnSqlNote['PDF']="PDF";
//From files
$columnSqlNote['fileName']="fileName";
$columnSqlNote['fileID']="fileID";
$columnSqlNote['filePath']="filePath";
$columnSqlNote['Noteutgivers katalognr']="Noteutgivers katalognr";
//From Sjanger not notedata
$columnSqlNote['Sjanger']="Sjanger";
$columnSqlNote['Obs']="Obs";
$columnSqlNote['Akkorder er angitt']="Akkorder er angitt";
$columnSqlNote['Arrangert av']="Arrangert av";
//From Avstamming not notedata

$columnSqlNote['Avstamning']="Avstamning";
$columnSqlNote['Utgivelsesdato']="Utgivelsesdato";

//From Lagrinssted Konserthistorikk
$columnSqlNote['Lagringssted']="konserthistorikk";
$columnSqlNote['Solist']="Solist";

//From Instrument not notedata
$columnSqlNote['Soloinstrument']="Instrument";
$columnSqlNote['Dur']="Dur";
$columnSqlNote['Opus nr']="Opus nr";

//From type arrangement
$columnSqlNote['Type arrangement']="Orkester";

//From type notedata
$columnSqlNote['Type arrangement notedata']="Type arrangement";
$columnSqlNote['Soloinstrument notedata']="Soloinstrument";
$columnSqlNote['Lagringssted notedata']="Lagringssted";
//From Opprinnelsesland
$columnSqlNote['Opprinnelsesland']="Opprinnelsesland";
$columnSqlNote['Spilletid']="Spilletid";
//
$columnSqlNote['Type stykke']="Type stykke";
$columnSqlNote['Finnes elektronisk på harddisk']="Finnes elektronisk på harddisk";
$columnSqlNote['Link til lydprøve']="Link til lydprøve";
$columnSqlNote['Alt-saksofon i Eb 1']="Alt-saksofon i Eb 1";
$columnSqlNote['Alt-saksofon i Eb 2']="Alt-saksofon i Eb 2";
$columnSqlNote['Alt-saksofon i Eb 3']="Alt-saksofon i Eb 3";
$columnSqlNote['Banjo']="Banjo";
$columnSqlNote['Bariton-Saxofon i Eb']="Bariton-Saxofon i Eb";
$columnSqlNote['Bassklarinett (og eller klarinett i Eb)']="Bassklarinett (og eller klarinett i Eb)";
$columnSqlNote['Bass-trombone']="Bass-trombone";
$columnSqlNote['Bratsj']="Bratsj";
$columnSqlNote['Castagnetter']="Castagnetter";
$columnSqlNote['Celesta']="Celesta";
$columnSqlNote['Cello 1']="Cello 1";
$columnSqlNote['Cello 2']="Cello 2";
$columnSqlNote['Cello obligato']="Cello obligato";
$columnSqlNote['Chimes/tubular bells']="Chimes/tubular bells";
$columnSqlNote['Cymbaler']="Cymbaler";
$columnSqlNote['Dombjeller']="Dombjeller";
$columnSqlNote['Engelsk horn']="Engelsk horn";
$columnSqlNote['Eufonium']="Eufonium";
$columnSqlNote['Fagott 1']="Fagott 1";
$columnSqlNote['Fagott 2']="Fagott 2";
$columnSqlNote['Fiolin 1']="Fiolin 1";
$columnSqlNote['Fiolin 2']="Fiolin 2";
$columnSqlNote['Fiolin 3']="Fiolin 3";
$columnSqlNote['Fiolin obligat']="Fiolin obligat";
$columnSqlNote['Fløyte 1']="Fløyte 1";
$columnSqlNote['Fløyte 2']="Fløyte 2";
$columnSqlNote['Fløyte 3']="Fløyte 3";
$columnSqlNote['Gitar']="Gitar";
$columnSqlNote['Harmonika']="Harmonika";
$columnSqlNote['Harmonium']="Harmonium";
$columnSqlNote['Harpe']="Harpe";
$columnSqlNote['Horn i C 1']="Horn i C 1";
$columnSqlNote['Horn i C 2']="Horn i C 2";
$columnSqlNote['Horn i D 1']="Horn i D 1";
$columnSqlNote['Horn i D 2']="Horn i D 2";
$columnSqlNote['Horn i Eb 1']="Horn i Eb 1";
$columnSqlNote['Horn i Eb 2']="Horn i Eb 2";
$columnSqlNote['Horn i F 1']="Horn i F 1";
$columnSqlNote['Horn i F 2']="Horn i F 2";
$columnSqlNote['Horn i F 3']="Horn i F 3";
$columnSqlNote['Horn i F 4']="Horn i F 4";
$columnSqlNote['Klarinett 1 i A']="Klarinett 1 i A";
$columnSqlNote['Klarinett 1 i Bb']="Klarinett 1 i Bb";
$columnSqlNote['Klarinett 1 i C']="Klarinett 1 i C";
$columnSqlNote['Klarinett 2 i A']="Klarinett 2 i A";
$columnSqlNote['Klarinett 2 i Bb']="Klarinett 2 i Bb";
$columnSqlNote['Klarinett 2 i C']="Klarinett 2 i C";
$columnSqlNote['Klarinett 3 i A']="Klarinett 3 i A";
$columnSqlNote['Klarinett 3 i Bb']="Klarinett 3 i Bb";
$columnSqlNote['Klaver']="Klaver";
$columnSqlNote['Klokkespill']="Klokkespill";
$columnSqlNote['Kontrabass']="Kontrabass";
$columnSqlNote['Kontrafagott']="Kontrafagott";
$columnSqlNote['Kornett i A 1']="Kornett i A 1";
$columnSqlNote['Kornett i A 2']="Kornett i A 2";
$columnSqlNote['Kornett i Bb 1']="Kornett i Bb 1";
$columnSqlNote['Kornett i Bb 2']="Kornett i Bb 2";
$columnSqlNote['Kubjelle']="Kubjelle";
$columnSqlNote['Mandolin 1']="Mandolin 1";
$columnSqlNote['Obo 1']="Obo 1";
$columnSqlNote['Obo 2']="Obo 2";
$columnSqlNote['Obo Obligat']="Obo Obligat";
$columnSqlNote['Partitur finnes']="Partitur finnes";
$columnSqlNote['Pauker 1-2 stk']="Pauker 1-2 stk";
$columnSqlNote['Pauker 3 eller fler']="Pauker 3 eller fler";
$columnSqlNote['Piccolo (muligens som en av fløytestemmene)']="Piccolo (muligens som en av fløytestemmene)";
$columnSqlNote['Sang']="Sang";
$columnSqlNote['Skarptromme']="Skarptromme";
$columnSqlNote['Slagverk']="Slagverk";
$columnSqlNote['Solistinstrument']="Solistinstrument";
$columnSqlNote['Sopran-saksofon']="Sopran-saksofon";
$columnSqlNote['Stortromme']="Stortromme";
$columnSqlNote['Tamburtromme']="Tamburtromme";
$columnSqlNote['Tenorbanjo']="Tenorbanjo";
$columnSqlNote['Tenor-saksofon i Bb 1']="Tenor-saksofon i Bb 1";
$columnSqlNote['Tenor-saksofon i Bb 2']="Tenor-saksofon i Bb 2";
$columnSqlNote['Tenor-saksofon i Bb 3']="Tenor-saksofon i Bb 3";
$columnSqlNote['Tenor-saksofon i Bb 4']="Tenor-saksofon i Bb 4";
$columnSqlNote['Tenor-saksofon i C (melodi)']="Tenor-saksofon i C (melodi)";
$columnSqlNote['Timbaler']="Timbaler";
$columnSqlNote['Tom tom']="Tom tom";
$columnSqlNote['Trekkspill/Bandoneon']="Trekkspill/Bandoneon";
$columnSqlNote['Triangel']="Triangel";
$columnSqlNote['Trombone 1']="Trombone 1";
$columnSqlNote['Trombone 2']="Trombone 2";
$columnSqlNote['Trombone 3']="Trombone 3";
$columnSqlNote['Trompet i A 1']="Trompet i A 1";
$columnSqlNote['Trompet i A 2']="Trompet i A 2";
$columnSqlNote['Trompet i A obligat']="Trompet i A obligat";
$columnSqlNote['Trompet i Bb 1']="Trompet i Bb 1";
$columnSqlNote['Trompet i Bb 2']="Trompet i Bb 2";
$columnSqlNote['Trompet i Bb 3']="Trompet i Bb 3";
$columnSqlNote['Trompet i Bb 4']="Trompet i Bb 4";
$columnSqlNote['Trompet i Bb obligat']="Trompet i Bb obligat";
$columnSqlNote['Trompet i C 1']="Trompet i C 1";
$columnSqlNote['Trompet i C 2']="Trompet i C 2";
$columnSqlNote['Trompet i F 1']="Trompet i F 1";
$columnSqlNote['Trompet i F 2']="Trompet i F 2";
$columnSqlNote['Tuba']="Tuba";
$columnSqlNote['Tuba-Ophicléide']="Tuba-Ophicléide";
$columnSqlNote['Vibrafon']="Vibrafon";
$columnSqlNote['Xylofon']="Xylofon";



//USER
$columnSqlUser['userFirstName']="userFirstName";
$columnSqlUser['userSurname']="userSurname";
  ?>