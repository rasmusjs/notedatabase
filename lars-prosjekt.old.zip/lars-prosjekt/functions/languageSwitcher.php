<?php 
include 'dbh.inc.php';

//Language
if (isset($_SESSION['userID'])) {

    $userID = $_SESSION['userID'];
    $sql = "SELECT userLanguage,userAccessLevel FROM userdata WHERE userID = '$userID'";
    $result = $conn->query($sql);
    
      if ($result->num_rows > 0) {
         // output data of each row
         while($row = $result->fetch_assoc()) {
          $_SESSION['language'] = $row["userLanguage"];
          $_SESSION['accessLevel'] = $row["userAccessLevel"];
         }
         
      }  
    
      $engFilePath = '/var/www/html/lars-prosjekt/lang/eng.php';
      //WIN$engFilePath = 'C:/wamp64/www/lars-prosjekt/lang/eng.php';

    //Language switch
    switch($_SESSION['language']){
       case "eng":
        require($engFilePath);
        break;
        case "fre":
            require('../..lang/fre.php');		
        break;
        case "ger":
            require('../..lang/ger.php');		
      break;
      case "nob":
            require('C:\wamp64\www\lars-prosjekt\lang\nob.php');		
        break;	
        default: 
            require($engFilePath);		
      }

    }  


?>
