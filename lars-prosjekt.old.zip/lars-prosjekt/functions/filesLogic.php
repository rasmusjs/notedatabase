<?php

//Grunnen til at dette ikke er samlet er for å skille det fra hoveddokumentet
include 'dbh.inc.php';



// fileDownloads files

$sql = "(SELECT files.*,users.userName FROM files LEFT JOIN users
ON files.fileAuthor = users.userID WHERE files.filePermission = '1') UNION (SELECT files.*,users.userName FROM files LEFT JOIN users
ON files.fileAuthor = users.userID WHERE files.fileAuthor = '$userID ')";
//$sql = "SELECT * FROM files";
$result = mysqli_query($conn, $sql);
$files = mysqli_fetch_all($result, MYSQLI_ASSOC);

if (isset($_GET['file_id'])) {

    $fileid = $_GET['file_id'];

    // fetch file to download from database
    $sql = "SELECT * FROM files WHERE filePath= '$fileid'";
    $result = mysqli_query($conn, $sql);

    $file = mysqli_fetch_assoc($result);
    $filePath = '../uploads/' . $file['filePath'];
    if (file_exists($filePath)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename='.basename($file['fileName']));
        header('Expires: -1');
		header("Cache-Control: public, must-revalidate, post-check=0, pre-check=0");
        header('Pragma: public');
        header('Content-Length: ' . filesize($filePath));
        ob_clean();
        flush();
        readfile($filePath);

        // Now update fileDownloads count
        $newCount = $file['fileDownloads'] + 1;
        $updateQuery = "UPDATE files SET fileDownloads=$newCount WHERE filePath='$fileid'";
        mysqli_query($conn, $updateQuery);
        exit;
    }

}
